----VEHICLE-----
--Nombre de lignes dans entity pour vehicle
select count(entity_id) from i3_v1_dev.entity where entity_type_id = 4 and entity_sub_type_id =24 and is_case_entity = false ;--1209927
--Nombre de lignes dans gvm
select count(*) from raw_questis_latest.gvm; --1209927



----OBJECT-----
--Nombre de lignes dans entity pour FIREARM
select count(entity_id) from i3_v1_dev.entity where entity_type_id = 4 and entity_sub_type_id =23 and is_case_entity = false ;--90915
--Nombre de lignes dans gvw pour FIREARM
select count(*) from raw_questis_latest.gvw where CAST(GVWCAT AS INT) IN (80, 96); --90915

--Nombre de lignes dans entity pour DRUG
select count(entity_id) from i3_v1_dev.entity where entity_type_id = 4 and entity_sub_type_id =20 and is_case_entity = false ;--470053
--Nombre de lignes dans gvw pour DRUG
select count(*) from raw_questis_latest.gvw where CAST(GVWCAT AS INT) = 18; --470053

--Nombre de lignes dans entity pour PHONENUMBER
select count(entity_id) from i3_v1_dev.entity where entity_type_id = 4 and entity_sub_type_id = 12 and is_case_entity = false ;--372085
--Nombre de lignes dans NUM 
select count(*) from raw_questis_latest.NUM  WHERE CAST(NUMCLASSE AS INT) IN (1, 2, 17, 18) ; --372085

--Nombre de lignes dans entity pour EMAIL ADRESS
select count(entity_id) from i3_v1_dev.entity where entity_type_id = 4 and entity_sub_type_id = 14 and is_case_entity = false ;--82830
--Nombre de lignes dans NUM 
select count(*) from raw_questis_latest.NUM  WHERE CAST(NUMCLASSE AS INT) = 3 ; --82830

---- OFFENCE ----

--Nombre de lignes dans entity pour fact (45 lignes manquantes)
select count(entity_id) from i3_v1_dev.entity where entity_type_id = 3 and entity_sub_type_id =10 and is_case_entity = false ;--10089688
--Nombre de lignes dans fei 
select count(*) from raw_questis_latest.fei; --10089733

---- PERSON----
--Nombre de lignes dans entity pour NATURAL PERSON
select count(entity_id) from i3_v1_dev.entity where entity_type_id = 1 and entity_sub_type_id =3 and is_case_entity = false ;--1462061
--Nombre de lignes dans gps 
select count(*) from raw_questis_latest.gps; --1462061

--Nombre de lignes dans entity pour MORAL PERSON
select count(entity_id) from i3_v1_dev.entity where entity_type_id = 1 and entity_sub_type_id = 1 and is_case_entity = false ;--29675
--Nombre de lignes dans ORG 
select count(*) from raw_questis_latest.org WHERE CAST(orgbeschtype AS INT) = 1 ; --29675

--Nombre de lignes dans entity pour grouping
select count(entity_id) from i3_v1_dev.entity where entity_type_id = 1 and entity_sub_type_id = 2 and is_case_entity = false ;--1270
--Nombre de lignes dans ORG 
select count(*) from raw_questis_latest.org  WHERE CAST(orgbeschtype AS INT) = 2 ; --1270

-- case drug-- 
select count(*) from i3_v1_dev.object WHERE object_type_id = 20;--3136
select count(*) from i3_v1_dev.drug;--3136
--case firearm-- 
select count(*) from i3_v1_dev.object WHERE object_type_id = 23;--1090
select count(*) from i3_v1_dev.firearm;--1090