from pyspark.sql.functions import monotonically_increasing_id, expr, substring, col


def load_table(sparkSession, conf_variables):
    raw_references = conf_variables['raw_references']
    sparkSession.sql(f"USE {raw_references}")
    tables_list = sparkSession.sql(f"show tables")
    tables_list = tables_list.select(tables_list.columns[1]).rdd.flatMap(lambda x : x).collect()
    tables = []
    translation_column_suffixes = ['textbe', 'textbf', 'textbd', 'textbg']

    for x in tables_list:
        table = sparkSession.read.table(x)
        keyTab = x[-3:]
        columns_to_check = list(map(lambda x: (keyTab + x).upper(), translation_column_suffixes))
        columns_to_check.append((keyTab + "key").upper())
        table_columns = list(map(lambda x : x.upper(), table.columns))
        columns_in_table = all(x in table_columns for x in columns_to_check)

        if columns_in_table:
            transformed_table = table.select(
                    expr(f"CAST('{x[-3:].upper()}' AS STRING)").alias("REFTAB_TABLE"),
                    table[keyTab + "key"].cast("BIGINT").alias("REFTAB_ID"),
                    expr(f"UPPER({keyTab + translation_column_suffixes[0]})").alias("LABEL"),
                    expr(f"CAST({keyTab + translation_column_suffixes[1]} AS STRING)").alias("LABEL_FR"),
                    expr(f"CAST({keyTab + translation_column_suffixes[2]} AS STRING)").alias("LABEL_NL"),
                    expr(f"CAST({keyTab + translation_column_suffixes[3]} AS STRING)").alias("LABEL_DE"),
                    expr(f"CAST({keyTab + translation_column_suffixes[0]} AS STRING)").alias("LABEL_EN")
            )
            tables.append(transformed_table)
    union_view = tables[0]
    for i in range(1, len(tables)):
        union_view = union_view.unionAll(tables[i])
    union_columns = union_view.columns
    # Adding the new column ID with unique identifier and casting to bigint
    id_df = union_view.withColumn("ID", monotonically_increasing_id())

    # Rearranging the ID column as a first column
    final_mat_view = id_df.select("ID", *union_columns)
    return final_mat_view



