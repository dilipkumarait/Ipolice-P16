CREATE TABLE ${referential_data_view}.`I3_TRANSLATION_LABEL` (
    `ID` BIGINT,
    `I3_TABLE` STRING,
    `I3_ID` BIGINT,
    `LABEL` STRING,
    `LABEL_FR` STRING,
    `LABEL_NL` STRING,
    `LABEL_DE` STRING,
    `LABEL_EN` STRING
) STORED AS PARQUET
    TBLPROPERTIES ('transactional'='false');

--Filling I3_TRANSLATION_LABEL view
INSERT INTO ${referential_data_view}.I3_TRANSLATION_LABEL (
    SELECT ROW_NUMBER() OVER (ORDER BY i3_label.i3_table, i3_label.id) AS ID,
           i3_label.i3_table AS I3_TABLE,
           i3_label.id AS I3_ID,
           i3_label.label AS LABEL,
           i3_label.label_fr AS LABEL_FR,
           i3_label.label_nl AS LABEL_NL,
           i3_label.label_de AS LABEL_DE,
           i3_label.label_en AS LABEL_EN
    FROM (
        SELECT
            case_type.id AS ID,
            'CASE_TYPE' AS I3_TABLE,
            case_type.label AS LABEL,
            case_type.label_fr AS LABEL_FR,
            case_type.label_nl AS LABEL_NL,
            case_type.label_de AS LABEL_DE,
            case_type.label_en AS LABEL_EN
        FROM ${i3_db}.CASE_TYPE AS case_type

        UNION

        SELECT
            case_status.id AS ID,
            'CASE_STATUS' AS I3_TABLE,
            case_status.label AS LABEL,
            case_status.label_fr AS LABEL_FR,
            case_status.label_nl AS LABEL_NL,
            case_status.label_de AS LABEL_DE,
            case_status.label_en AS LABEL_EN
        FROM ${i3_db}.CASE_STATUS AS case_status

        UNION

        SELECT
            case_confidentiality.id AS ID,
            'CASE_CONFIDENTIALITY' AS I3_TABLE,
            case_confidentiality.label AS LABEL,
            case_confidentiality.label_fr AS LABEL_FR,
            case_confidentiality.label_nl AS LABEL_NL,
            case_confidentiality.label_de AS LABEL_DE,
            case_confidentiality.label_en AS LABEL_EN
        FROM ${i3_db}.CASE_CONFIDENTIALITY AS case_confidentiality

        UNION

        SELECT
            data_container_type.id AS ID,
            'DATA_CONTAINER_TYPE' AS I3_TABLE,
            data_container_type.label AS LABEL,
            data_container_type.label_fr AS LABEL_FR,
            data_container_type.label_nl AS LABEL_NL,
            data_container_type.label_de AS LABEL_DE,
            data_container_type.label_en AS LABEL_EN
        FROM ${i3_db}.DATA_CONTAINER_TYPE AS data_container_type

        UNION

        SELECT
            information_category.id AS ID,
            'INFORMATION_CATEGORY' AS I3_TABLE,
            information_category.label AS LABEL,
            information_category.label_fr AS LABEL_FR,
            information_category.label_nl AS LABEL_NL,
            information_category.label_de AS LABEL_DE,
            information_category.label_en AS LABEL_EN
        FROM ${i3_db}.INFORMATION_CATEGORY AS information_category
    ) AS i3_label
);