from pyspark.sql.functions import col, max, lit, asc, desc, concat

def load_table(sparkSession, conf_variables):
    source_entity = natural_person_informations(sparkSession, conf_variables)
    target_entity = natural_person_informations(sparkSession, conf_variables)

    # Change de name and types of the fields to fit the expected structure
    source_entity = source_entity.select(*(
        source_entity['ENTITY_ID'].cast("BIGINT").alias("SOURCE_ENTITY_ID"),
        source_entity['ENTITY_FIRSTNAME'].cast("STRING").alias("SOURCE_ENTITY_FIRSTNAME"),
        source_entity['ENTITY_LASTNAME'].cast("STRING").alias("SOURCE_ENTITY_LASTNAME"),
        source_entity['ENTITY_DISPLAY_TITLE'].cast("STRING").alias("SOURCE_ENTITY_DISPLAY_TITLE"),
        source_entity['NATIONALITY'].cast("STRING").alias("SOURCE_NATIONALITY"),
        source_entity['GENDER'].cast("STRING").alias("SOURCE_GENDER"),
        source_entity['REAL_OFFENCE_ID'].cast("BIGINT").alias("REAL_OFFENCE_ID"),
        source_entity['REAL_OFFENCE_DISPLAY_TITLE'].cast("STRING").alias("REAL_OFFENCE_DISPLAY_TITLE"),
        source_entity['REAL_OFFENCE_CATEGORY'].cast("STRING").alias("REAL_OFFENCE_CATEGORY"),
        source_entity['REAL_OFFENCE_CLASS'].cast("STRING").alias("REAL_OFFENCE_CLASS"),
        source_entity['REAL_OFFENCE_QUALIFICATION'].cast("BIGINT").alias("REAL_OFFENCE_QUALIFICATION"),
        source_entity['REAL_OFFENCE_IS_CONCRETE'].cast("STRING").alias("REAL_OFFENCE_IS_CONCRETE"),
        source_entity['REAL_OFFENCE_START_DATE_TIME'].cast("BIGINT").alias("REAL_OFFENCE_START_DATE_TIME"),
        source_entity['REAL_OFFENCE_END_DATE_TIME'].cast("STRING").alias("REAL_OFFENCE_END_DATE_TIME"),
        source_entity['CASE_ID'].cast("BIGINT").alias("CASE_ID"),
        source_entity['CASE_TYPE'].cast("STRING").alias("CASE_TYPE"),
        source_entity['DOCUMENT_ID'].cast("STRING").alias("DOCUMENT_ID"),
        source_entity['DOCUMENT_TYPE'].cast("STRING").alias("DOCUMENT_TYPE"),
        source_entity['RECORD_UNIT'].cast("STRING").alias("RECORD_UNIT")
        )
    )

    target_entity = target_entity.select(*(
            target_entity['ENTITY_ID'].cast("BIGINT").alias("TARGET_ENTITY_ID"),
            target_entity['ENTITY_FIRSTNAME'].cast("STRING").alias("TARGET_ENTITY_FIRSTNAME"),
            target_entity['ENTITY_LASTNAME'].cast("STRING").alias("TARGET_ENTITY_LASTNAME"),
            target_entity['ENTITY_DISPLAY_TITLE'].cast("STRING").alias("TARGET_ENTITY_DISPLAY_TITLE"),
            target_entity['NATIONALITY'].cast("STRING").alias("TARGET_NATIONALITY"),
            target_entity['GENDER'].cast("STRING").alias("TARGET_GENDER"),
            target_entity['REAL_OFFENCE_ID'].cast("BIGINT").alias("TARGET_REAL_OFFENCE_ID")
        )
    )

    # Join the tables on the real fact_id
    final_df = source_entity.join(
        target_entity,
        how='inner',
        on=source_entity['REAL_OFFENCE_ID']==target_entity['TARGET_REAL_OFFENCE_ID']
    )

    # Remove permutation duplications
    final_df = final_df.orderBy(col("SOURCE_ENTITY_ID").asc(),col("TARGET_ENTITY_ID").asc())
    final_df = final_df.filter("SOURCE_ENTITY_ID < TARGET_ENTITY_ID")
    
    # Add static columns
    final_df = final_df.withColumn("RELATION_TYPE", lit("Co-suspect"))
    final_df = final_df.withColumn("IS_DEDUCED", lit("Oui"))

    # Final select to set the order of the fields
    final_df = final_df.select(
        [
            "SOURCE_ENTITY_ID", "SOURCE_ENTITY_FIRSTNAME", "SOURCE_ENTITY_LASTNAME", "SOURCE_ENTITY_DISPLAY_TITLE",
            "TARGET_ENTITY_ID", "TARGET_ENTITY_FIRSTNAME", "TARGET_ENTITY_LASTNAME", "TARGET_ENTITY_DISPLAY_TITLE",
            "SOURCE_NATIONALITY", "TARGET_NATIONALITY", "SOURCE_GENDER", "TARGET_GENDER", 
            "REAL_OFFENCE_ID", "REAL_OFFENCE_DISPLAY_TITLE", "REAL_OFFENCE_CATEGORY", "REAL_OFFENCE_CLASS", "REAL_OFFENCE_QUALIFICATION",
            "REAL_OFFENCE_IS_CONCRETE", "REAL_OFFENCE_START_DATE_TIME", "REAL_OFFENCE_END_DATE_TIME",
            "CASE_ID", "CASE_TYPE", "DOCUMENT_ID", "DOCUMENT_TYPE", "RECORD_UNIT", "RELATION_TYPE", "IS_DEDUCED"
        ]
    )

    return final_df

def natural_person_informations(sparkSession, conf_variables):
    i3_db = conf_variables["i3_db"]

    # define all ref tables needed
    real_person_names = sparkSession.sql(f"""
        SELECT 
            sta.target_entity_id AS REAL_PERSON_NAMES_ID,
            concat_ws(
                ',',
                sort_array(collect_set(CAST(ippa.first_name AS STRING)))
            ) AS LIST_FIRSTNAME,
            concat_ws(
                ',',
                sort_array(collect_set(CAST(ippa.last_name AS STRING)))
            ) AS LIST_LASTNAME
        FROM {i3_db}.STATEMENT AS sta
        LEFT JOIN {i3_db}.IDENTIFYING_NATURAL_PERSON_ATTRIBUTES AS ippa
            ON sta.source_entity_id = ippa.natural_person_id
            AND sta.statement_type_id = 2
            AND sta.statement_subtype_id = 7
        GROUP BY 
            sta.target_entity_id
    """)

    person_informations = sparkSession.sql(f"""
        SELECT 
            natural_person_identification_statement.target_entity_id AS ENTITY_ID,
            concat_ws(',', collect_set(CAST(ippa.first_name AS STRING))) AS ENTITY_FIRSTNAME,
            concat_ws(',', collect_set(CAST(ippa.last_name AS STRING))) AS ENTITY_LASTNAME,
            concat_ws(',', collect_set(CAST(nap.label_fr AS STRING))) AS NATIONALITY,
            concat_ws(',', collect_set(CAST(gender.label_fr AS STRING)))  AS GENDER,
            offence_identification_statement.target_entity_id AS REAL_OFFENCE_ID,
            concat_ws(',', sort_array(collect_set(CAST(fcat.label_fr AS STRING)))) AS REAL_OFFENCE_CATEGORY,
            concat_ws(',', sort_array(collect_set(CAST(fclass.label_fr AS STRING)))) AS REAL_OFFENCE_CLASS,
            concat_ws(',', sort_array(collect_set(CAST(fqua.label_fr AS STRING)))) AS REAL_OFFENCE_QUALIFICATION,
            concat_ws(',', collect_set(CAST(fact.is_concrete AS STRING))) AS REAL_OFFENCE_IS_CONCRETE,
            concat_ws(',', collect_set(CAST(fact.start_date AS STRING))) AS REAL_OFFENCE_START_DATE_TIME,
            concat_ws(',', collect_set(CAST(fact.end_date AS STRING))) AS REAL_OFFENCE_END_DATE_TIME,
            concat_ws(',', sort_array(collect_set(CAST(cse.id AS STRING)))) AS CASE_ID,
            concat_ws(',', sort_array(collect_set(CAST(case_type.label_fr AS STRING)))) AS CASE_TYPE,
            concat_ws(',', sort_array(collect_set(CAST(dc.id AS STRING)))) AS DOCUMENT_ID,
            concat_ws(',', sort_array(collect_set(CAST(dc_type.label_fr AS STRING)))) AS DOCUMENT_TYPE,
            concat_ws(',', sort_array(collect_set(CAST(pp.label_fr AS STRING)))) AS RECORD_UNIT

        FROM {i3_db}.STATEMENT AS natural_person_identification_statement
        INNER JOIN {i3_db}.STATEMENT AS suspect_person_in_offence_statement
            ON natural_person_identification_statement.source_entity_id = suspect_person_in_offence_statement.source_entity_id
            AND suspect_person_in_offence_statement.statement_type_id = 2
            AND suspect_person_in_offence_statement.statement_subtype_id = 28
            AND natural_person_identification_statement.statement_type_id = 2
            AND natural_person_identification_statement.statement_subtype_id = 7
            AND natural_person_identification_statement.source_entity_type_id = 1
            AND natural_person_identification_statement.source_entity_sub_type_id = 3
            AND natural_person_identification_statement.target_entity_type_id = 1
            AND natural_person_identification_statement.target_entity_sub_type_id = 3
        INNER JOIN {i3_db}.STATEMENT AS offence_identification_statement
            ON offence_identification_statement.source_entity_id = suspect_person_in_offence_statement.target_entity_id -- case-offence
            AND offence_identification_statement.statement_type_id = 2
            AND offence_identification_statement.statement_subtype_id = 7
            AND offence_identification_statement.source_entity_type_id = 3
            AND offence_identification_statement.source_entity_sub_type_id = 10
            AND offence_identification_statement.target_entity_type_id = 3
            AND offence_identification_statement.target_entity_sub_type_id = 10
        INNER JOIN {i3_db}.IDENTIFYING_NATURAL_PERSON_ATTRIBUTES AS ippa
            ON ippa.natural_person_id = natural_person_identification_statement.source_entity_id
        INNER JOIN {i3_db}.FACT AS fact
            ON suspect_person_in_offence_statement.target_entity_id = fact.id
        INNER JOIN {i3_db}.PERSON_ATTRIBUTES AS pa
            ON pa.person_id = natural_person_identification_statement.source_entity_id
        INNER JOIN {i3_db}.`CASE` AS cse
            ON cse.case_number = natural_person_identification_statement.registration_case_number
            AND cse.case_year = natural_person_identification_statement.registration_case_year
        INNER JOIN {i3_db}.CASE_TYPE AS case_type
            ON cse.case_type_id = case_type.id
        
        -- To modify as an inner join when the link between datacontainer and case is well implemented  
        LEFT JOIN {i3_db}.DATA_CONTAINER AS dc
            ON dc.registration_case_number = natural_person_identification_statement.registration_case_number
            AND dc.registration_case_year = natural_person_identification_statement.registration_case_year
        LEFT JOIN {i3_db}.DATA_CONTAINER_TYPE AS dc_type
            ON dc_type.id = dc.data_container_type_id
        LEFT JOIN {i3_db}.POLICE_PARTICIPANT AS pp
            ON pp.id = dc.police_participant_id

        -- Joins to add the labels in french
        LEFT JOIN {i3_db}.FACT_CATEGORY AS fcat
            ON fcat.id = fact.fact_category_id
        LEFT JOIN {i3_db}.FACT_CLASS AS fclass
            ON fclass.id = fact.fact_class_id 
        LEFT JOIN {i3_db}.FACT_QUALIFICATION AS fqua
            ON fqua.id = fact.fact_qualification_id               
        LEFT JOIN {i3_db}.NATIONALITY AS nap
            ON nap.id = pa.nationality_id
        LEFT JOIN {i3_db}.GENDER AS gender
            ON gender.id = ippa.gender_id
        
        GROUP BY
            natural_person_identification_statement.target_entity_id, -- Real Natural Person ID
            natural_person_identification_statement.source_entity_id, -- Case Natural Person ID
            offence_identification_statement.target_entity_id -- Real Offence ID
    """)

    final_df = person_informations.join(
        real_person_names, 
        how='inner',
        on=real_person_names['REAL_PERSON_NAMES_ID']==person_informations['ENTITY_ID']
    )

    final_df = final_df.withColumn(
        "ENTITY_DISPLAY_TITLE", 
        concat(
                final_df['ENTITY_ID'], lit(" "),
                final_df['LIST_FIRSTNAME'], lit(" "),
                final_df['LIST_LASTNAME']
        )
    ).withColumn(
        "REAL_OFFENCE_DISPLAY_TITLE", 
        concat(
                final_df['REAL_OFFENCE_ID'], lit(" "),
                final_df['REAL_OFFENCE_CLASS']
        )
    )    
    return final_df

