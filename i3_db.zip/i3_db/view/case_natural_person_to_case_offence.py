def load_table(sparkSession, conf_variables):
    i3_db = conf_variables['i3_db']
    
    is_suspect_table = sparkSession.sql(f"""
        SELECT 
            stm.id AS STATEMENT_ID,
            stm.source_entity_id AS SOURCE_ENTITY_ID, -- Person
            stm.target_entity_id AS TARGET_ENTITY_ID, -- Offence
            cse.id AS CASE_ID,
            cse.case_type_id AS CASE_TYPE_ID,
            ct.label_fr AS CASE_TYPE,
            "Est suspect" AS TYPE

        FROM {i3_db}.STATEMENT AS stm
        INNER JOIN {i3_db}.CASE_ITEM AS ci
            ON stm.id = ci.id
        INNER JOIN {i3_db}.`CASE` AS cse
            ON cse.case_number = ci.registration_case_number
            AND cse.case_year= ci.registration_case_year
        INNER JOIN {i3_db}.CASE_TYPE AS ct
            ON ct.id = cse.case_type_id
        WHERE stm.statement_subtype_id = 28
            AND stm.statement_type_id = 2
    """)
    return is_suspect_table