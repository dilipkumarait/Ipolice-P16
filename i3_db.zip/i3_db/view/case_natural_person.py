from pyspark.sql.functions import col, lit
from pyspark.sql.functions import concat, collect_set

def load_table(sparkSession, conf_variables):

    i3_db = conf_variables['i3_db']

    case_natural_person = sparkSession.sql(f"""
        SELECT
            sta.source_entity_id AS CASE_PERSON_ID,
            sta.target_entity_id AS REAL_PERSON_ID,
            concat_ws(',', sort_array(collect_set(CAST(iden.first_name AS STRING)))) AS FIRST_NAME,
            concat_ws(',', sort_array(collect_set(CAST(iden.last_name AS STRING)))) AS LAST_NAME,
            CONCAT(
                sta.source_entity_id, " ",
                concat_ws(',',collect_set(CAST(iden.first_name AS STRING)))," ",
                concat_ws(',',collect_set(CAST(iden.last_name AS STRING)))
            ) AS CASE_PERSON_DISPLAY_TITLE,
            CAST(concat_ws(',',collect_set(CAST(iden.date_of_birth AS STRING))) AS DATE) AS BIRTHDATE, -- Forcer le format de la date avec la fonction FORMAT_DATE
            CAST(concat_ws(',',collect_set(CAST(ct.id AS STRING))) AS BIGINT) AS BIRTH_COUNTRY_ID,
            concat_ws(',',collect_set(CAST(ct.label_fr AS STRING))) AS BIRTH_COUNTRY,
            concat_ws(',',collect_set(CAST(iden.national_registration_number AS STRING))) AS NATIONAL_REGISTRATION_NUMBER,                          
            CAST(concat_ws(',',collect_set(CAST(att.nationality_id AS STRING))) AS BIGINT) AS NATIONALITY_ID,
            concat_ws(',',collect_set(CAST(nat.label_fr AS STRING))) AS NATIONALITY,
            CAST(concat_ws(',',collect_set(CAST(iden.gender_id AS STRING))) AS BIGINT) AS GENDER_ID,
            concat_ws(',',collect_set(CAST(gdr.label_fr AS STRING))) AS GENDER,
            cse.id AS CASE_ID,
            cse.case_type_id AS CASE_TYPE_ID,
            case_type.label_fr AS CASE_TYPE,
            concat_ws(',',sort_array(collect_set(CAST(entity_to_legacy.LEGACY_ID AS STRING)))) AS ANG_BNG_ID
        FROM {i3_db}.NATURAL_PERSON AS natural_person
        INNER JOIN {i3_db}.CASE_ITEM AS item 
            ON natural_person.id = item.id 
        INNER JOIN {i3_db}.`CASE` AS cse
            ON cse.case_number = item.registration_case_number
            AND cse.case_year = item.registration_case_year
        INNER JOIN {i3_db}.CASE_TYPE AS case_type
            ON cse.case_type_id = case_type.id
        INNER JOIN {i3_db}.ENTITY_TO_LEGACY AS entity_to_legacy
            ON natural_person.id = entity_to_legacy.entity_id
        LEFT JOIN {i3_db}.PERSON_ATTRIBUTES AS att 
            ON natural_person.id = att.person_id
        LEFT JOIN {i3_db}.IDENTIFYING_NATURAL_PERSON_ATTRIBUTES AS iden 
            ON natural_person.id = iden.natural_person_id
        LEFT JOIN {i3_db}.COUNTRY AS ct
            ON ct.id = iden.birth_municipality_id 
        LEFT JOIN {i3_db}.NATIONALITY AS nat
            ON nat.id = att.nationality_id 
        LEFT JOIN {i3_db}.gender AS gdr 
            ON gdr.id = iden.gender_id
        LEFT JOIN {i3_db}.STATEMENT AS sta 
            ON sta.statement_type_id = 2
            AND sta.statement_subtype_id = 7
            AND natural_person.id = sta.source_entity_id
        GROUP BY sta.source_entity_id, sta.target_entity_id, cse.id, cse.case_type_id, case_type.label_fr
    """)

    real_person_names = sparkSession.sql(f"""
        SELECT
            sta.target_entity_id AS REAL_PERSON_NAMES_ID,
            -- concat_ws(',' , collect_set(cast(sta.source_entity_id as STRING))) as list_case_person_id,
            concat_ws(',' , sort_array(collect_set(CAST(ippa.first_name AS STRING)))) AS LIST_FIRSTNAME,
            concat_ws(',' , sort_array(collect_set(CAST(ippa.last_name AS STRING)))) AS LIST_LASTNAME
        FROM {i3_db}.identifying_natural_person_attributes AS ippa
        INNER JOIN {i3_db}.statement AS sta
            ON sta.source_entity_id = ippa.natural_person_id
            AND sta.statement_type_id = 2
            AND sta.statement_subtype_id = 7
        GROUP BY sta.target_entity_id
    """)

    final_df = case_natural_person.join(
        real_person_names,
        how='left',
        on=case_natural_person['REAL_PERSON_ID']==real_person_names['REAL_PERSON_NAMES_ID']
    )

    final_df = final_df.withColumn(
        "real_person_display_title",
        concat(
            final_df['REAL_PERSON_ID'],lit(" "),
            final_df['LIST_FIRSTNAME'],lit(" "),
            final_df['LIST_LASTNAME']
        )
    )

    final_df = final_df.select(*(
        final_df['CASE_PERSON_ID'].cast("BIGINT").alias("CASE_NATURAL_PERSON_ID"),
        final_df['REAL_PERSON_ID'].cast("BIGINT").alias("REAL_NATURAL_PERSON_ID"),
        final_df['FIRST_NAME'].cast("STRING").alias("FIRST_NAME"),
        final_df['LAST_NAME'].cast("STRING").alias("LAST_NAME"),
        final_df['CASE_PERSON_DISPLAY_TITLE'].cast("STRING").alias("CASE_PERSON_DISPLAY_TITLE"),
        final_df['REAL_PERSON_DISPLAY_TITLE'].cast("STRING").alias("REAL_PERSON_DISPLAY_TITLE"),
        final_df['BIRTHDATE'].cast("TIMESTAMP").alias("BIRTHDATE"),
        final_df['BIRTH_COUNTRY_ID'].cast("BIGINT").alias("BIRTH_COUNTRY_ID"),
        final_df['BIRTH_COUNTRY'].cast("STRING").alias("BIRTH_COUNTRY"),
        final_df['NATIONAL_REGISTRATION_NUMBER'].cast("STRING").alias("NATIONAL_REGISTRATION_NUMBER"),
        final_df['NATIONALITY_ID'].cast("BIGINT").alias("NATIONALITY_ID"),
        final_df['NATIONALITY'].cast("STRING").alias("NATIONALITY"),
        final_df['GENDER_ID'].cast("BIGINT").alias("GENDER_ID"),
        final_df['GENDER'].cast("STRING").alias("GENDER"),
        final_df['CASE_ID'].cast("BIGINT").alias("CASE_ID"),
        final_df['CASE_TYPE_ID'].cast("BIGINT").alias("CASE_TYPE_ID"),
        final_df['CASE_TYPE'].cast("STRING").alias("CASE_TYPE"),
        final_df['ANG_BNG_ID'].cast("BIGINT").alias("ANG_BNG_ID")
        )
    )

    return final_df