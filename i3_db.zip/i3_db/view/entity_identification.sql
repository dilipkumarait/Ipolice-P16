CREATE TABLE IF NOT EXISTS ${i3_view}.`ENTITY_IDENTIFICATION`(
    `STATEMENT_ID` BIGINT,
    `TYPE` STRING,
    `SOURCE_ENTITY_ID` BIGINT,
    `TARGET_ENTITY_ID` BIGINT,
    `ENTITY_TYPE_ID` BIGINT,
    `ENTITY_SUBTYPE_ID` BIGINT,
    `CASE_ID` BIGINT,
    `CASE_TYPE_ID` BIGINT,
    `CASE_TYPE` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_view}.`ENTITY_IDENTIFICATION` (
    SELECT 
        stm.id AS STATEMENT_ID,
        "Identification" AS TYPE,
        stm.source_entity_id AS SOURCE_ENTITY_ID,
        stm.target_entity_id AS TARGET_ENTITY_ID,
        stm.source_entity_type_id AS ENTITY_TYPE_ID,
        stm.source_entity_sub_type_id AS ENTITY_SUBTYPE_ID,
        cse.id AS CASE_ID,
        cse.case_type_id AS CASE_TYPE_ID,
        ct.label_fr AS CASE_TYPE
    FROM ${i3_db}.STATEMENT AS stm
    INNER JOIN ${i3_db}.CASE_ITEM AS ci
        ON stm.id = ci.id
    INNER JOIN ${i3_db}.`CASE` AS cse
        ON cse.case_number = ci.registration_case_number
        AND cse.case_year= ci.registration_case_year
    INNER JOIN ${i3_db}.CASE_TYPE AS ct
        ON ct.id = cse.case_type_id
    WHERE stm.statement_type_id = 2
        AND stm.statement_subtype_id = 7
);