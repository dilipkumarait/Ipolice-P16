
def load_table(sparkSession, conf_variables):
    
    i3_db = conf_variables['i3_db']

    real_entity_table = sparkSession.sql(f"""
        SELECT 
            e.id AS REAL_ENTITY_ID,
            CAST(e.entity_type_id AS BIGINT) AS REAL_ENTITY_TYPE_ID,
            CAST(e.entity_sub_type_id AS BIGINT) AS REAL_ENTITY_SUB_TYPE_ID
        FROM {i3_db}.ENTITY AS e
        WHERE e.is_case_entity = FALSE
    """)

    return real_entity_table