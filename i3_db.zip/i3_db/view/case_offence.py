from pyspark.sql.functions import col, max, lit, asc, desc, concat

def load_table(sparkSession, conf_variables):
    i3_db = conf_variables['i3_db']

    day_of_week = sparkSession.createDataFrame(
        [
            (1, 'Dimanche'),
            (2, 'Lundi'),
            (3, 'Mardi'),
            (4, 'Mercredi'),
            (5, 'Jeudi'),
            (6, 'Vendredi'),
            (7, 'Samedi')
        ],
        ['DAY_ID', 'DAY_LABEL_FR']
    )
    
    real_offence_label = sparkSession.sql(f"""
        SELECT 
            sta.target_entity_id AS REAL_OFFENCE_LABEL_ID,
            CONCAT(sta.target_entity_id, " ", concat_ws(',' , sort_array(collect_set(CAST(fcla.label_fr AS STRING))))) AS REAL_OFFENCE_LABEL
        FROM {i3_db}.FACT AS fact
        LEFT JOIN {i3_db}.statement AS sta
            ON sta.source_entity_id = fact.id
            AND sta.statement_type_id = 2
            AND sta.statement_subtype_id = 7
        INNER JOIN {i3_db}.fact_class AS fcla
            ON fact.fact_class_id = fcla.id

        GROUP BY sta.target_entity_id
    """)

    case_offence_label = sparkSession.sql(f"""
    SELECT 
        fact.id AS CASE_OFFENCE_LABEL_ID,
        CONCAT(fact.id, " ", concat_ws(',' , sort_array(collect_set(CAST(fcla.label_fr AS STRING))))) AS CASE_OFFENCE_LABEL
    FROM {i3_db}.FACT AS fact
    INNER JOIN {i3_db}.FACT_CLASS AS fcla
        ON fact.fact_class_id = fcla.id

    GROUP BY fact.id
    """)

    case_offence = sparkSession.sql(f"""
        SELECT
            stm.source_entity_id AS CASE_OFFENCE_ID,
            stm.target_entity_id AS REAL_OFFENCE_ID,
            fact.fact_category_id AS CATEGORY_ID,
            fact.fact_class_id AS CLASS_ID,
            fact.fact_qualification_id AS QUALIFICATION_ID,
            fact.is_concrete AS IS_CONCRETE,
            fact.is_attempt AS IS_ATTEMPT,
            fact.start_date AS START_DATE_TIME,
            EXTRACT(dayofweek from fact.start_date) AS START_WEEK_DAY_ID,
            fact.end_date AS END_DATE_TIME,
            EXTRACT(dayofweek from fact.end_date) AS END_WEEK_DAY_ID,
            CONCAT_WS(',', SORT_ARRAY(COLLECT_SET(CAST(dc.id AS STRING)))) AS DOCUMENT_ID,
            CONCAT_WS(',', SORT_ARRAY(COLLECT_SET(CAST(dc.data_container_type_id AS STRING)))) AS DOCUMENT_TYPE_ID,
            CONCAT_WS(',', SORT_ARRAY(COLLECT_SET(CAST(dc_type.label_fr AS STRING)))) AS DOCUMENT_TYPE,
            CONCAT_WS(',', SORT_ARRAY(COLLECT_SET(CAST(dc.police_participant_id AS STRING)))) AS RECORD_UNIT_ID,
            CONCAT_WS(',', SORT_ARRAY(COLLECT_SET(CAST(pp.label_FR AS STRING)))) AS RECORD_UNIT,
            cse.id AS CASE_ID,
            cse.case_type_id AS CASE_TYPE_ID,
            case_type.label_fr AS CASE_TYPE,
            concat_ws(',',sort_array(collect_set(CAST(entity_to_legacy.LEGACY_ID AS STRING)))) AS ANG_BNG_ID
        FROM {i3_db}.FACT AS fact
        LEFT JOIN {i3_db}.STATEMENT AS stm
            ON stm.source_entity_id = fact.id
            AND stm.statement_type_id = 2
            AND stm.statement_subtype_id = 7
        INNER JOIN {i3_db}.`CASE` AS cse
            ON fact.registration_case_year = cse.case_year
            AND fact.registration_case_number = cse.case_number
        INNER JOIN {i3_db}.CASE_TYPE AS case_type
            ON cse.case_type_id = case_type.id
        INNER JOIN {i3_db}.ENTITY_TO_LEGACY AS entity_to_legacy
            ON fact.id = entity_to_legacy.entity_id
        
        -- To modify as an inner join when the link between datacontainer and case is well implemented  
        LEFT JOIN {i3_db}.DATA_CONTAINER AS dc
            ON dc.registration_case_number = fact.registration_case_number
            AND dc.registration_case_year = fact.registration_case_year
        LEFT JOIN {i3_db}.DATA_CONTAINER_TYPE AS dc_type
            ON dc_type.id = dc.data_container_type_id
        LEFT JOIN {i3_db}.POLICE_PARTICIPANT AS pp
            ON pp.id = dc.police_participant_id
        
        GROUP BY
            stm.source_entity_id,
            stm.target_entity_id,
            fact.fact_category_id,
            fact.fact_class_id,
            fact.fact_qualification_id,
            fact.is_concrete,
            fact.is_attempt,
            fact.start_date,
            fact.end_date,
            cse.id,
            cse.case_type_id,
            case_type.label_fr
    """)

    final_df = case_offence.join(
        real_offence_label,
        how='left',
        on=real_offence_label['REAL_OFFENCE_LABEL_ID']==case_offence['REAL_OFFENCE_ID']
    )

    final_df = final_df.join(
        case_offence_label,
        how='left',
        on=case_offence_label['CASE_OFFENCE_LABEL_ID']==final_df['CASE_OFFENCE_ID']
    )

    final_df = final_df.join(
        day_of_week,
        how='left',
        on=day_of_week['DAY_ID']==final_df['START_WEEK_DAY_ID']
    ).withColumnRenamed('DAY_LABEL_FR', 'START_WEEK_DAY').withColumnRenamed('DAY_ID', 'START_DAY_ID')

    final_df = final_df.join(
        day_of_week,
        how='left',
        on=day_of_week['DAY_ID']==final_df['END_WEEK_DAY_ID']
    ).withColumnRenamed('DAY_LABEL_FR', 'END_WEEK_DAY').withColumnRenamed('DAY_ID', 'END_DAY_ID')

    final_df = final_df.select(
        *(
            final_df['CASE_OFFENCE_ID'].cast("BIGINT").alias("CASE_OFFENCE_ID"),
            final_df['REAL_OFFENCE_ID'].cast("BIGINT").alias("REAL_OFFENCE_ID"),
            final_df['CASE_OFFENCE_LABEL'].cast("STRING").alias("CASE_OFFENCE_DISPLAY_TITLE"),
            final_df['REAL_OFFENCE_LABEL'].cast("STRING").alias("REAL_OFFENCE_DISPLAY_TITLE"),
            final_df['CATEGORY_ID'].cast("BIGINT").alias("CATEGORY_ID"),
            final_df['CLASS_ID'].cast("BIGINT").alias("CLASS_ID"),
            final_df['QUALIFICATION_ID'].cast("BIGINT").alias("QUALIFICATION_ID"),
            final_df['IS_CONCRETE'].cast("BOOLEAN").alias("IS_CONCRETE"),
            final_df['IS_ATTEMPT'].cast("BOOLEAN").alias("IS_ATTEMPT"),
            final_df['START_DATE_TIME'].cast("TIMESTAMP").alias("START_DATE_TIME"),
            final_df['START_WEEK_DAY'].cast("STRING").alias("START_WEEK_DAY"),
            final_df['END_DATE_TIME'].cast("TIMESTAMP").alias("END_DATE_TIME"),
            final_df['END_WEEK_DAY'].cast("STRING").alias("END_WEEK_DAY"),
            final_df['DOCUMENT_ID'].cast("BIGINT").alias("DOCUMENT_ID"),
            final_df['DOCUMENT_TYPE_ID'].cast("BIGINT").alias("DOCUMENT_TYPE_ID"),
            final_df['DOCUMENT_TYPE'].cast("STRING").alias("DOCUMENT_TYPE"),
            final_df['RECORD_UNIT_ID'].cast("BIGINT").alias("RECORD_UNIT_ID"),
            final_df['RECORD_UNIT'].cast("BIGINT").alias("RECORD_UNIT"),
            final_df['CASE_ID'].cast("BIGINT").alias("CASE_ID"),
            final_df['CASE_TYPE_ID'].cast("BIGINT").alias("CASE_TYPE_ID"),
            final_df['CASE_TYPE'].cast("STRING").alias("CASE_TYPE"),
            final_df['ANG_BNG_ID'].cast("STRING").alias("ANG_BNG_ID")
        )
    )

    return final_df