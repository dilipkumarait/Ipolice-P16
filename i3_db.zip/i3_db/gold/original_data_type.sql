CREATE TABLE ${i3_db}.`ORIGINAL_DATA_TYPE` (
    `ID` BIGINT,
    `LABEL` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

--Filling original_data_type table
INSERT INTO ${i3_db}.ORIGINAL_DATA_TYPE
VALUES 
    (1, 'PV'),
    (2, 'RIR');