CREATE TABLE IF NOT EXISTS ${i3_db}.`FACT_QUALIFICATION` (
    `ID` BIGINT,
    `LEGACY_SOURCE` STRING,
    `LEGACY_TABLE` STRING,
    `LEGACY_ID` BIGINT,
    `LABEL` STRING,
    `LABEL_FR` STRING,
    `LABEL_NL` STRING,
    `LABEL_DE` STRING,
    `LABEL_EN` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

--Filling fact_qualification table
INSERT INTO ${i3_db}.FACT_QUALIFICATION (
    SELECT
        ROW_NUMBER() OVER (ORDER BY qlfkey) AS ID,
        'REFTAB' AS LEGACY_SOURCE,
        'QLF' AS LEGACY_TABLE,
        CAST(qlfkey AS BIGINT) AS LEGACY_ID,
        UPPER(qlfTextBE) AS LABEL,
        qlfTextBF AS LABEL_FR,
        qlfTextBD AS LABEL_NL,
        qlfTextBG AS LABEL_DE,
        qlfTextBE AS LABEL_EN
    FROM ${raw_references}.reftab_rqlf
);
