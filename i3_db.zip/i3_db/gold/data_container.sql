
CREATE TABLE ${i3_db}.`DATA_CONTAINER` (
    `ID` BIGINT,
    `REGISTRATION_CASE_YEAR` INT,
    `REGISTRATION_CASE_NUMBER` BIGINT,
    `DATA_CONTAINER_TYPE_ID` BIGINT,
    `DATA_CONTAINER_STATUS_ID` BIGINT,
    `POLICE_PARTICIPANT_ID` BIGINT
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO  ${i3_db}.`DATA_CONTAINER` (
    SELECT
        mci.case_item_generated_id AS ID,
        cse.case_year AS REGISTRATION_CASE_YEAR,
        cse.case_number AS REGISTRATION_CASE_NUMBER,
        dct.id AS DATA_CONTAINER_TYPE_ID,
        NULL AS DATA_CONTAINER_STATUS_ID,
        pp.id AS POLICE_PARTICIPANT_ID
    FROM ${i3_db_staging}.MAPPING_CASE_ITEMS AS mci
    INNER JOIN ${i3_db_staging}.MAPPING_DATA_CONTAINERS AS mdc
        ON mdc.data_container_staging_id = mci.case_item_staging_id
        AND mci.source_table = "mapping_data_containers"
        AND mci.TARGET_TYPE = mdc.target_type
        AND mdc.TARGET_TYPE = 'DATA CONTAINER PV'
    INNER JOIN ${i3_db}.`CASE` AS cse
        ON cse.id = mdc.case_generated_id
    LEFT JOIN ${raw_questis}.PVF AS pvf
        ON CAST(CONV(pvf.pvtechkey,16,10) AS BIGINT) = mdc.questis_id
        AND mdc.source_table = 'PVF'
    LEFT JOIN ${i3_db}.POLICE_PARTICIPANT AS pp
        ON pvf.pvregisterekode = pp.legacy_id
    CROSS JOIN ${i3_db}.DATA_CONTAINER_TYPE AS dct
    WHERE dct.label = 'PV'

    UNION

    SELECT
        mci.case_item_generated_id AS ID,
        cse.case_year AS REGISTRATION_CASE_YEAR,
        cse.case_number AS REGISTRATION_CASE_NUMBER,
        dct.id AS DATA_CONTAINER_TYPE_ID,
        NULL AS DATA_CONTAINER_STATUS_ID,
        pp.id AS POLICE_PARTICIPANT_ID
    FROM ${i3_db_staging}.MAPPING_CASE_ITEMS AS mci
    INNER JOIN ${i3_db_staging}.MAPPING_DATA_CONTAINERS AS mdc
        ON mdc.data_container_staging_id = mci.case_item_staging_id
        AND mci.source_table = "mapping_data_containers"
        AND mci.target_type = mdc.target_type
        AND mdc.target_type = 'DATA CONTAINER RIR'
    INNER join ${i3_db}.`CASE` AS cse
        ON cse.id = mdc.case_generated_id
    LEFT JOIN ${raw_questis}.RIR AS rir
        ON CAST(CONV(rir.rirtechkey,16,10) AS BIGINT) = mdc.questis_id
        AND mdc.source_table = 'RIR'
    LEFT JOIN ${i3_db}.POLICE_PARTICIPANT AS pp
        ON rir.rirunit = pp.legacy_id
    CROSS JOIN ${i3_db}.DATA_CONTAINER_TYPE AS dct
    WHERE dct.label = 'INFORMATION REPORT'
);

