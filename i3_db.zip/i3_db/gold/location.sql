-------------------------------------------------------------
--- Description: Script used to create the table LOCATION ---
-------------------------------------------------------------

CREATE TABLE ${i3_db}.`LOCATION`
(
    `ID` BIGINT,
    `REGISTRATION_CASE_YEAR` INT,
    `REGISTRATION_CASE_NUMBER` BIGINT,
    `LOCATION_TYPE_ID` BIGINT,
    `NAME` STRING,
    `REGISTRATION_DATE` TIMESTAMP,
    `FREE_DESCRIPTION` STRING,
    `LOCATION_DESCRIPTION_ID` BIGINT,
    `ADDRESS_HOUSE_NR` INT,
    `ADDRESS_COUNTRY_ID` BIGINT,
    `ADDRESS_MUNICIPALITY_ID` BIGINT,
    `ADDRESS_SUB_MUNICIPALITY_ID` BIGINT,
    `ADDRESS_POSTAL_CODE_ID` BIGINT,
    `ADDRESS_STREET_ID` BIGINT,
    `SHAPE_TYPE_ID` BIGINT,
    `SHAPE_WKT` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.`LOCATION` (
    SELECT
        e.id AS ID,
        e.registration_case_year AS REGISTRATION_CASE_YEAR,
        e.registration_case_number AS REGISTRATION_CASE_NUMBER,
        e.entity_sub_type_id AS LOCATION_TYPE_ID,
        e.name AS NAME,
        e.registration_date AS REGISTRATION_DATE,
        CAST(NULL AS STRING) AS FREE_DESCRIPTION,
        CAST(NULL AS BIGINT) AS LOCATION_DESCRIPTION_ID,
        NULL AS ADDRESS_HOUSE_NR,
        NULL AS ADDRESS_COUNTRY_ID,
        NULL AS ADDRESS_MUNICIPALITY_ID,
        NULL AS ADDRESS_SUB_MUNICIPALITY_ID,
        NULL AS ADDRESS_POSTAL_CODE_ID,
        NULL AS ADDRESS_STREET_ID,
        1 AS SHAPE_TYPE_ID,
        CAST(NULL AS STRING) AS SHAPE_WKT
    FROM ${i3_db}.`ENTITY` e
    WHERE e.entity_type_id = 2
);