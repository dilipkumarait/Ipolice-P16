-----------------------------------------------------------
-- Description: Create and add data to table references ---
-----------------------------------------------------------

CREATE TABLE ${i3_db}.`REFERENCE` (
    `ID` BIGINT,
    `REGISTRATION_CASE_YEAR` INT,
    `REGISTRATION_CASE_NUMBER` BIGINT,
    `NAME` STRING,
    `IS_CASE_ENTITY` BOOLEAN,
    `REGISTRATION_DATE` TIMESTAMP,
    `REFERENCE_TYPE_ID` BIGINT,
    `NUMBER_TYPE_ID` BIGINT,
    `REFERENCE_ADDRESS` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

--Filling reference with licence_plate
INSERT INTO ${i3_db}.`REFERENCE` (
    SELECT
        o.id AS ID,
        o.registration_case_year AS REGISTRATION_CASE_YEAR,
        o.registration_case_number AS REGISTRATION_CASE_NUMBER,
        o.name AS NAME,
        o.is_case_entity AS IS_CASE_ENTITY,
        o.registration_date AS REGISTRATION_DATE,
        o.object_type_id AS REFERENCE_TYPE_ID,
        CAST(NULL AS BIGINT) AS NUMBER_TYPE_ID,
        CAST(NULL AS STRING) AS REFERENCE_ADDRESS
    FROM ${i3_db}.`OBJECT` o
    WHERE o.object_type_id in (13,12,14)
);
