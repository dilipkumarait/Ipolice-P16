CREATE TABLE ${i3_db}.`INFORMATION_CATEGORY` (
     `ID` BIGINT,
     `LABEL` STRING,
     `LABEL_FR` STRING,
     `LABEL_NL` STRING,
     `LABEL_DE` STRING,
     `LABEL_EN` STRING,
     `DESCRIPTION_FR` STRING,
     `DESCRIPTION_NL` STRING,
     `DESCRIPTION_DE` STRING,
     `DESCRIPTION_EN` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.INFORMATION_CATEGORY VALUES
  (1, 'CAT. 1', 'Catégorie 1', 'Categorie 1', 'Kategorie 1', 'Category 1', "Entités conformes aux règles de saisie de l’ANG/BNG (au sens de la LPA/WPA).", NULL, NULL, NULL),
  (2, 'CAT. 2', 'Catégorie 2', 'Categorie 2', 'Kategorie 2', 'Category 2', "Entités qui peuvent être temporairement partagées. Pour une enquête, ces entités doivent changer de catégorie lors de la clôture (ou être supprimées).", NULL, NULL, NULL),
  (3, 'CAT. 3', 'Catégorie 3', 'Categorie 3', 'Kategorie 3', 'Category 3', "Entités « marginales », pouvant être associées au dossier. Pour une enquête, ces entités sont « partageables » jusqu''à la clôture de l''enquête.", NULL, NULL, NULL),
  (4, 'CAT. 4', 'Catégorie 4', 'Categorie 4', 'Kategorie 4', 'Category 4', "Entités qui ne sont pertinentes que dans le dossier lui-même et ne doivent pas être partagées en dehors du dossier.", NULL, NULL, NULL),
  (5, 'CAT. 5', 'Catégorie 5', 'Categorie 5', 'Kategorie 5', 'Category 5', "Entités qui, dans le contexte de la « Privacy » sont sensibles et qui, pour des entités cibles spécifiques, peuvent/ devraient toujours être partagées.", NULL, NULL, NULL)