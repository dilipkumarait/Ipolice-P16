CREATE TABLE ${i3_db}.`FIREARM` (
    `ID` BIGINT,
    `REGISTRATION_CASE_YEAR` INT,
    `REGISTRATION_CASE_NUMBER` BIGINT,
    `NAME` STRING,
    `IS_CASE_ENTITY` BOOLEAN,
    `REGISTRATION_DATE` TIMESTAMP,
    `CREATION_YEAR` INT,
    `SERIAL_NUMBER` INT,
    `FIREARM_MAKE_ID` BIGINT,
    `FIREARM_MODEL_ID` BIGINT
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.`FIREARM` (
    SELECT
    wp.id AS ID,
    wp.registration_case_year AS REGISTRATION_CASE_YEAR,
    wp.registration_case_number AS REGISTRATION_CASE_NUMBER,
    wp.name AS NAME,
    wp.is_case_entity AS IS_CASE_ENTITY,
    wp.registration_date AS REGISTRATION_DATE,
    wp.creation_year AS CREATION_YEAR,
    NULL AS SERIAL_NUMBER,
    CASE
        WHEN TRIM(gvw.gvwmerk) = make.label THEN make.id
    END AS FIREARM_MAKE_ID,
    CASE
        WHEN TRIM(gvw.gvwtype) = model.label THEN model.id
    END AS FIREARM_MODEL_ID
    FROM ${i3_db}.`WEAPON` wp
    INNER JOIN ${i3_db_staging}.mapping_case_items AS mci
        ON mci.CASE_ITEM_GENERATED_ID = wp.id
        AND mci.source_table = "mapping_case_entities"
    INNER JOIN ${i3_db_staging}.mapping_case_entities mce
        ON mce.CASE_ENTITY_STAGING_ID = mci.CASE_ITEM_STAGING_ID
        AND mce.TARGET_TYPE = mci.TARGET_TYPE
        AND mce.TARGET_TYPE = "FIREARM"
    INNER JOIN ${raw_questis}.`gvw` gvw 
        ON CAST(CONV(gvw.GVWNCDBKEY,16,10) AS BIGINT) = mce.QUESTIS_ID
    LEFT JOIN ${i3_db}.`FIREARM_MAKE` make
        ON gvw.gvwmerk = make.label
    LEFT JOIN ${i3_db}.`FIREARM_MODEL` model
        ON gvw.gvwtype = model.label
    WHERE wp.weapon_type_id = 23
);
