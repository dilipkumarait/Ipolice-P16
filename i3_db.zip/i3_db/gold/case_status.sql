CREATE TABLE ${i3_db}.`CASE_STATUS` (
    `ID` BIGINT,
    `LABEL` STRING,
    `LABEL_FR` STRING,
    `LABEL_NL` STRING,
    `LABEL_DE` STRING,
    `LABEL_EN` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.CASE_STATUS VALUES
  (1, 'DRAFT',"Ebauche", NULL, NULL, 'Draft'),
  (2, 'ACTIVE', "Actif", NULL, NULL, 'Active'),
  (3, 'CLOSED', "Clôturé", NULL, NULL, 'Closed'),
  (4, 'ARCHIVED', "Archivé", NULL, NULL, 'Archived')
