
CREATE TABLE ${i3_db}.`FIREARM_MAKE` (
    `ID` BIGINT,
    `LABEL` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');


INSERT INTO ${i3_db}.`FIREARM_MAKE` (
    SELECT
        ROW_NUMBER() OVER (ORDER BY gvwmerk) AS ID,
        gvwmerk AS LABEL
    FROM (
	    SELECT DISTINCT TRIM(gvwmerk) AS gvwmerk
            FROM ${raw_questis}.`gvw`
    ) AS `gvwmerk`
    ORDER BY gvwmerk
);
