CREATE TABLE IF NOT EXISTS ${i3_db}.`ENTITY_TO_LEGACY` (
    `ID` BIGINT,
    `ENTITY_ID` BIGINT,
    `LEGACY_SOURCE` STRING,
    `LEGACY_TABLE` STRING,
    `LEGACY_ID` BIGINT 
)
STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

--Filling entity_to_legacy table
INSERT INTO ${i3_db}.ENTITY_TO_LEGACY (
  
    SELECT
        ROW_NUMBER() OVER (ORDER BY e.id) AS ID,
        e.id AS ENTITY_ID,
        'QUESTIS' AS LEGACY_SOURCE,
        CASE
            WHEN mce.source_table = 'EF1' THEN 'FEI'
            WHEN mce.source_table = 'EP1' THEN 'GPS'
            WHEN mce.source_table = 'EM1' THEN 'GVM'
            WHEN mce.source_table = 'EW1' THEN 'GVW'
            WHEN mce.source_table = 'EN1' THEN 'NUM'
        END AS LEGACY_TABLE,
        mce.questis_id AS LEGACY_ID
    FROM ${i3_db}.ENTITY AS e
    INNER JOIN ${i3_db_staging}.mapping_case_items AS mci
        ON e.id = mci.case_item_generated_id
        AND mci.source_table = "mapping_case_entities"
    INNER JOIN ${i3_db_staging}.mapping_case_entities mce
        ON mci.case_item_staging_id = mce.case_entity_staging_id
    WHERE mci.target_type in ('NATURAL PERSON', 'FIREARM', 'OFFENCE', 'PHONE NUMBER', 'EMAIL ADDRESS', 'DRUG')
);