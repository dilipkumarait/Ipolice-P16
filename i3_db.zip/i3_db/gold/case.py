from pyspark.sql.functions import monotonically_increasing_id, col


def load_table(sparkSession, conf_variables):
    i3_db = conf_variables["i3_db"]
    # Add Cases
    case_ond = add_case_ond(sparkSession, conf_variables)
    case_rir = add_case_rir(sparkSession, conf_variables)
    case_pv = add_case_pv(sparkSession, conf_variables)

    # Merge all cases
    cases = case_ond.union(case_rir).union(case_pv)
    
    # Create confidentiality level mapping dataframe
    sparkSession.sql(f"USE {i3_db}")
    i3_confidentiality_level = sparkSession.read.table('CASE_CONFIDENTIALITY')
    i3_confidentiality_level = i3_confidentiality_level.select(
        *(  
            i3_confidentiality_level['ID'].cast('BIGINT').alias('CASE_CONFIDENTIALITY_ID'),
            i3_confidentiality_level['LABEL'].cast('STRING').alias('LABEL')
        )
    )
    
    confidentiality_mapping = sparkSession.createDataFrame(
        [
            (1, 'A'),
            (2, 'B'),
            (3, 'C'),
            (4, 'D')
        ],
        ['QUESTIS_CONFIDENTIALITY_LEVEL', 'I3_CONFIDENTIALITY_LEVEL']
    )

    cases = cases.join(
        confidentiality_mapping,
        how='left',
        on=confidentiality_mapping['QUESTIS_CONFIDENTIALITY_LEVEL']==cases['CONFIDENTIALITY']
    ).join(
        i3_confidentiality_level,
        how='left',
        on=i3_confidentiality_level['LABEL']==confidentiality_mapping['I3_CONFIDENTIALITY_LEVEL']
    ).withColumn("CASE_NUMBER", monotonically_increasing_id())
    cases=cases.select(
        cases['ID'].cast('BIGINT').alias('ID'),
        cases['CASE_YEAR'].cast('INT').alias('CASE_YEAR'),
        cases['CASE_NUMBER'].cast('BIGINT').alias('CASE_NUMBER'),
        cases['CASE_TYPE_ID'].cast('BIGINT').alias('CASE_TYPE_ID'),
        cases['CASE_CONFIDENTIALITY_ID'].cast('BIGINT').alias('CASE_CONFIDENTIALITY_ID'),
        cases['CREATION_DATE'].cast('DATE').alias('CREATION_DATE'),
        cases['LAST_MODIFICATION_TIME'].cast('TIMESTAMP').alias('LAST_MODIFICATION_TIME')
    )
    
    return cases


def add_case_ond(sparkSession, conf_variables):
    i3_db = conf_variables["i3_db"]
    i3_db_staging = conf_variables["i3_db_staging"]
    raw_questis = conf_variables["raw_questis"]

    # load case from ond
    case_ond = sparkSession.sql(f"""
        SELECT DISTINCT
            mc.CASE_GENERATED_ID AS ID,
            CAST(SUBSTR(ond.ondbegindate, 0, 4) AS INT) AS CASE_YEAR,
            DATE(
                CONCAT(
                    SUBSTR(ond.ondbegindate, 0, 4),"-",
                    SUBSTR(ond.ondbegindate, 5, 2),"-",
                    SUBSTR(ond.ondbegindate, 7, 2)
                )
            ) AS CREATION_DATE,
            case_type.id AS CASE_TYPE_ID,
            CAST(ond.ondembargo AS INT) AS CONFIDENTIALITY,
            from_unixtime(unix_timestamp(ond.ondtechts ,'yyyyMMddHHmmss')) AS LAST_MODIFICATION_TIME       
        FROM {i3_db_staging}.MAPPING_CASES AS mc
        JOIN {raw_questis}.OND AS ond
            ON CAST(CONV(ond.ondncdbkey,16,10) AS BIGINT) = mc.QUESTIS_ID 
            AND mc.SOURCE_TABLE = "OND"
        CROSS JOIN {i3_db}.CASE_TYPE AS case_type
        WHERE case_type.label = 'CRIMINAL INVESTIGATION CASE'
            AND ond.ondtechts = (SELECT MAX(ondi.ondtechts) FROM {raw_questis}.OND AS ondi WHERE CAST(CONV(ondi.ondncdbkey,16,10) AS BIGINT) = mc.QUESTIS_ID)
       
    """)
    return case_ond


def add_case_rir(sparkSession, conf_variables):
    i3_db = conf_variables["i3_db"]
    i3_db_staging = conf_variables["i3_db_staging"]
    raw_questis = conf_variables["raw_questis"]

    #load case from rir
    # RIR linked to a fact through rf1 (association) table
    case_rir = sparkSession.sql(f"""
       SELECT DISTINCT
            mc.CASE_GENERATED_ID AS ID,
            MIN(CAST(SUBSTR(fei.feibegindate, 0, 4) AS INT)) AS CASE_YEAR,
            MIN(DATE(
                CONCAT(
                    SUBSTR(fei.feibegindate, 0, 4),"-",
                    SUBSTR(fei.feibegindate, 5, 2),"-",
                    SUBSTR(fei.feibegindate, 7, 2)
                )
            )) AS CREATION_DATE,
            case_type.id AS CASE_TYPE_ID,
            1 AS CONFIDENTIALITY,
            NULL AS LAST_MODIFICATION_TIME
        FROM {i3_db_staging}.MAPPING_CASES AS mc
        JOIN {raw_questis}.RF1 rf1
            ON CAST(CONV(rf1.rf1rirtechkey,16,10) AS BIGINT) = mc.QUESTIS_ID 
            AND mc.SOURCE_TABLE = "RIR"
        JOIN {raw_questis}.FEI AS fei
            ON rf1.rf1feincdbkey  = fei.feincdbkey 
        JOIN {raw_questis}.RIR AS rir
            ON CAST(CONV(rir.rirtechkey,16,10) AS BIGINT) = mc.QUESTIS_ID
        CROSS JOIN {i3_db}.CASE_TYPE AS case_type
        WHERE case_type.label = 'NON CONCRETE OFFENCE CASE'
        GROUP BY mc.CASE_GENERATED_ID, case_type.id

        """)
    return case_rir


def add_case_pv(sparkSession, conf_variables):
    i3_db = conf_variables["i3_db"]
    i3_db_staging = conf_variables["i3_db_staging"]
    raw_questis = conf_variables["raw_questis"]

    # Load case from pv
    case_pv = sparkSession.sql(f"""
        SELECT DISTINCT
            mc.CASE_GENERATED_ID AS ID,
            MIN(CAST(SUBSTR(fei.feibegindate, 0, 4) AS INT)) AS CASE_YEAR,
            MIN(DATE(
                CONCAT(
                    SUBSTR(fei.feibegindate, 0, 4),"-",
                    SUBSTR(fei.feibegindate, 5, 2),"-",
                    SUBSTR(fei.feibegindate, 7, 2)
                )
            )) AS CREATION_DATE,
            case_type.id AS CASE_TYPE_ID,
            1 AS CONFIDENTIALITY,
            NULL AS LAST_MODIFICATION_TIME
        FROM {i3_db_staging}.MAPPING_CASES AS mc
        JOIN {raw_questis}.PF1 AS pf1
            ON cast(conv(pf1.pf1pvtechkey,16,10) AS BIGINT) = mc.questis_id 
            AND mc.SOURCE_TABLE = "PVF"
        JOIN {raw_questis}.FEI AS fei
            ON pf1.pf1feincdbkey = fei.feincdbkey 
        JOIN {raw_questis}.PVF AS pvf
            ON CAST(CONV(pvf.pvtechkey,16,10) AS BIGINT) = mc.questis_id
        CROSS JOIN {i3_db}.CASE_TYPE AS case_type
        WHERE case_type.label = 'OFFENCE CASE'
        GROUP BY mc.CASE_GENERATED_ID, case_type.id
    """)

    return case_pv
