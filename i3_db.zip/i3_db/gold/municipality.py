#-----------------------------------------------------------------
#-- Description: Create and add data to table municipality  ------
#-----------------------------------------------------------------
from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):

    raw_references = conf_variables['raw_references']

    query = f"""
    SELECT
        "REFTAB" AS LEGACY_SOURCE,
        "MUN" AS LEGACY_TABLE,
        CAST(mun.munkey as BIGINT) AS LEGACY_ID,
        UPPER(CAST(mun.muntextbe AS STRING)) AS LABEL,
        CAST(mun.muntextbf AS STRING) AS LABEL_FR,
        CAST(mun.muntextbd AS STRING) AS LABEL_NL,
        CAST(mun.muntextbg AS STRING) AS LABEL_DE,
        CAST(mun.muntextbe AS STRING) AS LABEL_EN
    FROM {raw_references}.reftab_rmun mun
        
      """

    municipality = sparkSession.sql(query)
    municipality = municipality.withColumn("ID", monotonically_increasing_id())

    return municipality
