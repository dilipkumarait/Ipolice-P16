CREATE TABLE IF NOT EXISTS ${i3_db}.`DRUG_CATEGORY` (
    `ID` BIGINT,
    `LEGACY_SOURCE` STRING,
    `LEGACY_TABLE` STRING,
    `LEGACY_ID` BIGINT,
    `LABEL` STRING,
    `LABEL_FR` STRING,
    `LABEL_NL` STRING,
    `LABEL_DE` STRING,
    `LABEL_EN` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

--Filling drug_category table
INSERT INTO ${i3_db}.DRUG_CATEGORY (
    SELECT
        ROW_NUMBER() OVER (ORDER BY kagkey) AS ID,
        'REFTAB' AS LEGACY_SOURCE,
        'KAG' AS LEGACY_TABLE,
        CAST(kagkey AS BIGINT) AS LEGACY_ID,
        UPPER(kagtextbe) AS LABEL,
        kagtextbf AS LABEL_FR,
        kagtextbd AS LABEL_NL,
        kagtextbg AS LABEL_DE,
        kagtextbe AS LABEL_EN
    FROM ${raw_references}.reftab_rkag
    WHERE CAST(kagkey AS BIGINT) IN (18, 90)
);