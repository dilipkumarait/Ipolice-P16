
from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    
    raw_references = conf_variables['raw_references']

    query = f"""
    SELECT
        "REFTAB" AS LEGACY_SOURCE,
        "PRV" AS LEGACY_TABLE,
        CAST(prv.prvkey AS BIGINT) AS LEGACY_ID,
        UPPER(CAST(prv.prvtextbe AS STRING)) AS LABEL,
        CAST(prv.prvtextbf AS STRING) AS LABEL_FR,
        CAST(prv.prvtextbd AS STRING) AS LABEL_NL,
        CAST(prv.prvtextbg AS STRING) AS LABEL_DE,
        CAST(prv.prvtextbe AS STRING) AS LABEL_EN
    FROM {raw_references}.reftab_rprv prv
        
      """

    province = sparkSession.sql(query)
    province = province.withColumn("ID", monotonically_increasing_id())

    return province
