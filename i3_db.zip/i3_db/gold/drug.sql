
CREATE TABLE ${i3_db}.`DRUG` (
    `ID` BIGINT,
    `REGISTRATION_CASE_YEAR` INT,
    `REGISTRATION_CASE_NUMBER` BIGINT,
    `NAME` STRING,
    `IS_CASE_ENTITY` BOOLEAN,
    `REGISTRATION_DATE` TIMESTAMP,
    `DRUG_TYPE_ID` BIGINT,
    `QUANTITY` FLOAT
)
STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');


INSERT INTO ${i3_db}.DRUG (
    SELECT
        obj.id AS ID,
        obj.registration_case_year AS REGISTRATION_CASE_YEAR,
        obj.registration_case_number AS REGISTRATION_CASE_NUMBER,
        rklg.klgtextbe AS NAME,
        obj.is_case_entity AS IS_CASE_ENTITY,
        obj.registration_date AS REGISTRATION_DATE,
        gvw.gvwclasse AS DRUG_TYPE_ID,
        CAST(NULL AS INT) AS QUANTITY
    FROM ${i3_db}.OBJECT AS obj
    INNER JOIN ${i3_db_staging}.mapping_case_items AS mci
        ON mci.CASE_ITEM_GENERATED_ID = obj.ID
        AND mci.source_table = "mapping_case_entities"
    INNER JOIN ${i3_db_staging}.mapping_case_entities mce
        ON mce.CASE_ENTITY_STAGING_ID = mci.CASE_ITEM_STAGING_ID 
        AND mce.TARGET_TYPE = mci.TARGET_TYPE
        AND mce.TARGET_TYPE = "DRUG"
        AND mce.SOURCE_TABLE = "EW1" 
    INNER JOIN ${raw_questis}.gvw AS gvw
       ON cast(conv(gvwncdbkey, 16, 10) as bigint) = mce.QUESTIS_ID
    LEFT JOIN ${raw_references}.reftab_rklg as rklg
        ON rklg.klgkey = gvw.gvwclasse
    WHERE obj.object_type_id = 20
)