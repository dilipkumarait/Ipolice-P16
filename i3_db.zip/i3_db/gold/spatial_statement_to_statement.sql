-----------------------------------------------------------------
-- Description: Add spatial_statement data to statement table  --
-----------------------------------------------------------------

INSERT INTO ${i3_db}.STATEMENT (
    SELECT
        ID,
        REGISTRATION_CASE_YEAR,
        REGISTRATION_CASE_NUMBER,
        4 AS STATEMENT_TYPE_ID,
        SPATIAL_STATEMENT_TYPE_ID AS STATEMENT_SUBTYPE_ID,
        REGISTRATION_DATE,
        RELIABILITY AS RELIABILITY_ID,
        START_DATE AS START_DATE_TIME,
        END_DATE AS END_DATE_TIME,
        SOURCE_ENTITY_ID,
        SOURCE_ENTITY_TYPE_ID,
        SOURCE_ENTITY_SUB_TYPE_ID,
        TARGET_ENTITY_ID,
        TARGET_ENTITY_TYPE_ID,
        TARGET_ENTITY_SUB_TYPE_ID,
        1 AS STATEMENT_STATUS_ID

    FROM ${i3_db}.SPATIAL_STATEMENT
)