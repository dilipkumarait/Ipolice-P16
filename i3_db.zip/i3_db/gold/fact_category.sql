CREATE TABLE IF NOT EXISTS ${i3_db}.`FACT_CATEGORY` (
    `ID` BIGINT,
    `LEGACY_SOURCE` STRING,
    `LEGACY_TABLE` STRING,
    `LEGACY_ID` BIGINT,
    `LABEL` STRING,
    `LABEL_FR` STRING,
    `LABEL_NL` STRING,
    `LABEL_DE` STRING,
    `LABEL_EN` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

--Filling fact_category table
INSERT INTO ${i3_db}.FACT_CATEGORY (
    SELECT
        ROW_NUMBER() OVER (ORDER BY kafkey) AS ID,
        'REFTAB' AS LEGACY_SOURCE,
        'KAF' AS LEGACY_TABLE,
        CAST(kafkey AS BIGINT) AS LEGACY_ID,
        UPPER(kafTextBE) AS LABEL,
        kafTextBF AS LABEL_FR,
        kafTextBD AS LABEL_NL,
        kafTextBG AS LABEL_DE,
        kafTextBE AS LABEL_EN
    FROM ${raw_references}.reftab_rkaf
);
