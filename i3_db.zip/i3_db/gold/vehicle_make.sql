-----------------------------------------------------------
-- Description: Create and add data to table VEHICLE_MAKE -
-----------------------------------------------------------
CREATE TABLE IF NOT EXISTS ${i3_db}.`VEHICLE_MAKE` (
    `ID` BIGINT,
    `LEGACY_SOURCE` STRING,
    `LEGACY_TABLE` STRING,
    `LEGACY_ID` BIGINT,
    `LABEL` STRING,
    `LABEL_FR` STRING,
    `LABEL_NL` STRING,
    `LABEL_DE` STRING,
    `LABEL_EN` STRING
    
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

--Filling Vehicle_make table
INSERT INTO ${i3_db}.VEHICLE_MAKE (
    SELECT
        ROW_NUMBER() OVER (ORDER BY mvmkey) AS ID,
        'REFTAB' AS LEGACY_SOURCE,
        'MVM' AS LEGACY_TABLE,
        CAST(mvmkey AS BIGINT) AS LEGACY_ID,
        UPPER(mvmtextbe) AS LABEL,
        mvmtextbf AS LABEL_FR,
        mvmtextbd AS LABEL_NL,
        mvmtextbg AS LABEL_DE,
        mvmtextbe AS LABEL_EN
    FROM ${raw_references}.reftab_rmvm
);