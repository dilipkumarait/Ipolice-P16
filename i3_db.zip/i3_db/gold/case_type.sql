CREATE TABLE ${i3_db}.`CASE_TYPE` (
    `ID` BIGINT,
    `LABEL` STRING,
    `LABEL_FR` STRING,
    `LABEL_NL` STRING,
    `LABEL_DE` STRING,
    `LABEL_EN` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.CASE_TYPE VALUES
  (1, 'OFFENCE CASE', "Dossier d'offense", "Inbreukdossier", NULL, "Offence case"),
  (2, 'INFORMATION MONITORING CASE', "Dossier de suivi des informations", NULL, NULL, 'Information monitoring case'),
  (3, 'INFORMATION GATHERING CASE', "Dossier de rassemblement des informations", NULL, NULL, 'Information gathering case'),
  (4, 'INFORMATION REGISTRATION CASE', "Dossier d'enregistrement des informations", NULL, NULL, 'Information registration case'),
  (5, 'INTERVENTION SUPPORT CASE', "Dossier de soutient à l'interventiobn", NULL, NULL, 'Intervention support case'),
  (6, 'POLICE INTERVENTION CASE', "Dossier d'intervention policière", NULL, NULL, 'Police intervention case'),
  (7, 'REALTIME INTELLIGENCE CASE', "Dossier d'intelligence en temps réel", NULL, NULL, 'Realtime intelligence case'),
  (8, 'CRIMINAL INVESTIGATION CASE', "Dossier d'investigation criminelle", NULL, NULL, 'Criminal investigation case'),
  (9, 'ELEMENT MONITORING CASE', "Dossier de suivi des éléments", NULL, NULL, 'Element monitoring case'),
  (10, 'FRONT OFFICE CASE', 'Dossier de front office', NULL, NULL, 'Front office case'),
  (11, 'ANNOUNCEMENT CASE', "Dossier d'annonce", NULL, NULL, 'Announcement case'),
  (12, 'NOTIFICATION REGISTRATION CASE', "Dossier d'enregistrement des notifications", NULL, NULL, 'Notification registration case'),
  (13, 'RECEPTION CASE', 'Dossier de réception', NULL, NULL, 'Reception case'),
  (14, 'CALL TAKING CASE', "Dossier de prise d'appel", NULL, NULL, 'Call taking case'),
  (15, 'NON CONCRETE OFFENCE CASE', "Dossier d'offense non concrète", NULL, NULL, 'Non concrete offence case'),
  (16, 'EXTERNAL DISTRIBUTION CASE', 'Dossier de distribution extérieure', NULL, NULL, 'External distribution case'),
  (17, 'SCANNING FOR POTENTIAL ELEMENTS TO BE MONITORED CASE', 'Dossier de balayage de potentiels éléments à surveiller', NULL, NULL, 'Scanning for potential elements to be monitored case'),
  (18, 'SCANNING FOR POTENTIAL ENTITY TO BE MONITORED CASE', 'Dossier de balayage de potentielles entités à surveiller', NULL, NULL, 'Scanning for potential entity to be monitored case'),
  (19, 'SCANNING FOR POTENTIAL PHENOMENON TO BE MONITORED CASE', 'Dossier de balayge de potentiels phénomènes à surveiller', NULL, NULL, 'Scanning for potential phenomenon to be monitored case'),
  (20, 'ANALYSE POTENTIAL ELEMENT TO BE MONITORED CASE', "Dossier d'analyse des éléments potentiels à suivre", NULL, NULL, 'Analyse potential element to be monitored case'),
  (21, 'PHENOMENON MONITORING CASE', 'Dossier de suivi des phénomènes', NULL, NULL, 'Phenomenon monitoring case'),
  (22, 'GROUP MONITORING CASE', 'Dossier de suivi des groupes', NULL, NULL, 'Group monitoring case'),
  (23, 'PERSON MONITORING CASE', 'Dossier de suivi des personnes', NULL, NULL, 'Person monitoring case'),
  (24, 'LOCATION MONITORING CASE', 'Dossier de suivi des locations', NULL, NULL, 'Location monitoring case')