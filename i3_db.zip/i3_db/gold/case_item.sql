-----------------------------------------------------------
-- Description: Script used to create the table Case_item -
-----------------------------------------------------------

CREATE TABLE ${i3_db}.`CASE_ITEM` (
    ID BIGINT,
    REGISTRATION_CASE_NUMBER BIGINT,
    REGISTRATION_CASE_YEAR INT,
    REGISTRATION_DATE TIMESTAMP
)
STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.`CASE_ITEM` (
    SELECT
        mci.CASE_ITEM_GENERATED_ID AS ID,
        cse.case_number AS REGISTRATION_CASE_NUMBER,
        cse.case_year AS REGISTRATION_CASE_YEAR,
        cse.creation_date AS REGISTRATION_DATE
    FROM ${i3_db_staging}.mapping_case_items AS mci
    INNER JOIN ${i3_db}.`CASE` cse
        ON cse.ID = mci.CASE_GENERATED_ID
    
)
