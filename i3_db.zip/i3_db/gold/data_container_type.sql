CREATE TABLE IF NOT EXISTS ${i3_db}.`DATA_CONTAINER_TYPE` (
    ID BIGINT,
    LABEL STRING,
    LABEL_FR STRING,
    LABEL_NL STRING,
    LABEL_DE STRING,
    LABEL_EN STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.`DATA_CONTAINER_TYPE`
VALUES 
(1, 'PV', 'PV (procès-verbal)', NULL, NULL, 'PV'),
(2, 'INFORMATION REPORT', "Rapport d'information", NULL, NULL, 'Information report'),
(3, 'MIGRATION RECORD', 'Enregistrement de migration', NULL, NULL, 'Migration record'),
(4, 'NOTIFICATION', 'Notification', 'Melding', NULL, 'Notification'),
(5, 'INTELLIGENCE PRODUCT', "Produit d'intelligence", NULL, NULL, 'Intelligence product'),
(6, 'INTERVENTION FICHE', "Fiche d'intervention", NULL, NULL, 'Intervention fiche')
;