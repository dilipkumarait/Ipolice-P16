-----------------------------------------------------------
-- Description: Create and add data to table entity_type --
-----------------------------------------------------------

CREATE TABLE ${i3_db}.`ENTITY_TYPE` (
    `ID` BIGINT,
    `LABEL` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.`ENTITY_TYPE`
VALUES (1, 'PERSON'), (2, 'LOCATION'), (3, 'EVENT'), (4, 'OBJECT'), (5, 'PHENOMENON');