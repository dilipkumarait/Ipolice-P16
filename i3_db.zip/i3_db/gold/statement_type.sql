-----------------------------------------------------------
-- Description: Create and add data to table statement_type --
-----------------------------------------------------------

CREATE TABLE ${i3_db}.`STATEMENT_TYPE` (
    ID BIGINT,
    LABEL STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.`STATEMENT_TYPE`
VALUES (1, 'CLASSIFICATION'),
       (2, 'RELATION'),
       (3, 'ATTRIBUTE'),
       (4, 'SPATIAL_STATEMENT'),
       (5, 'DEDUCED_STATEMENT');