CREATE TABLE IF NOT EXISTS ${i3_db}.`LANGUAGE` (
    `ID` BIGINT,
    `LEGACY_SOURCE` STRING,
    `LEGACY_TABLE` STRING,
    `LEGACY_ID` BIGINT,
    `LABEL` STRING,
    `LABEL_FR` STRING,
    `LABEL_NL` STRING,
    `LABEL_DE` STRING,
    `LABEL_EN` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

--Filling Language table
INSERT INTO ${i3_db}.LANGUAGE (
    SELECT
        ROW_NUMBER() OVER (ORDER BY tngkey) AS ID,
        'REFTAB' AS LEGACY_SOURCE,
        'TNG' AS LEGACY_TABLE,
        CAST(tngkey AS BIGINT) AS LEGACY_ID,
        UPPER(tngtextbe) AS LABEL,
        tngtextbf AS LABEL_FR,
        tngtextbd AS LABEL_NL,
        tngtextbg AS LABEL_DE,
        tngtextbe AS LABEL_EN
    FROM ${raw_references}.reftab_rtng
);