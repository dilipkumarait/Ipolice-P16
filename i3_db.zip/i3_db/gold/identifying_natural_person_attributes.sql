
CREATE TABLE ${i3_db}.`IDENTIFYING_NATURAL_PERSON_ATTRIBUTES` (
    `ID` BIGINT,
    `REGISTRATION_CASE_YEAR` INT,
    `REGISTRATION_CASE_NUMBER` BIGINT,
    `NATURAL_PERSON_ID` BIGINT,
    `BIRTH_MUNICIPALITY_ID` BIGINT,
    `REGISTRATION_DATE` TIMESTAMP,
    `RELIABILITY_ID` BIGINT,
    `START_DATE` TIMESTAMP,
    `END_DATE` TIMESTAMP,
    `FIRST_NAME` STRING,
    `LAST_NAME` STRING,
    `DATE_OF_BIRTH` TIMESTAMP,
    `GENDER_ID` BIGINT,
    `NATIONAL_REGISTRATION_NUMBER` STRING,
    `IMMIGRATION_OFFICE_NUMBER` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.`IDENTIFYING_NATURAL_PERSON_ATTRIBUTES` (
    SELECT
        mci.CASE_ITEM_GENERATED_ID AS ID,
        pprs.registration_case_year AS REGISTRATION_CASE_YEAR,
        pprs.registration_case_number AS REGISTRATION_CASE_NUMBER,
        pprs.id AS NATURAL_PERSON_ID,
        NULL AS BIRTH_MUNICIPALITY_ID,
        pprs.registration_date AS REGISTRATION_DATE,
        NULL AS RELIABILITY_ID,
        NULL AS START_DATE,
        NULL AS END_DATE,
        gps.gpsfirstname AS FIRSTNAME,
        gps.gpslastname AS LASTNAME,
        DATE(
            CONCAT(
                    gps.gpsbirthyear,"-",
                    gps.gpsbirthmonth,"-",
                    gps.gpsbirthday
            )
        ) AS DATE_OF_BIRTH,
        gender.id AS GENDER_ID,
        CAST(gps.gpsnrnr AS STRING) AS NATIONAL_REGISTRATION_NUMBER,
        CAST(gps.gpsvreemdzakennr AS STRING) AS IMMIGRATION_OFFICE_NUMBER
    FROM ${i3_db_staging}.MAPPING_CASE_ITEMS AS mci
    INNER JOIN ${i3_db_staging}.MAPPING_ATTRIBUTES AS ma
        ON  mci.CASE_ITEM_STAGING_ID = ma.ATTRIBUTE_STAGING_ID
        AND mci.TARGET_TYPE = ma.TARGET_TYPE
        AND mci.TARGET_TYPE = "IDENTIFYING NATURAL PERSON ATTRIBUTES"
    INNER JOIN ${raw_questis}.GPS AS gps
        ON CAST(CONV(gps.GPSNCDBKEY,16,10) AS BIGINT) = ma.QUESTIS_ID
    INNER JOIN ${i3_db_staging}.MAPPING_CASE_ITEMS AS mci2
        ON mci2.CASE_ITEM_STAGING_ID= ma.CASE_ENTITY_STAGING_ID
        AND mci2.TARGET_TYPE= 'NATURAL PERSON'
    INNER JOIN ${i3_db}.NATURAL_PERSON AS pprs
        ON mci2.CASE_ITEM_GENERATED_ID = pprs.id
    INNER JOIN ${i3_db}.GENDER AS gender
        ON CAST(gps.gpsgender AS BIGINT) = gender.legacy_id
)


