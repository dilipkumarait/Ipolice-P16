CREATE TABLE IF NOT EXISTS ${i3_db}.`GENDER` (
    `ID` BIGINT,
    `LEGACY_SOURCE` STRING,
    `LEGACY_TABLE` STRING,
    `LEGACY_ID` BIGINT,
    `LABEL` STRING,
    `LABEL_FR` STRING,
    `LABEL_NL` STRING,
    `LABEL_DE` STRING,
    `LABEL_EN` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

--Filling gender table
INSERT INTO ${i3_db}.GENDER (
    SELECT
        ROW_NUMBER() OVER (ORDER BY geskey) AS ID,
        'REFTAB' AS LEGACY_SOURCE,
        'GES' AS LEGACY_TABLE,
        cast(geskey AS BIGINT) AS LEGACY_ID,
        UPPER(gestextbe) AS LABEL,
        gestextbf AS LABEL_FR,
        gestextbd AS LABEL_NL,
        gestextbg AS LABEL_DE,
        gestextbe AS LABEL_EN
    FROM ${raw_references}.reftab_rges
);