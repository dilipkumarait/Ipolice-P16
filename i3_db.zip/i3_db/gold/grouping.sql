-----------------------------------------------------------
-- Description: Script used to create the table Grouping --
-----------------------------------------------------------

CREATE TABLE ${i3_db}.`GROUPING` (
    ID BIGINT,
    NAME STRING,
    IS_CRIMINAL BOOLEAN,
    REGISTRATION_DATE TIMESTAMP,
    REGISTRATION_CASE_NUMBER BIGINT,
    REGISTRATION_CASE_YEAR INT
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.`GROUPING` (
    SELECT
        person.id AS ID,
        person.NAME AS NAME,
        CASE
            WHEN CAST(org.orgbeschtype AS INT) = 1 THEN True
            ELSE False
        END AS IS_CRIMINAL,
        person.registration_date AS REGISTRATION_DATE,
        person.registration_case_number AS REGISTRATION_CASE_NUMBER,
        person.registration_case_year AS REGISTRATION_CASE_YEAR
    FROM ${i3_db}.PERSON person
    INNER JOIN ${i3_db_staging}.mapping_case_items AS mci
        ON mci.CASE_ITEM_GENERATED_ID = person.id
        AND mci.source_table = "mapping_case_entities"
    INNER JOIN ${i3_db_staging}.mapping_case_entities mce
        ON mce.CASE_ENTITY_STAGING_ID = mci.CASE_ITEM_STAGING_ID
        AND mce.TARGET_TYPE = mci.TARGET_TYPE
        AND mce.TARGET_TYPE = "GROUPING"
    INNER JOIN ${raw_questis}.org org
        ON CAST(CONV(org.orgncdbkey, 16, 10) AS BIGINT) =  mce.QUESTIS_ID
    WHERE person.person_type_id = 2
)
