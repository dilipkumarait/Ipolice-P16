
CREATE TABLE ${i3_db}.`PERSON_ATTRIBUTES` (
    `ID` BIGINT,
    `REGISTRATION_CASE_YEAR` INT,
    `REGISTRATION_CASE_NUMBER` BIGINT,
    `PERSON_ID` BIGINT,
    `NAME` STRING,
    `REGISTRATION_DATE` TIMESTAMP,
    `RELIABILITY_ID` BIGINT,
    `START_DATE` TIMESTAMP,
    `END_DATE` TIMESTAMP,
    `LANGUAGE_ID` BIGINT,
    `NATIONALITY_ID` BIGINT
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');


INSERT INTO ${i3_db}.`PERSON_ATTRIBUTES` (
    SELECT
        mci.CASE_ITEM_GENERATED_ID AS ID,
        person.registration_case_year AS REGISTRATION_CASE_YEAR,
        person.registration_case_number AS REGISTRATION_CASE_NUMBER,
        person.id AS PERSON_ID,
        gps.gpsfullname AS NAME,
        person.registration_date AS REGISTRATION_DATE,
        NULL AS RELIABILITY_ID,
        NULL AS START_DATE,
        NULL AS END_DATE,
        NULL AS LANGUAGE_ID,
        nationality.id AS NATIONALITY_ID
    FROM ${i3_db_staging}.MAPPING_CASE_ITEMS AS mci
    INNER JOIN ${i3_db_staging}.MAPPING_ATTRIBUTES AS ma
        ON  mci.CASE_ITEM_STAGING_ID = ma.ATTRIBUTE_STAGING_ID
        AND mci.TARGET_TYPE = ma.TARGET_TYPE
        AND mci.TARGET_TYPE = "PERSON ATTRIBUTES"
    INNER JOIN ${raw_questis}.GPS AS gps
        ON CAST(CONV(gps.GPSNCDBKEY,16,10) AS BIGINT) = ma.QUESTIS_ID 
    INNER JOIN ${i3_db_staging}.mapping_case_items AS mci2
        ON mci2.CASE_ITEM_STAGING_ID= ma.CASE_ENTITY_STAGING_ID
        AND mci2.TARGET_TYPE= 'NATURAL PERSON'
    INNER JOIN ${i3_db}.NATURAL_PERSON AS person
        ON mci2.CASE_ITEM_GENERATED_ID = person.id
    INNER JOIN `${i3_db}`.NATIONALITY AS nationality
        ON CAST(gps.gpsnationality AS BIGINT) = nationality.legacy_id
);


   