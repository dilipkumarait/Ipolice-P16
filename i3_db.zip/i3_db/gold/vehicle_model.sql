-------------------------------------------------------------
-- Description: Create and add data to table vehicle_model --
-------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ${i3_db}.`VEHICLE_MODEL` (
    `ID` BIGINT,
    `LEGACY_SOURCE` STRING,
    `LEGACY_TABLE` STRING,
    `LEGACY_ID` BIGINT,
    `LABEL` STRING,
    `LABEL_FR` STRING,
    `LABEL_NL` STRING,
    `LABEL_DE` STRING,
    `LABEL_EN` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

--Filling vehicle_model table
INSERT INTO ${i3_db}.VEHICLE_MODEL (
    SELECT
        ROW_NUMBER() OVER (ORDER BY tvmkey) AS ID,
        'REFTAB' AS LEGACY_SOURCE,
        'TVM' AS LEGACY_TABLE,
        CAST(tvmkey AS BIGINT) AS LEGACY_ID,
        UPPER(tvmtextbe) AS LABEL,
        tvmtextbf AS LABEL_FR,
        tvmtextbd AS LABEL_NL,
        tvmtextbg AS LABEL_DE,
        tvmtextbe AS LABEL_EN
    FROM ${raw_references}.reftab_rtvm
);