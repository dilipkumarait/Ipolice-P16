----------------------------------------------------------------------
--- Description: Script used to create the table Object_attributes ---
----------------------------------------------------------------------

CREATE TABLE ${i3_db}.`OBJECT_ATTRIBUTES` (
    `ID` BIGINT,
    `NATIONALITY_ID` BIGINT,
    `COLOR_ID` BIGINT,
    `OBJECT_ID` BIGINT
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');


INSERT INTO ${i3_db}.`OBJECT_ATTRIBUTES` (
    SELECT
        mci.CASE_ITEM_GENERATED_ID,
        CAST(gvm.gvmnatcode AS BIGINT) AS NATIONALITY_ID,
        CAST(gvm.gvmaktklvoornm AS BIGINT) AS COLOR_ID,
        object.id AS OBJECT_ID
    FROM ${i3_db_staging}.mapping_case_items AS mci
    INNER JOIN ${i3_db_staging}.mapping_attributes ma
        ON  mci.CASE_ITEM_STAGING_ID = ma.ATTRIBUTE_STAGING_ID
        AND mci.TARGET_TYPE = ma.TARGET_TYPE
        AND mci.TARGET_TYPE = "OBJECT ATTRIBUTES"
    INNER JOIN ${raw_questis}.`gvm` gvm 
        ON CAST(CONV(gvm.GVMNCDBKEY,16,10) AS BIGINT) = ma.QUESTIS_ID 
    INNER JOIN  ${i3_db_staging}.mapping_case_items AS mci2
        ON mci2.CASE_ITEM_STAGING_ID = ma.CASE_ENTITY_STAGING_ID
        AND mci2.TARGET_TYPE = 'VEHICLE'
    INNER JOIN ${i3_db}.`OBJECT` AS object
        ON mci2.CASE_ITEM_GENERATED_ID = object.id
    
    UNION

    SELECT
        mci.CASE_ITEM_GENERATED_ID,
        CAST(gvw.GVWNATKODE AS BIGINT) AS NATIONALITY_ID,
        CAST(NULL AS BIGINT) AS COLOR_ID,
        object.id AS OBJECT_ID
    FROM ${i3_db_staging}.mapping_case_items AS mci
    INNER JOIN ${i3_db_staging}.mapping_attributes ma
        ON  mci.CASE_ITEM_STAGING_ID = ma.ATTRIBUTE_STAGING_ID
        AND mci.TARGET_TYPE = ma.TARGET_TYPE
        AND mci.TARGET_TYPE = "OBJECT ATTRIBUTES"
    INNER JOIN ${raw_questis}.`gvw` gvw 
        ON CAST(CONV(gvw.GVWNCDBKEY,16,10) AS BIGINT) = ma.QUESTIS_ID 
    INNER JOIN ${i3_db_staging}.mapping_case_items AS mci2
        ON mci2.CASE_ITEM_STAGING_ID = ma.CASE_ENTITY_STAGING_ID
        AND mci2.TARGET_TYPE in ("DRUG", "FIREARM")
    INNER JOIN ${i3_db}.`OBJECT` AS object
        ON mci2.CASE_ITEM_GENERATED_ID = object.id
)