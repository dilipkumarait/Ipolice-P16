
from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    
    raw_references = conf_variables['raw_references']

    query = f"""
    SELECT
        "REFTAB" AS LEGACY_SOURCE,
        "NIS" AS LEGACY_TABLE,
        CAST(nis.niskey AS STRING) AS LEGACY_ID,
        CAST(nis.niscode AS STRING) AS LABEL,
        CAST(nis.niscode AS STRING) AS LABEL_FR,
        CAST(nis.niscode AS STRING) AS LABEL_NL,
        CAST(nis.niscode AS STRING) AS LABEL_DE,
        CAST(nis.niscode AS STRING) AS LABEL_EN
    FROM {raw_references}.reftab_rnis nis
        
      """

    nis_code = sparkSession.sql(query)
    nis_code = nis_code.withColumn("ID", monotonically_increasing_id())

    return nis_code
