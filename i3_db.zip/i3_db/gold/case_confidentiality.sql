CREATE TABLE ${i3_db}.`CASE_CONFIDENTIALITY` (
    `ID` BIGINT,
    `LABEL` STRING,
    `LABEL_FR` STRING,
    `LABEL_NL` STRING,
    `LABEL_DE` STRING,
    `LABEL_EN` STRING,
    `DESCRIPTION_FR` STRING,
    `DESCRIPTION_NL` STRING,
    `DESCRIPTION_DE` STRING,
    `DESCRIPTION_EN` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.CASE_CONFIDENTIALITY VALUES
  (1, 'A', 'A', 'A', 'A', 'A', "A exploiter dans un contexte opérationnel", NULL, NULL, NULL),
  (2, 'B', 'B', 'B', 'B', 'B', "Utilisation autorisée mais la source ne peut pas être fournie", NULL, NULL, NULL),
  (3, 'C', 'C', 'C', 'C', 'C', "Information à n'utiliser qu'après consultation de l'auteur", NULL, NULL, NULL),
  (4, 'D', 'D', 'D', 'D', 'D', "L’information ne peut pas être utilisée", NULL, NULL, NULL)