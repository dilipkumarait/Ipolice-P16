
CREATE TABLE ${i3_db}.`MORAL_PERSON` (
    `ID` BIGINT,
    `REGISTRATION_CASE_YEAR` INT,
    `REGISTRATION_CASE_NUMBER` BIGINT,
    `REGISTRATION_DATE` TIMESTAMP,
    `CREATION_DATE` TIMESTAMP,
    `BCE_NO` INT,
    `COM_REG_NO` INT,
    `VAT_NO` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.`MORAL_PERSON` (
    SELECT
        person.id AS ID,
        person.registration_case_year AS REGISTRATION_CASE_YEAR,
        person.registration_case_number AS REGISTRATION_CASE_NUMBER,
        person.registration_date AS REGISTRATION_DATE,
        person.registration_date AS CREATION_DATE,
        NULL AS BCE_NO,
        NULL AS COM_REG_NO,
        CAST(CONV(org.orgbeschbtwnr,16,10) AS STRING) AS VAT_NO
    FROM ${i3_db}.PERSON AS person
    INNER JOIN ${i3_db_staging}.MAPPING_CASE_ITEMS AS mci
        ON mci.case_item_generated_id = person.id
        AND mci.source_table = "mapping_case_entities"
    INNER JOIN ${i3_db_staging}.MAPPING_CASE_ENTITIES AS mce
        ON mce.case_entity_staging_id = mci.case_item_staging_id
        AND mce.target_type = mci.target_type
        AND mce.target_type = "MORAL PERSON"
        AND mce.source_table = "EO1"
    INNER JOIN ${raw_questis}.ORG AS org
    ON CAST(CONV(org.orgncdbkey,16,10) AS BIGINT) =  mce.questis_id
    WHERE person.person_type_id = 1
);

