from pyspark.sql.functions import col, max, lit, lpad
from pyspark.sql.functions import hash as pyhash
from pyspark.sql.functions import concat
from pyspark.sql.functions import hex as pyhex
from pyspark.sql.functions import monotonically_increasing_id


def load_table(sparkSession, conf_variables):

    # Generic Case tables
    sdf_gps = add_relation_generic_case(sparkSession, conf_variables, 1,3, "GPSINPUTDATE", "GPSINPUTTIME", "NATURAL PERSON", "gps", "GPSNCDBKEY","GPSTECHTS")
    sdf_gvm = add_relation_generic_case(sparkSession, conf_variables, 4,24, "GVMINPUTDATE", "GVMINPUTTIME", "VEHICLE", "gvm", "GVMNCDBKEY","GMVTECHTS")
    sdf_org = add_relation_generic_case(sparkSession, conf_variables, 1,1, "ORGINPUTDATE", "ORGINPUTTIME", "MORAL PERSON", "org", "ORGNCDBKEY","ORGTECHTS")
    sdf_group = add_relation_generic_case(sparkSession, conf_variables, 1,2, "ORGINPUTDATE", "ORGINPUTTIME", "GROUPING", "org", "ORGNCDBKEY","ORGTECHTS", default_select={"name":"ORGBESCHNAAM as name"})
    sdf_fei = add_relation_generic_case(sparkSession, conf_variables, 3,10, "FEIINPUTDATE", "FEIINPUTTIME", "OFFENCE", "fei", "FEINCDBKEY","FEITECHTS")
    sdf_lcp = add_relation_generic_case(sparkSession, conf_variables, 4,13, "GVMINPUTDATE", "GVMINPUTTIME", "LICENSE PLATE", "gvm", "GVMNCDBKEY","GMVTECHTS", default_select={"name":"gvminschrijvingnr as name"})
    sdf_gpl = add_relation_generic_case(sparkSession, conf_variables, 2,30, "GPLINPUTDATE", "GPLINPUTTIME", "LOCATION", "gpl", "GPLNCDBKEY","GPLTECHTS")
    sdf_gvw = add_relation_generic_case(sparkSession, conf_variables, 4,20, "GVWINPUTDATE", "GVWINPUTTIME", "DRUG", "gvw", "GVWNCDBKEY","GVWTECHTS", default_select={"name":"gvwnaam as name"})
    sdf_firearm = add_relation_generic_case(sparkSession, conf_variables, 4,23, "GVWINPUTDATE", "GVWINPUTTIME", "FIREARM", "gvw", "GVWNCDBKEY","GVWTECHTS", default_select={"name":"gvwnaam as name"})
    sdf_num = add_relation_generic_case(sparkSession, conf_variables, 4,12, "NUMINPUTDATE", "NUMINPUTTIME", "num", "num", "NUMNCDBKEY","NUMTECHTS", default_select={"name":"NUMNAAM as name"})
    sdf_email = add_relation_generic_case(sparkSession, conf_variables, 4,14, "NUMINPUTDATE", "NUMINPUTTIME", "EMAIL ADDRESS", "num", "NUMNCDBKEY","NUMTECHTS")
    
    # Generic Real tables
    sdf_real_gps = add_relation_real_naturalperson(sparkSession, conf_variables)
    sdf_real_gvm = add_relation_real_vehicle(sparkSession, conf_variables)
    sdf_real_org = add_relation_real_moral_person(sparkSession, conf_variables)
    sdf_real_group = add_relation_real_grouping(sparkSession, conf_variables)
    sdf_real_fei = add_relation_real_offence(sparkSession, conf_variables)
    sdf_real_lcp = add_relation_real_licence_plate(sparkSession, conf_variables)
    sdf_real_gpl = add_relation_real_location(sparkSession, conf_variables)
    sdf_real_gvw = add_real_drug(sparkSession, conf_variables)
    sdf_real_firearm = add_real_firearm(sparkSession, conf_variables)
    sdf_real_num = add_relation_real_phonenumber(sparkSession, conf_variables)
    sdf_real_email= add_relation_real_email(sparkSession, conf_variables)

    # Specific Processing
    # Generation of random names for gps table
    sdf_gps = sdf_gps.withColumn("tmp_name", pyhex(pyhash(lpad(monotonically_increasing_id().cast("string"), 10, "0"))))
    sdf_gps = sdf_gps.withColumn("name", concat(col("tmp_name").substr(0, 5), concat(lit(" "), col("tmp_name").substr(6, 100))))
    sdf_gps = sdf_gps.drop("tmp_name")
    # Generation of random email
    sdf_email = sdf_email.withColumn("name", concat(pyhex(pyhash(lpad(col("ID").cast("string"), 10, "0"))), lit("@gmail.com")))
    

    # Fusion of all the data
     # Fusion de toutes les tables
    final_df = sdf_gps.union(sdf_gvm)
    final_df = final_df.union(sdf_real_gvm)
    final_df = final_df.union(sdf_real_gps)
    final_df = final_df.union(sdf_org)
    final_df = final_df.union(sdf_real_org)
    final_df = final_df.union(sdf_group)
    final_df = final_df.union(sdf_real_group)
    final_df = final_df.union(sdf_fei)
    final_df = final_df.union(sdf_real_fei)
    final_df = final_df.union(sdf_lcp)
    final_df = final_df.union(sdf_real_lcp)
    final_df = final_df.union(sdf_gpl)
    final_df = final_df.union(sdf_real_gpl)
    final_df = final_df.union(sdf_gvw)
    final_df = final_df.union(sdf_real_gvw)
    final_df = final_df.union(sdf_firearm)
    final_df = final_df.union(sdf_real_firearm)
    final_df = final_df.union(sdf_num)
    final_df = final_df.union(sdf_real_num)
    final_df = final_df.union(sdf_email)
    final_df = final_df.union(sdf_real_email)

    return final_df

def add_relation_generic_case(
        sparkSession, 
        conf_variables,
        entity_type_id,
        entity_sub_type_id,
        questis_date_field,
        questis_time_field,
        target_type,
        questis_table_name,
        questis_pk_name,
        questis_technical_timestamp_name,
        default_select = {
            "id":None,
            "reg_case_year": None,
            "reg_case_num": None,
            "name": None,
            "is_case": None,
            "type_id": None,
            "subtype_id": None,
            "information_category_id": None,
            "reg_date": None,
            "last_modification_time": None
        }
    ):

    i3_db = conf_variables["i3_db"]
    i3_db_staging = conf_variables["i3_db_staging"]
    raw_questis = conf_variables["raw_questis"]

    # Prépare default_select dictionnary
    select_dict = default_select.copy()
    if "id" not in select_dict:
        select_dict["id"] = None
    if "reg_case_year" not in select_dict:
        select_dict["reg_case_year"] = None
    if "reg_case_num" not in select_dict:
        select_dict["reg_case_num"] = None
    if "name" not in select_dict:
        select_dict["name"] = None
    if "is_case" not in select_dict:
        select_dict["is_case"] = None
    if "type_id" not in select_dict:
        select_dict["type_id"] = None
    if "subtype_id" not in select_dict:
        select_dict["subtype_id"] = None
    if "information_category_id" not in select_dict:
        select_dict["information_category_id"] = None
    if "reg_date" not in select_dict:
        select_dict["reg_date"] = None
    if "last_modification_time" not in select_dict:
        select_dict["last_modification_time"] = None

    # Define the fields to select
    entity_id = "mci.CASE_ITEM_GENERATED_ID AS ID" if select_dict["id"] is None else select_dict["id"]
    case_year = "c.CASE_YEAR AS REGISTRATION_CASE_YEAR" if select_dict["reg_case_year"] is None else select_dict["reg_case_year"]
    case_number = "c.CASE_NUMBER AS REGISTRATION_CASE_NUMBER" if select_dict["reg_case_num"] is None else select_dict["reg_case_num"]
    name = "NULL AS NAME" if select_dict["name"] is None else select_dict["name"]
    is_case_entity = "true AS IS_CASE_ENTITY" if select_dict["is_case"] is None else select_dict["is_case"]
    type_id = f"{entity_type_id} AS ENTITY_TYPE_ID" if select_dict["type_id"] is None else select_dict["type_id"]
    subtype_id = f"{entity_sub_type_id} AS ENTITY_SUB_TYPE_ID" if select_dict["subtype_id"] is None else select_dict["subtype_id"]
    reg_date = f"""
        from_unixtime(
            unix_timestamp(
                CONCAT(questis_tab.{questis_date_field},questis_tab.{questis_time_field}),
                'yyyyMMddHHmm'
            )
        ) AS REGISTRATION_DATE
    """ if select_dict["reg_date"] is None else select_dict["reg_date"]
    information_category_id = f"ic.id AS INFORMATION_CATEGORY_ID" if select_dict["information_category_id"] is None else select_dict["information_category_id"]
    last_modification_time = f"from_unixtime(unix_timestamp(questis_tab.{questis_technical_timestamp_name} ,'yyyyMMddHHmmss'))  AS LAST_MODIFICATION_TIME" if select_dict["last_modification_time"] is None else select_dict["last_modification_time"]


    # Build and execute query
    sdf_case_table = sparkSession.sql(f"""
        SELECT DISTINCT
            {entity_id},
            {case_year},
            {case_number},
            {name},
            {is_case_entity},
            {type_id},
            {subtype_id},
            {information_category_id},
            {reg_date},
            {last_modification_time}
        
        FROM {i3_db_staging}.MAPPING_CASE_ITEMS AS mci
        INNER JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES AS mce 
            ON mci.case_item_staging_id = mce.case_entity_staging_id
            AND mci.target_type = mce.target_type 
            AND mce.target_type = "{target_type}"
            AND mci.source_table = "mapping_case_entities"
        INNER JOIN {i3_db_staging}.MAPPING_CASES AS mc
            ON mc.questis_id = mce.questis_case_id 
            AND mc.source_table = "OND"
        INNER JOIN {i3_db}.`CASE` AS c 
            ON c.id = mc.case_generated_id
        CROSS JOIN {i3_db}.INFORMATION_CATEGORY AS ic
        LEFT JOIN {raw_questis}.`{questis_table_name}` AS questis_tab 
            ON CAST(CONV(questis_tab.{questis_pk_name},16,10) AS BIGINT) = mce.questis_id
        WHERE ic.label = 'CAT. 1' 
            AND questis_tab.{questis_technical_timestamp_name} = (SELECT MAX(questis_tabi.{questis_technical_timestamp_name}) FROM {raw_questis}.`{questis_table_name}` AS questis_tabi WHERE CAST(CONV(questis_tabi.{questis_pk_name},16,10) AS BIGINT) = mce.QUESTIS_ID)

    """)
   
    return sdf_case_table

def add_relation_real_naturalperson(sparkSession, conf_variables):
    i3_db_staging = conf_variables["i3_db_staging"]


    # Load entity
    sdf_real_gps = sparkSession.sql(f"""
        SELECT
            mci.CASE_ITEM_GENERATED_ID AS ID,
            '-1' AS REGISTRATION_CASE_YEAR,
            '-1' AS REGISTRATION_CASE_NUMBER,
            NULL AS NAME,
            false AS IS_CASE_ENTITY,
            1 AS ENTITY_TYPE_ID,
            3 AS ENTITY_SUB_TYPE_ID,
            NULL AS INFORMATION_CATEGORY_ID,
            NULL AS REGISTRATION_DATE,
            NULL AS LAST_MODIFICATION_TIME                    
        FROM {i3_db_staging}.mapping_case_items mci
        INNER JOIN {i3_db_staging}.mapping_real_entities mre
            ON mci.CASE_ITEM_STAGING_ID = mre.REAL_ENTITY_STAGING_ID
            AND mci.TARGET_TYPE = mre.TARGET_TYPE
            AND mre.TARGET_TYPE = "NATURAL PERSON"
            AND mci.SOURCE_TABLE = "mapping_real_entities"
        
    """)

    return sdf_real_gps
   
def add_relation_real_moral_person(sparkSession, conf_variables):
    i3_db_staging = conf_variables["i3_db_staging"]

    # Load entity
    sdf_real_org = sparkSession.sql(f"""
        SELECT
            mci.CASE_ITEM_GENERATED_ID AS ENTITY_ID,
            '-1' AS REGISTRATION_CASE_YEAR,
            '-1' AS REGISTRATION_CASE_NUMBER,
            NULL AS NAME,
            false AS IS_CASE_ENTITY,
            1 AS ENTITY_TYPE_ID,
            1 AS  ENTITY_SUB_TYPE_ID,
            NULL AS INFORMATION_CATEGORY_ID,
            NULL AS REGISTRATION_DATE,
            NULL AS LAST_MODIFICATION_TIME
        FROM {i3_db_staging}.mapping_case_items mci
        INNER JOIN {i3_db_staging}.mapping_real_entities mre
            ON mci.CASE_ITEM_STAGING_ID = mre.REAL_ENTITY_STAGING_ID
            AND mci.TARGET_TYPE = mre.TARGET_TYPE
            AND mci.TARGET_TYPE = "MORAL PERSON"
            AND mci.SOURCE_TABLE = "mapping_real_entities"
    """)
    
    return sdf_real_org
    
def add_relation_real_grouping(sparkSession, conf_variables):
    i3_db_staging = conf_variables["i3_db_staging"]

    # Load entity
    sdf_real_group = sparkSession.sql(f"""
        SELECT
           mci.CASE_ITEM_GENERATED_ID AS ENTITY_ID,
            '-1' AS REGISTRATION_CASE_YEAR,
            '-1' AS REGISTRATION_CASE_NUMBER,
            NULL AS NAME,
            false AS IS_CASE_ENTITY,
            1 AS ENTITY_TYPE_ID,
            2 AS  ENTITY_SUB_TYPE_ID,
            NULL AS INFORMATION_CATEGORY_ID,
            NULL AS REGISTRATION_DATE,
            NULL AS LAST_MODIFICATION_TIME
         FROM {i3_db_staging}.mapping_case_items mci
         INNER JOIN {i3_db_staging}.mapping_real_entities mre
            ON mci.CASE_ITEM_STAGING_ID = mre.REAL_ENTITY_STAGING_ID
            AND mci.TARGET_TYPE = mre.TARGET_TYPE
            AND mci.TARGET_TYPE = "GROUPING"
    """)
    
    return sdf_real_group

def add_relation_real_vehicle(sparkSession, conf_variables):
    i3_db_staging = conf_variables["i3_db_staging"]

    # Load entity
    sdf_real_gvm = sparkSession.sql(f"""
        SELECT
            mci.CASE_ITEM_GENERATED_ID AS ENTITY_ID,
            '-1' AS REGISTRATION_CASE_YEAR,
            '-1' AS REGISTRATION_CASE_NUMBER,
            NULL AS NAME,
            false AS IS_CASE_ENTITY,
            4 AS ENTITY_TYPE_ID,
            24 AS ENTITY_SUB_TYPE_ID,
            NULL AS INFORMATION_CATEGORY_ID,
            NULL AS REGISTRATION_DATE,
            NULL AS LAST_MODIFICATION_TIME      
        FROM {i3_db_staging}.mapping_case_items mci
        INNER JOIN {i3_db_staging}.mapping_real_entities mre
            ON mci.CASE_ITEM_STAGING_ID = mre.REAL_ENTITY_STAGING_ID
            AND mci.TARGET_TYPE = mre.TARGET_TYPE
            AND mci.TARGET_TYPE = "VEHICLE"
            AND mci.SOURCE_TABLE = "mapping_real_entities"    
    """)

    return sdf_real_gvm

def add_relation_real_offence(sparkSession, conf_variables):
    i3_db_staging = conf_variables["i3_db_staging"]

    # Load Fact
    sdf_real_fei = sparkSession.sql(f"""
        SELECT
           mci.CASE_ITEM_GENERATED_ID AS ENTITY_ID,
            '-1' AS REGISTRATION_CASE_YEAR,
            '-1' AS REGISTRATION_CASE_NUMBER,
            NULL AS NAME,
            false AS IS_CASE_ENTITY,
            3 AS ENTITY_TYPE_ID,
            10 AS ENTITY_SUB_TYPE_ID,
            NULL AS INFORMATION_CATEGORY_ID,
            NULL AS REGISTRATION_DATE,
            NULL AS LAST_MODIFICATION_TIME       
       FROM {i3_db_staging}.mapping_case_items mci
       INNER JOIN {i3_db_staging}.mapping_real_entities mre
            ON mci.CASE_ITEM_STAGING_ID = mre.REAL_ENTITY_STAGING_ID
            AND mci.TARGET_TYPE = mre.TARGET_TYPE
            AND mci.TARGET_TYPE = "OFFENCE"
            AND mci.SOURCE_TABLE = "mapping_real_entities"
    """)
 
    return sdf_real_fei

def add_relation_real_licence_plate(sparkSession, conf_variables):
    i3_db_staging = conf_variables["i3_db_staging"]

    # Load entity
    sdf_real_lcp = sparkSession.sql(f"""
        SELECT
            mci.CASE_ITEM_GENERATED_ID AS ENTITY_ID,
            '-1' AS REGISTRATION_CASE_YEAR,
            '-1' AS REGISTRATION_CASE_NUMBER,
            NULL AS NAME,
            false AS IS_CASE_ENTITY,
            4 AS ENTITY_TYPE_ID,
            13 AS ENTITY_SUB_TYPE_ID,
            NULL AS INFORMATION_CATEGORY_ID,
            NULL AS REGISTRATION_DATE,
            NULL AS LAST_MODIFICATION_TIME      
        FROM {i3_db_staging}.mapping_case_items mci
        INNER JOIN {i3_db_staging}.mapping_real_entities mre
            ON mci.CASE_ITEM_STAGING_ID = mre.REAL_ENTITY_STAGING_ID
            AND mci.TARGET_TYPE = mre.TARGET_TYPE
            AND mci.TARGET_TYPE = "LICENSE PLATE"
            AND mci.SOURCE_TABLE = "mapping_real_entities"
    """)
    
    return sdf_real_lcp

def add_relation_real_location(sparkSession, conf_variables):
    i3_db_staging = conf_variables["i3_db_staging"]

    # Load Place
    sdf_real_gpl = sparkSession.sql(f"""
        SELECT
             mci.CASE_ITEM_GENERATED_ID AS ENTITY_ID,
            '-1' AS REGISTRATION_CASE_YEAR,
            '-1' AS REGISTRATION_CASE_NUMBER,
            NULL AS NAME,
            false AS IS_CASE_ENTITY,
            2 AS ENTITY_TYPE_ID,
            30 AS ENTITY_SUB_TYPE_ID,
            NULL AS INFORMATION_CATEGORY_ID,
            NULL AS REGISTRATION_DATE,
            NULL AS LAST_MODIFICATION_TIME       
        FROM {i3_db_staging}.mapping_case_items mci
        INNER JOIN {i3_db_staging}.mapping_real_entities mre
            ON mci.CASE_ITEM_STAGING_ID = mre.REAL_ENTITY_STAGING_ID
            AND mci.TARGET_TYPE = mre.TARGET_TYPE
            AND mci.TARGET_TYPE = "LOCATION"
            AND mci.SOURCE_TABLE = "mapping_real_entities"
    """)
  
    return sdf_real_gpl

def add_real_drug(sparkSession, conf_variables):
    i3_db_staging = conf_variables["i3_db_staging"]

    # Load Drugs 
    sdf_real_gvw = sparkSession.sql(f"""
        SELECT
            mci.CASE_ITEM_GENERATED_ID AS ENTITY_ID,
            '-1' AS REGISTRATION_CASE_YEAR,
            '-1' AS REGISTRATION_CASE_NUMBER,
            NULL AS NAME,
            false AS IS_CASE_ENTITY,
            4 AS ENTITY_TYPE_ID,
            20 AS ENTITY_SUB_TYPE_ID,
            NULL AS INFORMATION_CATEGORY_ID,
            NULL AS REGISTRATION_DATE,
            NULL AS LAST_MODIFICATION_TIME       
        FROM {i3_db_staging}.mapping_case_items mci
        INNER JOIN {i3_db_staging}.mapping_real_entities mre
            ON mci.CASE_ITEM_STAGING_ID = mre.REAL_ENTITY_STAGING_ID
            AND mci.TARGET_TYPE = mre.TARGET_TYPE
            AND mci.TARGET_TYPE = "DRUG"
            AND mci.SOURCE_TABLE = "mapping_real_entities"
    """)

    return sdf_real_gvw

def add_real_firearm(sparkSession, conf_variables):
    i3_db_staging = conf_variables["i3_db_staging"]

    # Load  Firearm
    sdf_real_firearm = sparkSession.sql(f"""
        SELECT
            mci.CASE_ITEM_GENERATED_ID AS ENTITY_ID,
            '-1' AS REGISTRATION_CASE_YEAR,
            '-1' AS REGISTRATION_CASE_NUMBER,
            NULL AS NAME,
            false AS IS_CASE_ENTITY,
            4 AS ENTITY_TYPE_ID,
            23 AS ENTITY_SUB_TYPE_ID,
            NULL AS INFORMATION_CATEGORY_ID,
            NULL AS REGISTRATION_DATE,
            NULL AS LAST_MODIFICATION_TIME       
        FROM {i3_db_staging}.mapping_case_items mci
        INNER JOIN {i3_db_staging}.mapping_real_entities mre
            ON mci.CASE_ITEM_STAGING_ID = mre.REAL_ENTITY_STAGING_ID
            AND mci.TARGET_TYPE = mre.TARGET_TYPE
            AND mci.TARGET_TYPE = "FIREARM"
            AND mci.SOURCE_TABLE = "mapping_real_entities"
    """)

    return sdf_real_firearm

def add_relation_real_phonenumber(sparkSession, conf_variables):
    i3_db_staging = conf_variables["i3_db_staging"]

    # Load Phone_number
    sdf_real_num = sparkSession.sql(f"""
        SELECT
            mci.CASE_ITEM_GENERATED_ID AS ENTITY_ID,
            '-1' AS REGISTRATION_CASE_YEAR,
            '-1' AS REGISTRATION_CASE_NUMBER,
            NULL AS NAME,
            false AS IS_CASE_ENTITY,
            4 AS ENTITY_TYPE_ID,
            12 ENTITY_SUB_TYPE_ID,
            NULL AS INFORMATION_CATEGORY_ID,
            NULL AS REGISTRATION_DATE,
            NULL AS LAST_MODIFICATION_TIME     
        FROM {i3_db_staging}.mapping_case_items mci
        INNER JOIN {i3_db_staging}.mapping_real_entities mre
            ON mci.CASE_ITEM_STAGING_ID = mre.REAL_ENTITY_STAGING_ID
            AND mci.TARGET_TYPE = mre.TARGET_TYPE
            AND mci.TARGET_TYPE = "PHONE NUMBER"
            AND mci.SOURCE_TABLE = "mapping_real_entities"
    """)

    return sdf_real_num
   
def add_relation_real_email(sparkSession, conf_variables):
    i3_db_staging = conf_variables["i3_db_staging"]

    # Load email adress
    sdf_real_email = sparkSession.sql(f"""
        SELECT
           mci.CASE_ITEM_GENERATED_ID AS ENTITY_ID,
            '-1' AS REGISTRATION_CASE_YEAR,
            '-1' AS REGISTRATION_CASE_NUMBER,
            NULL AS NAME,
            false AS IS_CASE_ENTITY,
            4 AS ENTITY_TYPE_ID,
            14 ENTITY_SUB_TYPE_ID,
            NULL AS INFORMATION_CATEGORY_ID,
            NULL AS REGISTRATION_DATE,
            NULL AS LAST_MODIFICATION_TIME     
        FROM {i3_db_staging}.mapping_case_items mci
        INNER JOIN {i3_db_staging}.mapping_real_entities mre
            ON mci.CASE_ITEM_STAGING_ID = mre.REAL_ENTITY_STAGING_ID
            AND mci.TARGET_TYPE = mre.TARGET_TYPE
            AND mci.TARGET_TYPE = "EMAIL ADDRESS"
            AND mci.SOURCE_TABLE = "mapping_real_entities"
    """)

    return sdf_real_email
