CREATE TABLE IF NOT EXISTS ${i3_db}.`DRUG_CLASS` (
    `ID` BIGINT,
    `LEGACY_SOURCE` STRING,
    `LEGACY_TABLE` STRING,
    `LEGACY_ID` BIGINT,
    `LABEL` STRING,
    `LABEL_FR` STRING,
    `LABEL_NL` STRING,
    `LABEL_DE` STRING,
    `LABEL_EN` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

--Filling DRUG_CLASS table
INSERT INTO ${i3_db}.DRUG_CLASS (
    SELECT
        ROW_NUMBER() OVER (ORDER BY klgkey) AS ID,
        'REFTAB' AS LEGACY_SOURCE,
        'KLG' AS LEGACY_TABLE,
        CAST(klgkey AS BIGINT) AS LEGACY_ID,
        UPPER(klgtextbe) AS LABEL,
        klgtextbf AS LABEL_FR,
        klgtextbd AS LABEL_NL,
        klgtextbg AS LABEL_DE,
        klgtextbe AS LABEL_EN
    FROM ${raw_references}.reftab_rklg
    WHERE CAST(klgkagkey AS BIGINT) IN (18, 90)
);