-----------------------------------------------------------------
-- Description: Create and add data to table SHAPE_TYPE --
-----------------------------------------------------------------

CREATE TABLE ${i3_db}.`SHAPE_TYPE` (
    `ID` BIGINT,
    `LABEL` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

-- https://en.wikipedia.org/wiki/Well-known_text_representation_of_geometry
INSERT INTO ${i3_db}.`SHAPE_TYPE`
    VALUES (1, 'POINT');