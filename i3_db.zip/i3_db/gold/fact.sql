-----------------------------------------------------------
---- Description: Script used to create the table Fact ----
-----------------------------------------------------------

CREATE TABLE ${i3_db}.`FACT` (
    `ID` BIGINT,
    `REGISTRATION_CASE_NUMBER` BIGINT,
    `REGISTRATION_CASE_YEAR` INT,
    `REGISTRATION_DATE` TIMESTAMP,
    `NAME` STRING,
    `IS_CASE_ENTITY` BOOLEAN,
    `START_DATE` TIMESTAMP,
    `END_DATE` TIMESTAMP,
    `IS_CONCRETE` BOOLEAN,
    `IS_ATTEMPT` BOOLEAN,
    `FACT_CATEGORY_ID` BIGINT,
    `FACT_CLASS_ID` BIGINT,
    `FACT_QUALIFICATION_ID` BIGINT,
    `MODUS_OPERANDI_ID` BIGINT
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.`FACT` (
    SELECT
        event.id AS ID,
        event.registration_case_number AS REGISTRATION_CASE_NUMBER,
        event.registration_case_year AS REGISTRATION_CASE_YEAR,
        event.registration_date AS REGISTRATION_DATE,
        event.name AS NAME,
        event.is_case_entity AS IS_CASE_ENTITY,
        TIMESTAMP(
            CONCAT(
                SUBSTR(fei.feibegindate, 0, 4),"-",
                SUBSTR(fei.feibegindate, 5, 2),"-",
                SUBSTR(fei.feibegindate, 7, 2)," ",
                SUBSTR(fei.feibeginhour, 0, 2),":",
                SUBSTR(fei.feibeginhour, 3, 2),":00"
            )
        ) AS START_DATE,
        TIMESTAMP(
            CONCAT(
                SUBSTR(fei.feienddate, 0, 4),"-",
                SUBSTR(fei.feienddate, 5, 2),"-",
                SUBSTR(fei.feienddate, 7, 2)," ",
                SUBSTR(fei.feiendhour, 0, 2),":",
                SUBSTR(fei.feiendhour, 3, 2),":00"
            )
        ) AS END_DATE,
        CASE
            WHEN fei.feiinfotype IS NULL THEN TRUE
            WHEN CAST(fei.feiinfotype AS INT) = 1 THEN FALSE
        END AS IS_CONCRETE,
        fei.feiisattempt AS IS_ATTEMPT,
        CAST(fei.feinaturecat AS BIGINT) AS FACT_CATEGORY_ID,
        CAST(fei.feinatureclass AS BIGINT) AS FACT_CLASS_ID,
        CAST(fei.feiqualification AS BIGINT) AS FACT_QUALIFICATION_ID,
        NULL AS MODUS_OPERANDI_ID
    FROM ${i3_db}.`EVENT` AS event
    INNER JOIN ${i3_db_staging}.mapping_case_items AS mci
        ON mci.CASE_ITEM_GENERATED_ID = event.id
        AND mci.source_table = "mapping_case_entities"
    INNER JOIN ${i3_db_staging}.mapping_case_entities AS mce
        ON mce.CASE_ENTITY_STAGING_ID = mci.CASE_ITEM_STAGING_ID
        AND mce.TARGET_TYPE = mci.TARGET_TYPE
        AND mce.TARGET_TYPE = "OFFENCE"
    INNER JOIN ${raw_questis}.`fei` AS fei
            ON CAST(CONV(fei.FEINCDBKEY,16,10) AS BIGINT) = mce.QUESTIS_ID
                AND from_unixtime(unix_timestamp(fei.feitechts ,'yyyyMMddHHmmss')) = event.last_modification_time
    WHERE event.event_type_id = 10
)
