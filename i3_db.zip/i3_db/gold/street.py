
from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    
    raw_references = conf_variables['raw_references']

    query = f"""
    SELECT
        "REFTAB" AS LEGACY_SOURCE,
        "STR" AS LEGACY_TABLE,
        CAST(str.strkey AS BIGINT) AS LEGACY_ID,
        UPPER(CAST(str.strtextbe AS STRING)) AS LABEL,
        CAST(str.strtextbf AS STRING) AS LABEL_FR,
        CAST(str.strtextbd AS STRING) AS LABEL_NL,
        CAST(str.strtextbg AS STRING) AS LABEL_DE,
        CAST(str.strtextbe AS STRING) AS LABEL_EN
    FROM {raw_references}.reftab_rstr str
        
      """

    street = sparkSession.sql(query)
    street = street.withColumn("ID", monotonically_increasing_id())

    return street
