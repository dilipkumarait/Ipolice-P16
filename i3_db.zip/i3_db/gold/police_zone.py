
from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    
    raw_references = conf_variables['raw_references']

    query = f"""
    SELECT
        "REFTAB" AS LEGACY_SOURCE,
        "OCP" AS LEGACY_TABLE,
        CAST(ocp.ocpKey AS BIGINT) AS LEGACY_ID,
        UPPER(CAST(ocp.ocptextbe AS STRING)) AS LABEL,
        CAST(ocp.ocptextbf AS STRING) AS LABEL_FR,
        CAST(ocp.ocptextbd AS STRING) AS LABEL_NL,
        CAST(ocp.ocptextbg AS STRING) AS LABEL_DE,
        CAST(ocp.ocptextbe AS STRING) AS LABEL_EN
    FROM {raw_references}.reftab_rocp ocp        
      """

    police_zone = sparkSession.sql(query)
    police_zone = police_zone.withColumn("ID", monotonically_increasing_id())

    return police_zone
