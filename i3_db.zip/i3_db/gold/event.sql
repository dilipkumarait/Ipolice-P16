-----------------------------------------------------------
-- Description: Script used to create the table Event -----
-----------------------------------------------------------

CREATE TABLE ${i3_db}.`EVENT` (
    `ID` BIGINT,
    `REGISTRATION_CASE_YEAR` INT,
    `REGISTRATION_CASE_NUMBER` BIGINT,
    `NAME` STRING,
    `IS_CASE_ENTITY` BOOLEAN,
    `REGISTRATION_DATE` TIMESTAMP,
    `START_DATE` TIMESTAMP,
    `END_DATE` TIMESTAMP,
    `EVENT_TYPE_ID` BIGINT,
    `LAST_MODIFICATION_TIME` TIMESTAMP
)
STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.EVENT (
    SELECT
        e.id AS ID,
        e.registration_case_year AS REGISTRATION_CASE_YEAR,
        e.registration_case_number AS REGISTRATION_CASE_NUMBER,
        'Événement' AS NAME,
        e.is_case_entity AS IS_CASE_ENTITY,
        e.registration_date AS REGISTRATION_DATE,
        NULL AS START_DATE,
        NULL AS END_DATE,
        e.entity_sub_type_id AS EVENT_TYPE_ID,
        e.last_modification_time AS LAST_MODIFICATION_TIME
    FROM ${i3_db}.`ENTITY` e
    WHERE e.entity_type_id = 3
        AND e.is_case_entity = True
)
