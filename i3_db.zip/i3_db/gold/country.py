
from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    
    raw_references = conf_variables['raw_references']

    query = f"""
    SELECT
        "REFTAB" AS LEGACY_SOURCE,
        "LND" AS LEGACY_TABLE,
        CAST(lnd.lndkey AS BIGINT) AS LEGACY_ID,
        UPPER(CAST(lndtextbe AS STRING)) AS LABEL,
        CAST(lndtextbf AS STRING) AS LABEL_FR,
        CAST(lndtextbd AS STRING) AS LABEL_NL,
        CAST(lndtextbg AS STRING) AS LABEL_DE,
        CAST(lndtextbe AS STRING) AS LABEL_EN
    FROM {raw_references}.reftab_rlnd lnd
        
      """

    country = sparkSession.sql(query)
    country = country.withColumn("ID", monotonically_increasing_id())

    return country
