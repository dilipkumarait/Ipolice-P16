-----------------------------------------------------------
-- Description: Create and add data to table entity_sub_type --
-----------------------------------------------------------

CREATE TABLE ${i3_db}.`ENTITY_SUB_TYPE` (
    `ID` BIGINT,
    `LABEL` STRING,
    `ENTITY_TYPE_ID` BIGINT
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.`ENTITY_SUB_TYPE`
VALUES 
    -- Person Types
    (1, 'MORAL_PERSON', 1),
    (2, 'GROUPING', 1),
    (3, 'NATURAL_PERSON', 1),
    -- Event Types
    (4, 'TRANSACTION', 3),
    (5, 'ACTION_TO_TAKE_DECISION', 3),
    (6, 'DRIVING_RESTRAINTS_CONVICTION', 3),
    (7, 'PUBLIC_EVENT', 3),
    (8, 'ACCIDENT', 3),
    (9, 'SUSPICIOUS_BEHAVIOR', 3),
    (10, 'OFFENCE', 3),
    -- Object Types
    (11, 'INTELLECTUAL_PROPERTY', 4),
    (12, 'PHONE_NUMBER', 4),
    (13, 'LICENCE_PLATE', 4),
    (14, 'EMAIL_ADDRESS', 4),
    (15, 'BANK_ACCOUNT_NUMBER', 4),
    (16, 'ID_SOCIAL_MEDIA', 4),
    (17, 'DOCUMENT', 4),
    (18, 'DRIVING_LICENSE', 4),
    (19, 'IDENTITY_CARD', 4),
    (20, 'DRUG', 4),
    (21, 'TOOL', 4),
    (22, 'WEAPON', 4),
    (23, 'FIREARM', 4),
    (24, 'VEHICLE', 4),
    (26, 'REFERENCE', 4),
    (27, 'OBJECT_GROUP', 4),
    (28, 'JUDICIAL_PHENOMENON', 5),
    (29, 'ADMINISTRATIVE_PHENOMENON', 5),
    -- Location Types
    (30, 'POINT_OF_INTEREST', 2);

