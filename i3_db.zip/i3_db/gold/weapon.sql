
CREATE TABLE ${i3_db}.`WEAPON`(
    `ID` BIGINT,
    `CREATION_YEAR` INT,
    `REGISTRATION_CASE_YEAR` INT,
    `REGISTRATION_CASE_NUMBER` BIGINT,
    `NAME` STRING,
    `IS_CASE_ENTITY` BOOLEAN,
    `REGISTRATION_DATE` TIMESTAMP,
    `WEAPON_TYPE_ID` BIGINT
)
STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.`WEAPON` (
    SELECT
        o.id AS ID,
        YEAR(o.registration_date) AS CREATION_YEAR,
        o.registration_case_year AS REGISTRATION_CASE_YEAR,
        o.registration_case_number AS REGISTRATION_CASE_NUMBER,
        o.name AS NAME,
        o.is_case_entity AS is_case_entity,
        o.registration_date AS REGISTRATION_DATE,
        o.object_type_id AS WEAPON_TYPE_ID
    FROM ${i3_db}.`OBJECT` o
    WHERE o.object_type_id = 23
);
