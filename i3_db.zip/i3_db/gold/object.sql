-----------------------------------------------------------
--- Description: Script used to create the table Object ---
-----------------------------------------------------------

CREATE TABLE ${i3_db}.`OBJECT`
(
    `ID` BIGINT,
    `REGISTRATION_CASE_YEAR` INT,
    `REGISTRATION_CASE_NUMBER` BIGINT,
    `NAME` STRING,
    `IS_CASE_ENTITY` BOOLEAN,
    `REGISTRATION_DATE` TIMESTAMP,
    `OBJECT_TYPE_ID` BIGINT,
    `CREATION_DATE` INT
)
STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');


INSERT INTO ${i3_db}.`OBJECT` (
    SELECT
        e.id AS ID,
        e.registration_case_year AS REGISTRATION_CASE_YEAR,
        e.registration_case_number AS REGISTRATION_CASE_NUMBER,
        e.name AS NAME,
        e.is_case_entity AS IS_CASE_ENTITY,
        e.registration_date AS REGISTRATION_DATE,
        e.entity_sub_type_id as OBJECT_TYPE_ID,
        NULL AS CREATION_DATE
    FROM ${i3_db}.ENTITY e
    WHERE e.entity_type_id = 4
    AND e.is_case_entity = True
);
