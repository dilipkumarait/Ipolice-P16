-----------------------------------------------------------
-- Description: Create and add data to table event_type --
-----------------------------------------------------------

CREATE TABLE ${i3_db}.`EVENT_TYPE` (
    `ID` BIGINT,
    `LABEL` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');


INSERT INTO ${i3_db}.`EVENT_TYPE`
VALUES (1, 'TRANSACTION'),
       (2, 'ACTION_TO_TAKE_DECISION'),
       (3, 'DRIVING_RESTRAINTS_CONVICTION'),
       (4, 'PUBLIC_EVENT'),
       (5, 'ACCIDENT'),
       (6, 'SUSPICIOUS_BEHAVIOR'),
       (7, 'OFFENCE');