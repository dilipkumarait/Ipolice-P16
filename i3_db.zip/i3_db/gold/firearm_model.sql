

CREATE TABLE ${i3_db}.`FIREARM_MODEL` (
    `ID` BIGINT,
    `LABEL` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');


INSERT INTO ${i3_db}.`FIREARM_MODEL` (
    SELECT
        ROW_NUMBER() OVER (ORDER BY gvwmodel) AS FIREARM_MAKE_ID,
        gvwmodel AS LABEL
    FROM (
	    SELECT DISTINCT TRIM(gvwtype) AS gvwmodel
            FROM ${raw_questis}.`gvw`
    ) AS `gvwmodel`
    ORDER BY gvwmodel
);
