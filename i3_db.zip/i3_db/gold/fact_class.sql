CREATE TABLE IF NOT EXISTS ${i3_db}.`FACT_CLASS` (
    `ID` BIGINT,
    `LEGACY_SOURCE` STRING,
    `LEGACY_TABLE` STRING,
    `LEGACY_ID` BIGINT,
    `LABEL` STRING,
    `LABEL_FR` STRING,
    `LABEL_NL` STRING,
    `LABEL_DE` STRING,
    `LABEL_EN` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

--Filling fact_class table
INSERT INTO ${i3_db}.FACT_CLASS (
    SELECT
        ROW_NUMBER() OVER (ORDER BY afekey) AS ID,
        'REFTAB' AS LEGACY_SOURCE,
        'AFE' AS LEGACY_TABLE,
        CAST(afekey AS BIGINT) AS LEGACY_ID,
        UPPER(afeTextBE) AS LABEL,
        afeTextBF AS LABEL_FR,
        afeTextBD AS LABEL_NL,
        afeTextBG AS LABEL_DE,
        afeTextBE AS LABEL_EN
    FROM ${raw_references}.reftab_rafe
);
