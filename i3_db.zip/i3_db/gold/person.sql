-----------------------------------------------------------
--- Description: Script used to create the table person ---
-----------------------------------------------------------

CREATE TABLE ${i3_db}.`PERSON` (
    `ID` BIGINT,
    `REGISTRATION_CASE_YEAR` INT,
    `REGISTRATION_CASE_NUMBER` BIGINT,
    `IS_CASE_ENTITY` BOOLEAN,
    `NAME` STRING,
    `PERSON_TYPE_ID` BIGINT,
    `REGISTRATION_DATE` TIMESTAMP
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

-- Chargement des personnes physiques depuis la table entity
INSERT INTO ${i3_db}.`PERSON` (
    SELECT
        e.id AS ID,
        e.registration_case_year AS REGISTRATION_CASE_YEAR,
        e.registration_case_number AS REGISTRATION_CASE_NUMBER,
        e.is_case_entity AS IS_CASE_ENTITY,
        e.name AS NAME,
        e.entity_sub_type_id AS PERSON_TYPE_ID,
        e.registration_date AS REGISTRATION_DATE
    FROM ${i3_db}.`ENTITY` e
    WHERE e.entity_type_id = 1
        AND e.is_case_entity
)