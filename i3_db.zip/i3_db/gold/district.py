
from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    
    raw_references = conf_variables['raw_references']

    query = f"""
    SELECT
        "REFTAB" AS LEGACY_SOURCE,
        "ARJ" AS LEGACY_TABLE,
        CAST(arj.arjkey AS STRING) AS LEGACY_ID,
        UPPER(CAST(arjtextbe AS STRING)) AS LABEL,
        CAST(arjtextbf AS STRING) AS LABEL_FR,
        CAST(arjtextbd AS STRING) AS LABEL_NL,
        CAST(arjtextbg AS STRING) AS LABEL_DE,
        CAST(arjtextbe AS STRING) AS LABEL_EN
    FROM {raw_references}.reftab_rarj arj
        
      """

    district = sparkSession.sql(query)
    district = district.withColumn("ID", monotonically_increasing_id())

    return district