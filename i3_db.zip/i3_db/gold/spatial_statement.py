#--------------------------------------------------------------
#-- Description: Create and add data to table statement_type --
#--------------------------------------------------------------

from pyspark.sql.functions import lit
from pyspark.sql.functions import col
from pyspark.sql.functions import row_number
from pyspark.sql.window import Window


def load_table(sparkSession, conf_variables):
    # TODO: Load json file here to replace hard coded source DB
    i3_db = conf_variables["i3_db"]
    i3_db_staging = conf_variables["i3_db_staging"]

    sdf_statement = sparkSession.sql(f"""
        SELECT 
            statement_id as ID,
            REGISTRATION_CASE_YEAR,
            REGISTRATION_CASE_NUMBER,
            REGISTRATION_DATE,
            cast(NULL as INT) as RELIABILITY,
            start_date_time as START_DATE,
            end_date_time as END_DATE,
            cast(NULL as BIGINT) as SPATIAL_STATEMENT_TYPE_ID,
            SOURCE_ENTITY_ID,
            SOURCE_ENTITY_TYPE_ID,
            SOURCE_ENTITY_SUB_TYPE_ID,
            TARGET_ENTITY_ID,
            TARGET_ENTITY_TYPE_ID,
            TARGET_ENTITY_SUB_TYPE_ID,
            cast(NULL as STRING) as FREE_DESCRIPTION,
            cast(NULL as BIGINT) as LOCATION_DESCRIPTION_ID,
            cast(NULL as FLOAT) as PRECISION,
            cast(NULL as BIGINT) as SHAPE_TYPE_ID,
            cast(NULL as STRING) as SHAPE_WKT,
            row_number() over(order by statement_id) as tech_id
        FROM {i3_db}.statement
    """)

        # Chargement de la table generic_location
    generic_location = sparkSession.sql(f"""
        SELECT *
        FROM {i3_db_staging}.generic_location    
    """)

    # Taille des tables
    size_sdf_statement = sdf_statement.count()
    size_generic_location = generic_location.count()

    nb_item_to_generate = size_sdf_statement - size_generic_location
    if nb_item_to_generate > 0:
        tmp_gen_loc = generic_location.rdd.takeSample(True,nb_item_to_generate)
        tmp_gen_loc = sparkSession.createDataFrame(tmp_gen_loc, generic_location.schema)
        generic_location = generic_location.union(tmp_gen_loc)


    w = Window().orderBy(lit('ID'))
    generic_location = generic_location.withColumn("tech_id", row_number().over(w))

    stm_cols = sdf_statement.columns
    gcl_cols = ["house_box", "house_number", "municipality_id", "postal_code_id", "street_id", "tech_id"]

    final_df = sdf_statement.select(stm_cols).join(
        generic_location.selectExpr(gcl_cols), how="inner", on='tech_id'
    )

    # Retypage des champs + Alias
    final_df = final_df.select(*(
        col("SPATIAL_STATEMENT_ID").cast("bigint").alias("SPATIAL_STATEMENT_ID"),
        col("REGISTRATION_CASE_YEAR").cast("int").alias("REGISTRATION_CASE_YEAR"),
        col("REGISTRATION_CASE_NUMBER").cast("BIGINT").alias("REGISTRATION_CASE_NUMBER" ),
        col("REGISTRATION_DATE").cast("TIMESTAMP").alias("REGISTRATION_DATE" ),
        col("RELIABILITY" ).cast("BOOLEAN").alias("RELIABILITY"),
        col("START_DATE").cast("TIMESTAMP").alias("START_DATE"),
        col("END_DATE").cast("TIMESTAMP").alias("END_DATE"),
        col("SPATIAL_STATEMENT_TYPE_ID").cast("BIGINT").alias("SPATIAL_STATEMENT_TYPE_ID"),
        col("SOURCE_ENTITY_ID").cast("bigint").alias("SOURCE_ENTITY_ID"),
        col("SOURCE_ENTITY_TYPE_ID").cast("BIGINT").alias("SOURCE_ENTITY_TYPE_ID"),
        col("SOURCE_ENTITY_SUB_TYPE_ID").cast("BIGINT").alias("SOURCE_ENTITY_SUB_TYPE_ID"),
        col("TARGET_ENTITY_ID").cast("BIGINT").alias("TARGET_ENTITY_ID"),
        col("TARGET_ENTITY_TYPE_ID").cast("BIGINT").alias("TARGET_ENTITY_TYPE_ID"),
        col("TARGET_ENTITY_SUB_TYPE_ID").cast("BIGINT").alias("TARGET_ENTITY_SUB_TYPE_ID"),
        col("FREE_DESCRIPTION").cast("STRING").alias("FREE_DESCRIPTION"),
        col("LOCATION_DESCRIPTION_ID").cast("BIGINT").alias("LOCATION_DESCRIPTION_ID"),
        col("PRECISION").cast("FLOAT").alias("PRECISION"),
        col("SHAPE_TYPE_ID").cast("BIGINT").alias("SHAPE_TYPE_ID"),
        col("SHAPE_WKT").cast("STRING").alias("SHAPE_WKT"),
        col("house_box").cast("INT").alias("ADDRESS_BOX_NR"),
        col("house_number").cast("INT").alias("ADDRESS_HOUSE_NR"),
        lit("1").cast("BIGINT").alias("ADDRESS_COUNTRY_ID"),
        col("municipality_id").cast("BIGINT").alias("ADDRESS_MUNICIPALITY_ID"),
        lit("NULL").cast("BIGINT").alias("ADDRESS_SUB_MUNICIPALITY_ID"),
        col("postal_code_id").cast("BIGINT").alias("ADDRESS_POSTAL_CODE_ID"),
        col("street_id").cast("BIGINT").alias("ADDRESS_STREET_ID")
        )
    )

    return final_df