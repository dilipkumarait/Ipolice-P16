------------------------------------------------------------------
--- Description: Script used to create the table LOCATION_TYPE ---
------------------------------------------------------------------

CREATE TABLE ${i3_db}.`LOCATION_TYPE` (
    `ID` BIGINT,
    `LABEL` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.`LOCATION_TYPE`
VALUES (30, 'POINT_OF_INTEREST');