-----------------------------------------------------------
-- Description: Create and add data to table Vehicle ------
-----------------------------------------------------------

CREATE TABLE ${i3_db}.`VEHICLE`(
    `ID` BIGINT,
    `REGISTRATION_CASE_YEAR` INT,
    `REGISTRATION_CASE_NUMBER` BIGINT,
    `NAME` STRING,
    `IS_CASE_ENTITY` BOOLEAN,
    `REGISTRATION_DATE` TIMESTAMP,
    `CREATION_YEAR` INT,
    `CHASSIS_NUMBER` STRING,
    `VEHICLE_MAKE_ID` BIGINT,
    `VEHICLE_MODEL_ID` BIGINT,
    `COLOR_ID` BIGINT
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.`VEHICLE` (
    SELECT
        obj.ID AS ID,
        obj.registration_case_year AS REGISTRATION_CASE_YEAR,
        obj.registration_case_number AS REGISTRATION_CASE_NUMBER,
        CAST(CONV(gvm.gvmnaam,16,10) AS STRING) AS NAME,
        obj.is_case_entity AS IS_CASE_ENTITY,
        TIMESTAMP(
            CONCAT(
                SUBSTR(gvm.gvminputdate, 0, 4),"-",
                SUBSTR(gvm.gvminputdate, 5, 2),"-",
                SUBSTR(gvm.gvminputdate, 7, 2)," ",
                SUBSTR(gvm.gvminputtime, 0, 2),":",
                SUBSTR(gvm.gvminputtime, 3, 2),":00"
            )
        ) AS REGISTRATION_DATE,
        SUBSTR(gvm.gvminputdate, 0, 4) AS CREATION_YEAR,
       -- cast(conv(gvmidentifnr,16,10) as int) as chassis_number,
        obj.ID AS CHASSIS_NUMBER,
        CAST(gvm.gvmcat AS BIGINT) AS VEHICLE_MAKE_ID,
        CAST(gvm.gvmclass AS BIGINT) AS VEHICLE_MODEL_ID,
        CAST(gvm.gvmaktklvoornm AS BIGINT) AS COLOR_ID
    FROM ${i3_db}.`OBJECT` AS obj
    INNER JOIN ${i3_db_staging}.mapping_case_items AS mci
        ON mci.CASE_ITEM_GENERATED_ID = obj.ID
        AND mci.source_table = "mapping_case_entities"
    INNER JOIN ${i3_db_staging}.mapping_case_entities mce
        ON mce.CASE_ENTITY_STAGING_ID = mci.CASE_ITEM_STAGING_ID
        AND mce.TARGET_TYPE = mci.TARGET_TYPE
        AND mce.TARGET_TYPE = "VEHICLE"
    INNER JOIN ${raw_questis}.`gvm` gvm
        ON CAST(CONV(gvm.gvmncdbkey,16,10) AS BIGINT) = mce.QUESTIS_ID
    WHERE obj.object_type_id = 24
);
