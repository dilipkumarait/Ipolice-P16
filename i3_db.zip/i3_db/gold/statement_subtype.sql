-----------------------------------------------------------------
-- Description: Create and add data to table STATEMENT_SUBTYPE --
-----------------------------------------------------------------

CREATE TABLE ${i3_db}.`STATEMENT_SUBTYPE` (
    STATEMENT_SUBTYPE_ID BIGINT,
    LABEL STRING,
    STATEMENT_TYPE_ID BIGINT,
    PARENT_SUBTYPE_ID BIGINT
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

INSERT INTO ${i3_db}.`STATEMENT_SUBTYPE`
VALUES (1, 'CASE_ENTITY-REAL_ENTITY', 2, NULL),
       (2, 'PERSON-PERSON', 2, NULL),
       (3, 'PERSON-OBJECT', 2, NULL),
       (4, 'PERSON-LOCATION', 2, NULL),
       (5, 'PERSON-EVENT', 2, NULL),
       (6, 'PERSON-PHENOMENON', 2, NULL),
       (7, 'IS_IDENTIFIED_AS', 2, 1),
       (8, 'NATURAL_PERSON-NATURAL_PERSON', 2, 2),
       (9, 'NATURAL_PERSON-ORGANISATION', 2, 2),
       (10, 'NATURAL_PERSON-GROUPING', 2, 2),
       (11, 'ORGANISATION-GROUPING', 2, 2),
       (12, 'USES', 2, 3),
       (13, 'OWNS', 2, 3),
       (14, 'HAS_LEGAL_ADDRESS', 2, 4),
       (15, 'HAS_DROP_POINT', 2, 4),
       (16, 'IS_LOCATED_IN', 2, 4),
       (17, 'PERSON-OFFENCE', 2, 5),
       (18, 'IS_ORGANISATOR', 2, 5),
       (19, 'IS_PARTICIPANT', 2, 5),
       (20, 'IS_RELATED_WITH', 2, 8),
       (21, 'IS_AN_ASSOCIATE_OF', 2, 8),
       (22, 'IS_PART_OF_ORGANISATION', 2, 9),
       (23, 'IS_PART_OF_GROUPING', 2, 10),
       (24, 'IS_LINKED_TO', 2, 11),
       (25, 'IS_VICTIM', 2, 17),
       (26, 'IS_COMPLICE', 2, 17),
       (27, 'IS_AUTHOR', 2, 17),
       (28, 'IS_SUSPECT', 2, 17),
       (29, 'OBJECT-OBJECT', 2, NULL),
       (30, 'OBJECT-OBJECT_GROUP', 2, NULL),
       (31, 'OBJECT-LOCATION', 2, NULL),
       (32, 'OBJECT-EVENT', 2, NULL),
       (33, 'IS_ASSOCIATED_WITH', 2, 29),
       (34, 'IS_PART_OF_GROUP', 2, 30),
       (35, 'IS_LOCATED_IN', 2, 31),
       (36, 'IS_OBJECT_OF_EVENT', 2, 32),
       (37, 'IS_USED_DURING', 2, 32),
       (38, 'EVENT-LOCATION', 2, NULL),
       (39, 'IS_LOCATED_IN', 2, 38),
       (40, 'PHENOMENON-EVENT', 2, NULL),
       (41, 'PHENOMENON-OFFENCE', 2, 40),
       (42, 'IS_PART_OF_PHENOMENON', 2, 41),
       (43, 'PERSON_ATTRIBUTE', 3, NULL),
       (44, 'IDENTIFYING_NATURAL_PERSON_ATTRIBUTE', 3, NULL);