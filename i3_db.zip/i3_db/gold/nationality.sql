CREATE TABLE IF NOT EXISTS ${i3_db}.`NATIONALITY` (
    `ID` BIGINT,
    `LEGACY_SOURCE` STRING,
    `LEGACY_TABLE` STRING,
    `LEGACY_ID` BIGINT,
    `LABEL` STRING,
    `LABEL_FR` STRING,
    `LABEL_NL` STRING,
    `LABEL_DE` STRING,
    `LABEL_EN` STRING
) STORED AS PARQUET
TBLPROPERTIES ('transactional'='false');

--Filling Nationality table
INSERT INTO ${i3_db}.`NATIONALITY` (
    SELECT
        ROW_NUMBER() OVER (ORDER BY napkey) AS ID,
        'REFTAB' AS LEGACY_SOURCE,
        'NAP' AS LEGACY_TABLE,
        CAST(napkey AS BIGINT) AS LEGACY_ID,
        UPPER(naptextbe) AS LABEL,
        naptextbf AS LABEL_FR,
        naptextbd AS LABEL_NL,
        naptextbg AS LABEL_DE,
        naptextbe AS LABEL_EN
    FROM ${raw_references}.reftab_rnap
);
