from pyspark.sql.types import StringType
from pyspark.sql.functions import col, max, lit
from pyspark.sql.functions import row_number
from pyspark.sql.window import Window
from pyspark.sql.functions import monotonically_increasing_id


def load_table(sparkSession, conf_variables):

    # Add Relation Case - Person (NaturalPerson)
    sdf_psof = add_statement(sparkSession, conf_variables, 2, 28, "PL2INPUTDATE", "SUSPECT NATURAL PERSON IN OFFENCE", "NATURAL PERSON","OFFENCE" , "pl2", "PL2", "PL2GPSNCDBKEY", "PL2FEINCDBKEY")
    sdf_ptf = add_statement(sparkSession, conf_variables, 2, 17, "PL2INPUTDATE", "NATURAL PERSON TO OFFENCE", "NATURAL PERSON", "OFFENCE", "pl2", "PL2", "PL2GPSNCDBKEY", "PL2FEINCDBKEY")
    sdf_pov = add_statement(sparkSession, conf_variables, 2, 12, "GB3INPUTDATE", "NATURAL PERSON OWNS VEHICLE", "NATURAL PERSON", "VEHICLE", "gb3", "GB3", "GB3GPSNCDBKEY", "GB3GVMNCDBKEY")
    sdf_puv = add_statement(sparkSession, conf_variables, 2, 13, "GB3INPUTDATE", "NATURAL PERSON USES VEHICLE", "NATURAL PERSON", "VEHICLE", "gb3", "GB3", "GB3GPSNCDBKEY", "GB3GVMNCDBKEY")
    sdf_pol = add_statement(sparkSession, conf_variables, 2, 12, "GB3INPUTDATE", "NATURAL PERSON OWNS LICENSE PLATE", "NATURAL PERSON", "VEHICLE", "gb3", "GB3", "GB3GPSNCDBKEY", "GB3GVMNCDBKEY")
    sdf_pul = add_statement(sparkSession, conf_variables, 2, 13, "GB3INPUTDATE", "NATURAL PERSON USES LICENSE PLATE", "NATURAL PERSON", "VEHICLE", "gb3", "GB3", "GB3GPSNCDBKEY", "GB3GVMNCDBKEY")
    sdf_pip_bzk = add_statement(sparkSession, conf_variables, 2, 16, "BZKINPUTDATE", "NATURAL PERSON IS LOCATED IN PLACE", "NATURAL PERSON", "LOCATION", "bzk", "BZK", "BZKGPSNCDBKEY", "BZKGPLNCDBKEY")
    # To verity first : sdf_pip_mtp = add_statement(sparkSession, conf_variables, 2, 16, "MTPTECHTS", "NATURAL PERSON IS LOCATED IN PLACE", "NATURAL PERSON", "LOCATION", "mtp", "MTP", "MTPGPSNCDBKEY", "AD1ADDNCDBKEY")
    sdf_phlp_bzk = add_statement(sparkSession, conf_variables, 2, 14, "BZKINPUTDATE", "NATURAL PERSON HAS LEGAL ADDRESS AT PLACE", "NATURAL PERSON", "LOCATION", "bzk", "BZK", "BZKGPSNCDBKEY", "BZKGPLNCDBKEY")
    # To verify first : sdf_phlp_mtp = add_statement(sparkSession, conf_variables, 2, 14, "MTPTECHTS", "NATURAL PERSON HAS LEGAL ADDRESS AT PLACE", "NATURAL PERSON", "LOCATION", "mtp", "MTP", "MTPGPSNCDBKEY", "AD1ADDNCDBKEY")
    
    # BND NOT IN mapping_deduced_relations: sdf_ptp = add_statement(sparkSession, conf_variables, 2, 2, "PL2INPUTDATE", "SUSPECT NATURAL PERSON IN FACT", "NATURAL PERSON", "NATURAL PERSON", "bnd", "PL2FEINCDBKEY", "PL2GPSNCDBKEY")
    # OP1 NOT IN sdf_op1 = add_statement(sparkSession, conf_variables, 2, 10, "OP1INPUTDATE", "SUSPECT NATURAL PERSON IN FACT", "FACT", "NATURAL PERSON", "pl2", "PL2FEINCDBKEY", "PL2GPSNCDBKEY")
    sdf_fip = add_statement(sparkSession, conf_variables, 2, 17, "PL1INPUTDATE", "OFFENCE LOCATED IN PLACE", "OFFENCE", "LOCATION", "pl1", "PL1", "PL1FEINCDBKEY", "PL1GPLNCDBKEY")
    sdf_vudo = add_statement(sparkSession, conf_variables, 2, 37, "VB4INPUTDATE", "VEHICLE IS USED DURING OFFENCE", "OFFENCE", "VEHICLE", "vb4", "VB4", "VB4FEINCDBKEY", "VB4GVMNCDBKEY")
    sdf_pof = add_statement(sparkSession, conf_variables, 2, 12, "PW1INPUTDATE", "NATURAL PERSON OWNS FIREARM", "NATURAL PERSON", "FIREARM", "pw1", "PW1", "PW1GPSNCDBKEY", "PW1GVWNCDBKEY")
    sdf_puf = add_statement(sparkSession, conf_variables, 2, 13, "PW1INPUTDATE", "NATURAL PERSON USES FIREARM", "NATURAL PERSON", "FIREARM", "pw1", "PW1", "PW1GPSNCDBKEY", "PW1GVWNCDBKEY")
    sdf_popn = add_statement(sparkSession, conf_variables, 2, 12, "PN1INPUTDATE", "NATURAL PERSON OWNS PHONE NUMBER", "NATURAL PERSON", "PHONE NUMBER", "pn1", "PN1", "PN1GPSNCDBKEY", "PN1NUMNCDBKEY")
    sdf_pupn = add_statement(sparkSession, conf_variables, 2, 13, "PN1INPUTDATE", "NATURAL PERSON USES PHONE NUMBER", "NATURAL PERSON", "PHONE NUMBER", "pn1", "PN1", "PN1GPSNCDBKEY", "PN1NUMNCDBKEY")
    # bizarre: sdf_ptg = add_statement(sparkSession, conf_variables, 2, 28, "PL2INPUTDATE", "SUSPECT NATURAL PERSON IN FACT", "FACT", "NATURAL PERSON", "pl2", "PL2FEINCDBKEY", "PL2GPSNCDBKEY")
    sdf_poe = add_statement(sparkSession, conf_variables, 2, 12, "PN1INPUTDATE", "NATURAL PERSON OWNS EMAIL ADDRESS", "NATURAL PERSON", "EMAIL ADDRESS", "pn1", "PN1", "PN1GPSNCDBKEY", "PN1NUMNCDBKEY")
    sdf_pue = add_statement(sparkSession, conf_variables, 2, 13, "PN1INPUTDATE", "NATURAL PERSON USES EMAIL ADDRESS", "NATURAL PERSON", "EMAIL ADDRESS", "pn1", "PN1", "PN1GPSNCDBKEY", "PN1NUMNCDBKEY")

    # Is identified as
    sdf_person_iia = add_statement_is_identified_as(sparkSession, conf_variables, "GPSINPUTDATE", "IDENTIFIED NATURAL PERSON", "NATURAL PERSON", "gps", "GPS", "gpsncdbkey")
    sdf_offense_iia = add_statement_is_identified_as(sparkSession, conf_variables, "FEIINPUTDATE", "IDENTIFIED OFFENCE", "OFFENCE", "fei", "FEI", "feincdbkey")
    
    # Fusion de toutes les tables
    final_df = sdf_psof.union(sdf_ptf)
    final_df = final_df.union(sdf_pov)
    final_df = final_df.union(sdf_puv)
    final_df = final_df.union(sdf_pol)
    final_df = final_df.union(sdf_pul)
    final_df = final_df.union(sdf_pip_bzk)
    final_df = final_df.union(sdf_phlp_bzk)
    final_df = final_df.union(sdf_fip)
    final_df = final_df.union(sdf_vudo)
    final_df = final_df.union(sdf_pof)
    final_df = final_df.union(sdf_puf)
    final_df = final_df.union(sdf_popn)
    final_df = final_df.union(sdf_pupn)
    final_df = final_df.union(sdf_poe)
    final_df = final_df.union(sdf_pue)

    # Ajout des relations is_identified_as
    final_df = final_df.union(sdf_person_iia)
    final_df = final_df.union(sdf_offense_iia)

    return final_df


def add_statement(
        sparkSession, 
        conf_variables,
        entity_type_id,
        entity_sub_type_id,
        questis_date_field,
        relation_target_type,
        source_target_type,
        target_target_type,
        quetis_table_name,
        questis_source_tag,
        questis_fk1,
        questis_fk2,
        default_select = {
            "id":None,
            "reg_case_year": None,
            "reg_case_num": None,
            "stm_type_id": None,
            "stm_subtype_id": None,
            "reg_date": None,
            "reliability": None,
            "start_date": None,
            "end_date": None,
            "source_id": None,
            "source_type_id": None,
            "source_subtype_id": None,
            "target_id": None,
            "target_type_id": None,
            "target_subtype_id": None,
            "status_id": None
        }
    ):

    i3_db = conf_variables["i3_db"]
    i3_db_staging = conf_variables["i3_db_staging"]
    raw_questis = conf_variables["raw_questis"]

    # Prépare default_select dictionnary
    select_dict = default_select.copy()
    if "id" not in select_dict:
        select_dict["id"] = None
    if "reg_case_year" not in select_dict:
        select_dict["reg_case_year"] = None
    if "reg_case_num" not in select_dict:
        select_dict["reg_case_num"] = None
    if "stm_type_id" not in select_dict:
        select_dict["stm_type_id"] = None
    if "stm_subtype_id" not in select_dict:
        select_dict["stm_subtype_id"] = None
    if "reliability" not in select_dict:
        select_dict['reliability'] = None
    if "start_date" not in select_dict:
        select_dict['start_date'] = None
    if "end_date" not in select_dict:
        select_dict['end_date'] = None
    if "source_id" not in select_dict:
        select_dict["source_id"] = None
    if "source_type_id" not in select_dict:
        select_dict["source_type_id"] = None
    if "source_subtype_id" not in select_dict:
        select_dict["source_subtype_id"] = None
    if "target_id" not in select_dict:
        select_dict["target_id"] = None
    if "target_type_id" not in select_dict:
        select_dict["target_type_id"] = None
    if "target_subtype_id" not in select_dict:
        select_dict["target_subtype_id"] = None
    if "status_id" not in select_dict:
        select_dict["status_id"] = None
    if "reg_date" not in select_dict:
        select_dict["reg_date"] = None

    # Define the fields to select
    STATEMENT_ID = "mci.CASE_ITEM_GENERATED_ID AS ID" if select_dict["id"] is None else select_dict["id"]
    REGISTRATION_CASE_YEAR = "cse.case_year AS REGISTRATION_CASE_YEAR" if select_dict["reg_case_year"] is None else select_dict["reg_case_year"]
    REGISTRATION_CASE_NUMBER = "cse.case_number AS REGISTRATION_CASE_NUMBER" if select_dict["reg_case_num"] is None else select_dict["reg_case_num"]
    STATEMENT_TYPE_ID = f"{entity_type_id} AS STATEMENT_TYPE_ID" if select_dict["stm_type_id"] is None else select_dict["stm_type_id"]
    STATEMENT_SUBTYPE_ID = f"{entity_sub_type_id} AS STATEMENT_SUBTYPE_ID" if select_dict["stm_subtype_id"] is None else select_dict["stm_subtype_id"]
    RELIABILITY_ID = f"1 AS RELIABILITY_ID" if select_dict["reliability"] is None else select_dict["reliability"]
    START_DATE_TIME = f"CAST(NULL AS TIMESTAMP) AS START_DATE_TIME" if select_dict["start_date"] is None else select_dict["start_date"]
    END_DATE_TIME = f"CAST(NULL AS TIMESTAMP) AS END_DATE_TIME" if select_dict["end_date"] is None else select_dict["end_date"]
    SOURCE_ENTITY_ID = f"mci_e1.CASE_ITEM_GENERATED_ID AS SOURCE_ENTITY_ID" if select_dict["source_id"] is None else select_dict["source_id"]
    SOURCE_ENTITY_TYPE_ID = f"ent_1.entity_type_id AS SOURCE_ENTITY_TYPE_ID" if select_dict["source_type_id"] is None else select_dict["source_type_id"]
    SOURCE_ENTITY_SUB_TYPE_ID = f"ent_1.entity_sub_type_id AS SOURCE_ENTITY_SUB_TYPE_ID" if select_dict["source_subtype_id"] is None else select_dict["source_subtype_id"]
    TARGET_ENTITY_ID = f"mci_e2.CASE_ITEM_GENERATED_ID AS TARGET_ENTITY_ID" if select_dict["target_id"] is None else select_dict["target_id"]
    TARGET_ENTITY_TYPE_ID = f"ent_2.entity_type_id AS TARGET_ENTITY_TYPE_ID" if select_dict["target_type_id"] is None else select_dict["target_type_id"]
    TARGET_ENTITY_SUB_TYPE_ID = f"ent_2.entity_sub_type_id AS TARGET_ENTITY_SUB_TYPE_ID" if select_dict["target_subtype_id"] is None else select_dict["target_subtype_id"]
    STATEMENT_STATUS_ID = f"1 AS STATEMENT_STATUS_ID" if select_dict["status_id"] is None else select_dict["status_id"]
    REGISTRATION_DATE = f"""
        DATE(
            CONCAT(
                SUBSTR(qtbl.{questis_date_field}, 0, 4),"-",
                SUBSTR(qtbl.{questis_date_field}, 5, 2),"-",
                SUBSTR(qtbl.{questis_date_field}, 7, 2)
            )
        ) AS REGISTRATION_DATE
    """ if select_dict["reg_date"] is None else select_dict["reg_date"]

    # Build and execute query
    statement_table = sparkSession.sql(f"""
        SELECT      
            {STATEMENT_ID},
            {REGISTRATION_CASE_YEAR},
            {REGISTRATION_CASE_NUMBER},
            {STATEMENT_TYPE_ID},
            {STATEMENT_SUBTYPE_ID},
            {REGISTRATION_DATE},
            {RELIABILITY_ID},
            {START_DATE_TIME}, 
            {END_DATE_TIME},
            {SOURCE_ENTITY_ID}, 
            {SOURCE_ENTITY_TYPE_ID},
            {SOURCE_ENTITY_SUB_TYPE_ID},
            {TARGET_ENTITY_ID}, 
            {TARGET_ENTITY_TYPE_ID},
            {TARGET_ENTITY_SUB_TYPE_ID},
            {STATEMENT_STATUS_ID}

        FROM {i3_db_staging}.mapping_case_items mci
        INNER JOIN {i3_db_staging}.mapping_deduced_relations mdr
            ON mci.CASE_ITEM_STAGING_ID = mdr.RELATION_STAGING_ID
            AND mci.source_table = "mapping_deduced_relations"
            AND mci.target_type = "{relation_target_type}"
            AND mdr.source_table = "{questis_source_tag}"
        INNER JOIN {i3_db}.`case` cse
            ON cse.id = mdr.CASE_GENERATED_ID
        INNER JOIN {i3_db_staging}.mapping_case_items mci_e1
            ON mci_e1.source_table = "mapping_case_entities"
            AND mci_e1.CASE_ITEM_STAGING_ID = mdr.CASE_ENTITY_STAGING_ID_1
            AND mci_e1.TARGET_TYPE = "{source_target_type}"
        INNER JOIN {i3_db_staging}.mapping_case_items mci_e2
            ON mci_e2.source_table = "mapping_case_entities"
            AND mci_e2.CASE_ITEM_STAGING_ID = mdr.CASE_ENTITY_STAGING_ID_2
            AND mci_e2.TARGET_TYPE = "{target_target_type}"
        INNER JOIN {i3_db}.entity AS ent_1
            ON ent_1.id = mci_e1.CASE_ITEM_GENERATED_ID
        INNER JOIN {i3_db}.entity AS ent_2
            ON ent_2.id = mci_e2.CASE_ITEM_GENERATED_ID
        LEFT JOIN {raw_questis}.{quetis_table_name} qtbl
            ON mdr.CASE_ENTITY_STAGING_ID_1 = CAST(CONV(qtbl.{questis_fk1},16,10) AS BIGINT)
            AND mdr.CASE_ENTITY_STAGING_ID_2 = CAST(CONV(qtbl.{questis_fk2},16,10) AS BIGINT)
    """)
    
    return statement_table


def add_statement_is_identified_as(
        sparkSession, 
        conf_variables,
        questis_date_field,
        identification_type,
        target_type,
        quetis_table_name,
        questis_source_tag,
        questis_pk,
        default_select = {
            "id": None,
            "reg_case_year": None,
            "reg_case_num": None,
            "stm_type_id": None,
            "stm_subtype_id": None,
            "reg_date": None,
            "reliability": None,
            "start_date": None,
            "end_date": None,
            "source_id": None,
            "source_type_id": None,
            "source_subtype_id": None,
            "target_id": None,
            "target_type_id": None,
            "target_subtype_id": None,
            "status_id": None
        }
    ):

    i3_db = conf_variables["i3_db"]
    i3_db_staging = conf_variables["i3_db_staging"]
    raw_questis = conf_variables["raw_questis"]

    # Prépare default_select dictionnary
    select_dict = default_select.copy()
    if "id" not in select_dict:
        select_dict["id"] = None
    if "reg_case_year" not in select_dict:
        select_dict["reg_case_year"] = None
    if "reg_case_num" not in select_dict:
        select_dict["reg_case_num"] = None
    if "stm_type_id" not in select_dict:
        select_dict["stm_type_id"] = None
    if "stm_subtype_id" not in select_dict:
        select_dict["stm_subtype_id"] = None
    if "reliability" not in select_dict:
        select_dict['reliability'] = None
    if "start_date" not in select_dict:
        select_dict['start_date'] = None
    if "end_date" not in select_dict:
        select_dict['end_date'] = None
    if "source_id" not in select_dict:
        select_dict["source_id"] = None
    if "source_type_id" not in select_dict:
        select_dict["source_type_id"] = None
    if "source_subtype_id" not in select_dict:
        select_dict["source_subtype_id"] = None
    if "target_id" not in select_dict:
        select_dict["target_id"] = None
    if "target_type_id" not in select_dict:
        select_dict["target_type_id"] = None
    if "target_subtype_id" not in select_dict:
        select_dict["target_subtype_id"] = None
    if "status_id" not in select_dict:
        select_dict["status_id"] = None
    if "reg_date" not in select_dict:
        select_dict["reg_date"] = None

    # Define the fields to select
    STATEMENT_ID = "mci.CASE_ITEM_GENERATED_ID AS ID" if select_dict["id"] is None else select_dict["id"]
    REGISTRATION_CASE_YEAR = "cse.case_year AS REGISTRATION_CASE_YEAR" if select_dict["reg_case_year"] is None else select_dict["reg_case_year"]
    REGISTRATION_CASE_NUMBER = "cse.case_number AS REGISTRATION_CASE_NUMBER" if select_dict["reg_case_num"] is None else select_dict["reg_case_num"]
    STATEMENT_TYPE_ID = f"2 AS STATEMENT_TYPE_ID" if select_dict["stm_type_id"] is None else select_dict["stm_type_id"]
    STATEMENT_SUBTYPE_ID = f"7 AS STATEMENT_SUBTYPE_ID" if select_dict["stm_subtype_id"] is None else select_dict["stm_subtype_id"]
    RELIABILITY_ID = f"1 AS RELIABILITY_ID" if select_dict["reliability"] is None else select_dict["reliability"]
    START_DATE_TIME = f"CAST(NULL AS TIMESTAMP) AS START_DATE_TIME" if select_dict["start_date"] is None else select_dict["start_date"]
    END_DATE_TIME = f"CAST(NULL AS TIMESTAMP) AS END_DATE_TIME" if select_dict["end_date"] is None else select_dict["end_date"]
    SOURCE_ENTITY_ID = f"mci_e1.CASE_ITEM_GENERATED_ID AS SOURCE_ENTITY_ID" if select_dict["source_id"] is None else select_dict["source_id"]
    SOURCE_ENTITY_TYPE_ID = f"e1.entity_type_id AS SOURCE_ENTITY_TYPE_ID" if select_dict["source_type_id"] is None else select_dict["source_type_id"]
    SOURCE_ENTITY_SUB_TYPE_ID = f"e1.entity_sub_type_id AS SOURCE_ENTITY_SUB_TYPE_ID" if select_dict["source_subtype_id"] is None else select_dict["source_subtype_id"]
    TARGET_ENTITY_ID = f"mci_e2.CASE_ITEM_GENERATED_ID AS TARGET_ENTITY_ID" if select_dict["target_id"] is None else select_dict["target_id"]
    TARGET_ENTITY_TYPE_ID = f"e2.entity_type_id AS TARGET_ENTITY_TYPE_ID" if select_dict["target_type_id"] is None else select_dict["target_type_id"]
    TARGET_ENTITY_SUB_TYPE_ID = f"e2.entity_sub_type_id AS TARGET_ENTITY_SUB_TYPE_ID" if select_dict["target_subtype_id"] is None else select_dict["target_subtype_id"]
    STATEMENT_STATUS_ID = f"1 AS STATEMENT_STATUS_ID" if select_dict["status_id"] is None else select_dict["status_id"]
    REGISTRATION_DATE = f"""
        DATE(
            CONCAT(
                SUBSTR(qtbl.{questis_date_field}, 0, 4),"-",
                SUBSTR(qtbl.{questis_date_field}, 5, 2),"-",
                SUBSTR(qtbl.{questis_date_field}, 7, 2)
            )
        ) AS REGISTRATION_DATE
    """ if select_dict["reg_date"] is None else select_dict["reg_date"]

    # Build and execute query
    statement_table = sparkSession.sql(f"""
        SELECT      
            {STATEMENT_ID},
            {REGISTRATION_CASE_YEAR},
            {REGISTRATION_CASE_NUMBER},
            {STATEMENT_TYPE_ID},
            {STATEMENT_SUBTYPE_ID},
            {REGISTRATION_DATE},
            {RELIABILITY_ID},
            {START_DATE_TIME}, 
            {END_DATE_TIME},
            {SOURCE_ENTITY_ID}, 
            {SOURCE_ENTITY_TYPE_ID},
            {SOURCE_ENTITY_SUB_TYPE_ID},
            {TARGET_ENTITY_ID}, 
            {TARGET_ENTITY_TYPE_ID},
            {TARGET_ENTITY_SUB_TYPE_ID},
            {STATEMENT_STATUS_ID}

        FROM {i3_db_staging}.mapping_identification_relations mir
        INNER JOIN {i3_db_staging}.mapping_case_items mci
            ON mir.relation_staging_id = mci.CASE_ITEM_STAGING_ID
            AND mci.source_table = "mapping_identification_relations"

        INNER JOIN {i3_db_staging}.mapping_case_entities mce
            ON mce.QUESTIS_ID = mir.QUESTIS_ITEM_2_ID
            AND mir.target_type = "{identification_type}"
            AND mce.target_type = "{target_type}"
        INNER JOIN {i3_db_staging}.mapping_case_items mci_e1
            ON mci_e1.case_item_staging_id = mce.CASE_ENTITY_STAGING_ID
            AND mci_e1.target_type = mce.target_type
            AND mci_e1.source_table = "mapping_case_entities"

        INNER JOIN {i3_db_staging}.mapping_real_entities mre
            ON mre.questis_id = mir.QUESTIS_ITEM_2_ID
            AND mre.target_type = "{target_type}"
            AND mre.source_table = "{questis_source_tag}"
        INNER JOIN {i3_db_staging}.mapping_case_items mci_e2
            ON mci_e2.case_item_staging_id = mre.REAL_ENTITY_STAGING_ID
            AND mci_e2.target_type = mre.target_type
            AND mci_e2.source_table = "mapping_real_entities"

        INNER JOIN {i3_db}.entity e1
            ON e1.id = mci_e1.case_item_generated_id
        INNER JOIN {i3_db}.entity e2
            ON e2.id = mci_e2.case_item_generated_id
            
        INNER JOIN {i3_db}.`case` cse
            ON cse.id = mir.CASE_GENERATED_ID
            
        INNER JOIN {raw_questis}.{quetis_table_name} qtbl
            ON CAST(CONV(qtbl.{questis_pk},16,10) AS BIGINT) = mir.QUESTIS_ITEM_2_ID
    """)
    
    return statement_table

