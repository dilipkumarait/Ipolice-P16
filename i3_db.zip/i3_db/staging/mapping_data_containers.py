from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    # TODO: Load json file here to replace hard coded source DB
    raw_questis = conf_variables['raw_questis']
    i3_db_staging = conf_variables['i3_db_staging']
    query = f"""
        SELECT
            CAST(CONV(pvtechkey,16,10) AS BIGINT) AS QUESTIS_ID,
            "PVF" AS SOURCE_TABLE,
            "DATA CONTAINER PV" as TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.pvf 
        JOIN {i3_db_staging}.MAPPING_CASES mc ON CAST(CONV(pvtechkey,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "PVF"
        
        UNION
        
        SELECT
            CAST(CONV(RIRTECHKEY,16,10) AS BIGINT) AS QUESTIS_ID,
            "RIR" AS SOURCE_TABLE,
            "DATA CONTAINER RIR" as TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.rir
        JOIN {i3_db_staging}.MAPPING_CASES mc ON CAST(CONV(RIRTECHKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "RIR"
    """

    mapping_data_containers = sparkSession.sql(query)
    mapping_data_containers = mapping_data_containers.withColumn("DATA_CONTAINER_STAGING_ID", monotonically_increasing_id())

    return mapping_data_containers
