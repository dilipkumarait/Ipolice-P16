from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    # TODO: Load json file here to replace hard coded source DB
    i3_db_staging = conf_variables['i3_db_staging']
    raw_questis = conf_variables['raw_questis']

    query = f"""
        SELECT 
            mce.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID,
            CAST(CONV(gps.GPSNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ID,
            "GPS" AS SOURCE_TABLE,
            "IDENTIFYING NATURAL PERSON ATTRIBUTES" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID as CASE_GENERATED_ID
        FROM {raw_questis}.gps gps
        inner join {i3_db_staging}.mapping_case_entities mce
        on  CAST(CONV(gps.GPSNCDBKEY,16,10) AS BIGINT) = mce.QUESTIS_ID 
        and mce.TARGET_TYPE = "NATURAL PERSON"
        INNER JOIN {i3_db_staging}.MAPPING_CASES mc ON mce.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
union

        SELECT 
            mce.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID,
            CAST(CONV(gps.GPSNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ID,
            "GPS" AS SOURCE_TABLE,
            "NON IDENTIFYING NATURAL PERSON ATTRIBUTES" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID as CASE_GENERATED_ID
        FROM {raw_questis}.gps gps
        inner join {i3_db_staging}.mapping_case_entities mce
        on  CAST(CONV(gps.GPSNCDBKEY,16,10) AS BIGINT) = mce.QUESTIS_ID 
        and mce.TARGET_TYPE = "NATURAL PERSON"
        INNER JOIN {i3_db_staging}.MAPPING_CASES mc ON mce.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"

union

        SELECT 
            mce.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID,
            CAST(CONV(gps.GPSNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ID,
            "GPS" AS SOURCE_TABLE,
            "PERSON ATTRIBUTES" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID as CASE_GENERATED_ID
        FROM {raw_questis}.gps gps
        inner join {i3_db_staging}.mapping_case_entities mce
        on  CAST(CONV(gps.GPSNCDBKEY,16,10) AS BIGINT) = mce.QUESTIS_ID 
        and mce.TARGET_TYPE = "NATURAL PERSON"
        INNER JOIN {i3_db_staging}.MAPPING_CASES mc ON mce.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
union 

        SELECT 
            mce.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID,
            CAST(CONV(gvw.GVWNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ID,
            "GVW" AS SOURCE_TABLE,
            "OBJECT ATTRIBUTES" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID as CASE_GENERATED_ID
        FROM {raw_questis}.gvw gvw
        inner join {i3_db_staging}.mapping_case_entities mce
        on  CAST(CONV(gvw.GVWNCDBKEY,16,10) AS BIGINT) = mce.QUESTIS_ID 
        and mce.TARGET_TYPE in ("DRUG", "FIREARM")
        INNER JOIN {i3_db_staging}.MAPPING_CASES mc ON mce.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
union 

        SELECT 
            mce.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID,
            CAST(CONV(gvm.GVMNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ID,
            "GVM" AS SOURCE_TABLE,
            "OBJECT ATTRIBUTES" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID as CASE_GENERATED_ID
        FROM {raw_questis}.gvm gvm
        inner join {i3_db_staging}.mapping_case_entities mce
        on  CAST(CONV(gvm.GVMNCDBKEY,16,10) AS BIGINT) = mce.QUESTIS_ID 
        and mce.TARGET_TYPE ="VEHICLE"
        INNER JOIN {i3_db_staging}.MAPPING_CASES mc ON mce.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"


"""
    mapping_attributes = sparkSession.sql(query)
    mapping_attributes = mapping_attributes.withColumn("ATTRIBUTE_STAGING_ID", monotonically_increasing_id())

    return mapping_attributes