from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    # TODO: Load json file here to replace hard coded source DB
    raw_questis = conf_variables['raw_questis']
    i3_db_staging = conf_variables['i3_db_staging']

    query = f"""
    SELECT DISTINCT
        CAST(CONV(ep1.EP1ONDNCDBKEY,16,10) AS BIGINT) AS AD1ONDNCDBKEY,
        mpa.AD1ADDNCDBKEY AS AD1ADDNCDBKEY,
        CAST(CONV(ep1.EP1GPSNCDBKEY,16,10) AS BIGINT) AS AD1GPSNCDBKEY
    FROM {raw_questis}.mtp mtp
    JOIN {i3_db_staging}.mapping_person_addresses mpa 
        ON mtp.MTPCOUNTRY = mpa.COUNTRY 
        AND mtp.MTPMUNICIPALITY = mpa.MUNICIPALITY
        AND mtp.MTPSTREET = mpa.STREET
        AND mtp.MTPSTREETASTEXT = mpa.STREET_AS_TEXT
        AND mtp.MTPHOUSENR = mpa.HOUSE_NR
        AND mtp.MTPBOXNR = mpa.BOX_NR
    JOIN {raw_questis}.ep1 ep1 ON ep1.EP1GPSNCDBKEY = mtp.MTPGPSNCDBKEY
    """

    return sparkSession.sql(query)
