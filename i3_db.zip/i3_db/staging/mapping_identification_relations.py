from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    # TODO: Load json file here to replace hard coded source DB
    i3_db_staging = conf_variables['i3_db_staging']
    raw_questis = conf_variables['raw_questis']
    

    query = f"""
        SELECT 
            CAST(CONV(ef1.EF1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_1_ID,
            CAST(CONV(ef1.EF1FEINCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_2_ID,
            "EF1" AS SOURCE_TABLE,
            "IDENTIFIED OFFENCE" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.ef1 ef1
        JOIN {i3_db_staging}.mapping_cases mc ON CAST(CONV(ef1.EF1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"

        UNION

        SELECT 
            CAST(CONV(ep1.EP1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_1_ID,
            CAST(CONV(ep1.EP1GPSNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_2_ID,
            "EP1" AS SOURCE_TABLE,
            "IDENTIFIED NATURAL PERSON" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.ep1 ep1
        JOIN {i3_db_staging}.mapping_cases mc ON CAST(CONV(ep1.EP1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"

        UNION

        SELECT 
            CAST(CONV(eo1.EO1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_1_ID,
            CAST(CONV(eo1.EO1ORGNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_2_ID,
            "EO1" AS SOURCE_TABLE,
            "IDENTIFIED MORAL PERSON" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.eo1 eo1
        JOIN {i3_db_staging}.mapping_cases mc ON CAST(CONV(eo1.EO1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        WHERE EXISTS(SELECT orgmp.ORGNCDBKEY FROM {raw_questis}.org orgmp where orgmp.ORGNCDBKEY = eo1.EO1ORGNCDBKEY AND CAST(orgmp.orgbeschtype AS INT) = 1)

        UNION

        SELECT 
            CAST(CONV(eo1.EO1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_1_ID,
            CAST(CONV(eo1.EO1ORGNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_2_ID,
            "EO1" AS SOURCE_TABLE,
            "IDENTIFIED GROUPING" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.eo1 eo1
        JOIN {i3_db_staging}.mapping_cases mc ON CAST(CONV(eo1.EO1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        WHERE EXISTS(SELECT orgg.ORGNCDBKEY FROM {raw_questis}.org orgg where orgg.ORGNCDBKEY = eo1.EO1ORGNCDBKEY AND CAST(orgg.orgbeschtype AS INT) = 2)

        UNION

        SELECT 
            CAST(CONV(em1.EM1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_1_ID,
            CAST(CONV(em1.EM1GVMNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_2_ID,
            "EM1" AS SOURCE_TABLE,
            "IDENTIFIED VEHICLE" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.em1 em1
        JOIN {i3_db_staging}.mapping_cases mc ON CAST(CONV(em1.EM1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"

        UNION

        SELECT 
            CAST(CONV(em11.EM1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_1_ID,
            CAST(CONV(em11.EM1GVMNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_2_ID,
            "EM1" AS SOURCE_TABLE,
            "IDENTIFIED LICENSE PLATE" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.em1 em11
        JOIN {i3_db_staging}.mapping_cases mc ON CAST(CONV(em11.EM1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"

        UNION

        SELECT 
            CAST(CONV(ew1.EW1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_1_ID,
            CAST(CONV(ew1.EW1GVWNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_2_ID,
            "EW1" AS SOURCE_TABLE,
            "IDENTIFIED FIREARM" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.ew1 ew1
        JOIN {i3_db_staging}.mapping_cases mc ON CAST(CONV(ew1.EW1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        WHERE EXISTS(SELECT gvwf.GVWNCDBKEY FROM {raw_questis}.gvw gvwf WHERE ew1.EW1GVWNCDBKEY = gvwf.GVWNCDBKEY AND CAST(gvwf.GVWCAT AS INT) IN (80, 96))

        UNION

        SELECT 
            CAST(CONV(ew1.EW1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_1_ID,
            CAST(CONV(ew1.EW1GVWNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_2_ID,
            "EW1" AS SOURCE_TABLE,
            "IDENTIFIED DRUG" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.ew1 ew1
        JOIN {i3_db_staging}.mapping_cases mc ON CAST(CONV(ew1.EW1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        WHERE EXISTS(SELECT gvwd.GVWNCDBKEY FROM {raw_questis}.gvw gvwd WHERE ew1.EW1GVWNCDBKEY = gvwd.GVWNCDBKEY AND CAST(gvwd.GVWCAT AS INT) = 18)

        UNION

        SELECT 
            CAST(CONV(en1.EN1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_1_ID,
            CAST(CONV(en1.EN1NUMNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_2_ID,
            "EN1" AS SOURCE_TABLE,
            "IDENTIFIED PHONE NUMBER" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.en1 en1
        JOIN {i3_db_staging}.mapping_cases mc ON CAST(CONV(en1.EN1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        WHERE EXISTS(SELECT numpn.NUMNCDBKEY FROM {raw_questis}.num numpn WHERE en1.EN1NUMNCDBKEY = numpn.NUMNCDBKEY AND CAST(numpn.NUMCLASSE AS INT) IN (1, 2, 17, 18))

        UNION

        SELECT 
            CAST(CONV(en1.EN1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_1_ID,
            CAST(CONV(en1.EN1NUMNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_2_ID,
            "EN1" AS SOURCE_TABLE,
            "IDENTIFIED EMAIL ADDRESS" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.en1 en1
        JOIN {i3_db_staging}.mapping_cases mc ON CAST(CONV(en1.EN1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        WHERE EXISTS(SELECT numea.NUMNCDBKEY FROM {raw_questis}.num numea WHERE en1.EN1NUMNCDBKEY = numea.NUMNCDBKEY AND CAST(numea.NUMCLASSE AS INT) = 3)

        UNION

        SELECT
            CAST(CONV(el1.EL1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_1_ID,
            CAST(CONV(el1.EL1GPLNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ITEM_2_ID,
            "EL1" AS SOURCE_TABLE,
            "IDENTIFIED LOCATION" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.el1 el1
        JOIN {i3_db_staging}.mapping_cases mc ON CAST(CONV(el1.EL1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"

        UNION
        
        SELECT
            mcpa.AD1ONDNCDBKEY AS QUESTIS_ITEM_1_ID,
            mcpa.AD1ADDNCDBKEY AS QUESTIS_ITEM_2_ID,
            "mapping_case_person_addresses" AS SOURCE_TABLE,
            "IDENTIFIED LOCATION" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.mapping_case_person_addresses mcpa
        JOIN {i3_db_staging}.mapping_cases mc ON mcpa.AD1ONDNCDBKEY = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        
        """

    mapping_case_items = sparkSession.sql(query)
    mapping_case_items = mapping_case_items.withColumn("RELATION_STAGING_ID", monotonically_increasing_id())

    return mapping_case_items