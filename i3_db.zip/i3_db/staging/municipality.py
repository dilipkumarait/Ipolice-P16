from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    # TODO: Load json file here to replace hard coded source DB
    raw_synthetic = conf_variables['raw_synthetic']

    query = f"""
        SELECT DISTINCT CITY AS MUNICIPALITY FROM {raw_synthetic}.location ORDER BY MUNICIPALITY
    """

    mapping_table = sparkSession.sql(query)
    mapping_table = mapping_table.withColumn("ID", monotonically_increasing_id())

    return mapping_table