from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    # TODO: Load json file here to replace hard coded source DB
    raw_synthetic = conf_variables['raw_synthetic']

    query = f"""
        SELECT DISTINCT STREET 
        FROM {raw_synthetic}.location 
        WHERE STREET is not NULL OR STREET <> ""
        ORDER BY STREET 
    """

    street_table = sparkSession.sql(query)
    street_table = street_table.withColumn("ID", monotonically_increasing_id())

    return street_table