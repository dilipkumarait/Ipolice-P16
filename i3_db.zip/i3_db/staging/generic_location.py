from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    # TODO: Load json file here to replace hard coded source DB
    raw_synthetic = conf_variables['raw_synthetic']
    i3_db_staging = conf_variables['i3_db_staging']

    query = f"""
        SELECT 
            gln.ID AS NAME_ID,
            s.ID AS STREET_ID,
            l.HOUSE_NUMBER AS HOUSE_NUMBER,
            l.BOX AS HOUSE_BOX,
            pc.ID AS POSTAL_CODE_ID,            
            m.ID AS MUNICIPALITY_ID,
            p.ID AS PROVINCE_ID,
            CAST(l.LATITUDE AS FLOAT) AS LATITUDE,
            CAST(l.LONGITUDE AS FLOAT) AS LONGITUDE
        FROM {raw_synthetic}.location l
        INNER JOIN {i3_db_staging}.generic_location_name gln ON l.NAME = gln.NAME
        INNER JOIN {i3_db_staging}.street s ON l.STREET = s.STREET
        INNER JOIN {i3_db_staging}.municipality m ON l.CITY = m.MUNICIPALITY
        INNER JOIN {i3_db_staging}.postal_code pc ON l.`POSTAL_CODE` = pc.POSTAL_CODE
        INNER JOIN {i3_db_staging}.province p ON l.PROVINCE = p.PROVINCE
    """

    mapping_table = sparkSession.sql(query)
    mapping_table = mapping_table.withColumn("ID", monotonically_increasing_id())

    return mapping_table