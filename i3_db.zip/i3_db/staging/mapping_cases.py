from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    # TODO: Load json file here to replace hard coded source DB
    raw_questis = conf_variables['raw_questis']

    query = f"""
        SELECT 
            DISTINCT(CAST(CONV(ondncdbkey,16,10) AS BIGINT)) AS QUESTIS_ID,
            "OND" AS SOURCE_TABLE
        FROM {raw_questis}.ond
        UNION
        SELECT
            DISTINCT(CAST(CONV(pvtechkey,16,10) AS BIGINT)) AS QUESTIS_ID,
            "PVF" AS SOURCE_TABLE
        FROM {raw_questis}.pvf
        UNION
        SELECT 
            DISTINCT(CAST(CONV(rirtechkey,16,10) AS BIGINT)) AS QUESTIS_ID,
            "RIR" AS SOURCE_TABLE
        FROM {raw_questis}.rir
    """

    mapping_cases = sparkSession.sql(query)
    mapping_cases = mapping_cases.withColumn("CASE_GENERATED_ID", monotonically_increasing_id())

    return mapping_cases