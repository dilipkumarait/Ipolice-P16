from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    # TODO: Load json file here to replace hard coded source DB
    i3_db_staging = conf_variables['i3_db_staging']
    raw_questis = conf_variables['raw_questis']

    query = f"""
    SELECT
        CAST(CONV(feincdbkey,16,10) AS BIGINT) AS QUESTIS_ID,
        "FEI" AS SOURCE_TABLE,
        "OFFENCE" AS TARGET_TYPE,
        cast('-1' as BIGINT) AS CASE_GENERATED_ID
    FROM {raw_questis}.fei
    
    UNION
    
    SELECT
        CAST(CONV(gpsncdbkey,16,10) AS BIGINT) AS QUESTIS_ID,
        "GPS" AS SOURCE_TABLE,
        "NATURAL PERSON" AS TARGET_TYPE,
        cast('-1' as BIGINT) AS CASE_GENERATED_ID
    FROM {raw_questis}.gps
    
    UNION
    
    SELECT
        CAST(CONV(orgncdbkey,16,10) AS BIGINT) AS QUESTIS_ID,
        "ORG" AS SOURCE_TABLE,
        "MORAL PERSON" AS TARGET_TYPE,
        cast('-1' as BIGINT) AS CASE_GENERATED_ID
    FROM {raw_questis}.org
    WHERE CAST(orgbeschtype AS INT) = 1
    
    UNION
    
    SELECT
        CAST(CONV(orgncdbkey,16,10) AS BIGINT) AS QUESTIS_ID,
        "ORG" AS SOURCE_TABLE,
        "GROUPING" AS TARGET_TYPE,
        cast('-1' as BIGINT) AS CASE_GENERATED_ID
    FROM {raw_questis}.org
    WHERE CAST(orgbeschtype AS INT) = 2
    
    UNION
    
    SELECT
        CAST(CONV(gvmncdbkey,16,10) AS BIGINT) AS QUESTIS_ID,
        "GVM" AS SOURCE_TABLE,
        "VEHICLE" AS TARGET_TYPE,
        cast('-1' as BIGINT) AS CASE_GENERATED_ID
    FROM {raw_questis}.gvm
    
    UNION
    
    SELECT
        CAST(CONV(gvmncdbkey,16,10) AS BIGINT) AS QUESTIS_ID,
        "GVM" AS SOURCE_TABLE,
        "LICENSE PLATE" AS TARGET_TYPE,
        cast('-1' as BIGINT) AS CASE_GENERATED_ID
    FROM {raw_questis}.gvm
    
    UNION
    
    SELECT
        CAST(CONV(gvwncdbkey,16,10) AS BIGINT) AS QUESTIS_ID,
        "GVW" AS SOURCE_TABLE,
        "FIREARM" AS TARGET_TYPE,
        cast('-1' as BIGINT) AS CASE_GENERATED_ID
    FROM {raw_questis}.gvw
    WHERE CAST(GVWCAT AS INT) IN (80, 96)
    
    UNION
    
    SELECT
        CAST(CONV(gvwncdbkey,16,10) AS BIGINT) AS QUESTIS_ID,
        "GVW" AS SOURCE_TABLE,
        "DRUG" AS TARGET_TYPE,
        cast('-1' as BIGINT) AS CASE_GENERATED_ID
    FROM {raw_questis}.gvw
    WHERE CAST(GVWCAT AS INT) = 18
    
    UNION
    
    SELECT
        CAST(CONV(numncdbkey,16,10) AS BIGINT) AS QUESTIS_ID,
        "NUM" AS SOURCE_TABLE,
        "PHONE NUMBER" AS TARGET_TYPE,
        cast('-1' as BIGINT) AS CASE_GENERATED_ID
    FROM {raw_questis}.num
    WHERE CAST(NUMCLASSE AS INT) IN (1, 2, 17, 18)
    
    UNION
    
    SELECT
        CAST(CONV(numncdbkey,16,10) AS BIGINT) AS QUESTIS_ID,
        "NUM" AS SOURCE_TABLE,
        "EMAIL ADDRESS" AS TARGET_TYPE,
        cast('-1' as BIGINT) AS CASE_GENERATED_ID
    FROM {raw_questis}.num
    WHERE CAST(NUMCLASSE AS INT) = 3
    
    UNION
    
    SELECT
        CAST(CONV(gplncdbkey,16,10) AS BIGINT) AS QUESTIS_ID,
        "GPL" AS SOURCE_TABLE,
        "LOCATION" AS TARGET_TYPE,
        cast('-1' as BIGINT) AS CASE_GENERATED_ID
    FROM {raw_questis}.gpl
    
    UNION
    
    SELECT
        AD1ADDNCDBKEY AS QUESTIS_ID,
        "mapping_person_addresses" AS SOURCE_TABLE,
        "LOCATION" AS TARGET_TYPE,
        cast('-1' as BIGINT) AS CASE_GENERATED_ID
    FROM {i3_db_staging}.mapping_person_addresses
      """

    mapping_real_entities = sparkSession.sql(query)
    mapping_real_entities = mapping_real_entities.withColumn("REAL_ENTITY_STAGING_ID", monotonically_increasing_id())

    return mapping_real_entities
