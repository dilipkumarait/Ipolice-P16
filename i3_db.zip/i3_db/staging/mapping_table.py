from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    # TODO: Load json file here to replace hard coded source DB
    raw_questis = conf_variables['raw_questis']

    query = f"""
        select 
            cast(conv(EP1ONDNCDBKEY,16,10) as bigint) as ONDKEY,
            cast(conv(EP1GPSNCDBKEY,16,10) as bigint) as EPK,
            "EP1" as source_table
        from {raw_questis}.ep1
        UNION
        select 
            cast(conv(EF1ONDNCDBKEY,16,10) as bigint) as ONDKEY,
            cast(conv(EF1FEINCDBKEY,16,10) as bigint) as EPK,
            "EF1" as source_table
        from {raw_questis}.ef1
        UNION
        select 
            cast(conv(EO1ONDNCDBKEY,16,10) as bigint) as ONDKEY,
            cast(conv(EO1ORGNCDBKEY,16,10) as bigint) as EPK,
            "EO1" as source_table
        from {raw_questis}.eo1
        UNION
        select 
            cast(conv(EM1ONDNCDBKEY,16,10) as bigint) as ONDKEY,
            cast(conv(EM1GVMNCDBKEY,16,10) as bigint) as EPK,
            "EM1" as source_table
        from {raw_questis}.em1
        UNION
        select 
            cast(conv(EM1ONDNCDBKEY,16,10) as bigint) as ONDKEY,
            cast(conv(EM1GVMNCDBKEY,16,10) as bigint) as EPK,
            "PTL1" as source_table
        from {raw_questis}.em1
        UNION
        select
            cast(conv(EW1ONDNCDBKEY,16,10) as bigint) as ONDKEY,
            cast(conv(EW1GVWNCDBKEY,16,10) as bigint) as EPK,
            "EW1" as source_table
        from {raw_questis}.ew1
        UNION
        select 
            cast(conv(EN1ONDNCDBKEY,16,10) as bigint) as ONDKEY,
            cast(conv(EN1NUMNCDBKEY,16,10) as bigint) as EPK,
            "EN1" as source_table
        from {raw_questis}.en1
        UNION
        select
            cast(conv(EL1ONDNCDBKEY,16,10) as bigint) as ONDKEY,
            cast(conv(EL1GPLNCDBKEY,16,10) as bigint) as EPK,
            "EL1" as source_table
        from {raw_questis}.el1
        UNION
        select 
            cast(conv(RF1FEINCDBKEY,16,10) as bigint) as ONDKEY,
            cast(conv(RF1RIRTECHKEY,16,10) as bigint) as EPK,
            "RF1" as source_table
        from {raw_questis}.rf1
        UNION
        select
            cast(conv(PF1FEINCDBKEY,16,10) as bigint) as ONDKEY,
            cast(conv(PF1PVTECHKEY,16,10) as bigint) as EPK,
            "PF1" as source_table
        from {raw_questis}.pf1
    """

    mapping_table = sparkSession.sql(query)
    mapping_table = mapping_table.withColumn("id", monotonically_increasing_id())

    return mapping_table