from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    # TODO: Load json file here to replace hard coded source DB
    i3_db_staging = conf_variables['i3_db_staging']
    raw_questis = conf_variables['raw_questis']

    query = f"""
        SELECT 
            CAST(CONV(EP1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_CASE_ID,
            CAST(CONV(EP1GPSNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ID,
            "EP1" AS SOURCE_TABLE,
            "NATURAL PERSON" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.ep1
        JOIN {i3_db_staging}.MAPPING_CASES mc 
            ON CAST(CONV(EP1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID 
            AND mc.SOURCE_TABLE = "OND"
        
        UNION
        
        SELECT 
            CAST(CONV(EF1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_CASE_ID,
            CAST(CONV(EF1FEINCDBKEY,16,10) AS BIGINT) AS QUESTIS_ID,
            "EF1" AS SOURCE_TABLE,
            "OFFENCE" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.ef1
        JOIN {i3_db_staging}.MAPPING_CASES mc ON CAST(CONV(EF1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        
        UNION
        
        SELECT 
            CAST(CONV(eo1mp.EO1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_CASE_ID,
            CAST(CONV(eo1mp.EO1ORGNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ID,
            "EO1" AS SOURCE_TABLE,
            "MORAL PERSON" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.eo1 eo1mp
        JOIN {i3_db_staging}.MAPPING_CASES mc ON CAST(CONV(eo1mp.EO1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        WHERE EXISTS(SELECT orgmp.ORGNCDBKEY FROM {raw_questis}.org orgmp WHERE orgmp.ORGNCDBKEY = eo1mp.EO1ORGNCDBKEY AND CAST(orgmp.orgbeschtype AS INT) = 1)
        
        UNION
        
        SELECT 
            CAST(CONV(eo1g.EO1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_CASE_ID,
            CAST(CONV(eo1g.EO1ORGNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ID,
            "EO1" AS SOURCE_TABLE,
            "GROUPING" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.eo1 eo1g
        JOIN {i3_db_staging}.MAPPING_CASES mc ON CAST(CONV(eo1g.EO1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        WHERE EXISTS(SELECT orgg.ORGNCDBKEY FROM {raw_questis}.org orgg WHERE orgg.ORGNCDBKEY = eo1g.EO1ORGNCDBKEY AND CAST(orgg.orgbeschtype AS INT) = 2)
        
        UNION
        
        SELECT 
            CAST(CONV(EM1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_CASE_ID,
            CAST(CONV(EM1GVMNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ID,
            "EM1" AS SOURCE_TABLE,
            "VEHICLE" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.em1
        JOIN {i3_db_staging}.MAPPING_CASES mc ON CAST(CONV(EM1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        
        UNION
        
        SELECT 
            CAST(CONV(EM1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_CASE_ID,
            CAST(CONV(EM1GVMNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ID,
            "EM1" AS SOURCE_TABLE,
            "LICENSE PLATE" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.em1
        JOIN {i3_db_staging}.MAPPING_CASES mc ON CAST(CONV(EM1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        
        UNION
        
        SELECT
            CAST(CONV(ew1f.EW1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_CASE_ID,
            CAST(CONV(ew1f.EW1GVWNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ID,
            "EW1" AS SOURCE_TABLE,
            "FIREARM" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.ew1 ew1f
        JOIN {i3_db_staging}.MAPPING_CASES mc ON CAST(CONV(ew1f.EW1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        WHERE EXISTS(SELECT gvwf.GVWNCDBKEY FROM {raw_questis}.gvw gvwf WHERE ew1f.EW1GVWNCDBKEY = gvwf.GVWNCDBKEY AND CAST(gvwf.GVWCAT AS INT) IN (80, 96))
        
        UNION
        
        SELECT
            CAST(CONV(ew1d.EW1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_CASE_ID,
            CAST(CONV(ew1d.EW1GVWNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ID,
            "EW1" AS SOURCE_TABLE,
            "DRUG" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.ew1 ew1d
        JOIN {i3_db_staging}.MAPPING_CASES mc ON CAST(CONV(ew1d.EW1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        WHERE EXISTS(SELECT gvwd.GVWNCDBKEY FROM {raw_questis}.gvw gvwd WHERE ew1d.EW1GVWNCDBKEY = gvwd.GVWNCDBKEY AND CAST(gvwd.GVWCAT AS INT) = 18)
        
        UNION
        
        SELECT 
            CAST(CONV(en1pn.EN1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_CASE_ID,
            CAST(CONV(en1pn.EN1NUMNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ID,
            "EN1" AS SOURCE_TABLE,
            "PHONE NUMBER" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.en1 en1pn
        JOIN {i3_db_staging}.MAPPING_CASES mc ON CAST(CONV(en1pn.EN1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        WHERE EXISTS(SELECT numpn.NUMNCDBKEY FROM {raw_questis}.num numpn WHERE en1pn.EN1NUMNCDBKEY = numpn.NUMNCDBKEY AND CAST(numpn.NUMCLASSE AS INT) IN (1, 2, 17, 18))
        
        UNION
        
        SELECT 
            CAST(CONV(en1ea.EN1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_CASE_ID,
            CAST(CONV(en1ea.EN1NUMNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ID,
            "EN1" AS SOURCE_TABLE,
            "EMAIL ADDRESS" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.en1 en1ea
        JOIN {i3_db_staging}.MAPPING_CASES mc ON CAST(CONV(en1ea.EN1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        WHERE EXISTS(SELECT numea.NUMNCDBKEY FROM {raw_questis}.num numea WHERE en1ea.EN1NUMNCDBKEY = numea.NUMNCDBKEY AND CAST(numea.NUMCLASSE AS INT) = 3)
        
        UNION
        
        SELECT
            CAST(CONV(EL1ONDNCDBKEY,16,10) AS BIGINT) AS QUESTIS_CASE_ID,
            CAST(CONV(EL1GPLNCDBKEY,16,10) AS BIGINT) AS QUESTIS_ID,
            "EL1" AS SOURCE_TABLE,
            "LOCATION" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {raw_questis}.el1
        JOIN {i3_db_staging}.MAPPING_CASES mc ON CAST(CONV(EL1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        
        UNION
        
        SELECT
            AD1ONDNCDBKEY AS QUESTIS_CASE_ID,
            AD1ADDNCDBKEY AS QUESTIS_ID,
            "mapping_case_person_addresses" AS SOURCE_TABLE,
            "LOCATION" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.mapping_case_person_addresses
        JOIN {i3_db_staging}.MAPPING_CASES mc ON CAST(CONV(AD1ONDNCDBKEY,16,10) AS BIGINT) = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
    """

    mapping_case_entities = sparkSession.sql(query)
    mapping_case_entities = mapping_case_entities.withColumn("CASE_ENTITY_STAGING_ID", monotonically_increasing_id())

    return mapping_case_entities