from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    # TODO: Load json file here to replace hard coded source DB
    raw_questis = conf_variables['raw_questis']

    query = f"""
    SELECT DISTINCT
        MTPCOUNTRY AS COUNTRY,
        MTPMUNICIPALITY AS MUNICIPALITY,
        MTPSTREET AS STREET,
        MTPSTREETASTEXT AS STREET_AS_TEXT,
        MTPHOUSENR AS HOUSE_NR,
        MTPBOXNR AS BOX_NR
    FROM {raw_questis}.mtp
    """

    mapping_person_addresses = sparkSession.sql(query)
    mapping_person_addresses = mapping_person_addresses.withColumn("AD1ADDNCDBKEY", monotonically_increasing_id())

    return mapping_person_addresses