from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    # TODO: Load json file here to replace hard coded source DB
    i3_db_staging = conf_variables['i3_db_staging']
    raw_questis = conf_variables['raw_questis']
    data_source = conf_variables['data_source']
    
    if data_source == "pamela":
        bzk_tab = sparkSession.sql(f"""
        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "BZK" AS SOURCE_TABLE,
            CASE
                WHEN CAST(bzk.REBMOTIF_001 AS INT) = 2 THEN "NATURAL PERSON HAS LEGAL ADDRESS AT PLACE"
                WHEN CAST(bzk.REBMOTIF_001 AS INT) IN (1, 3, 4) THEN "NATURAL PERSON IS LOCATED IN PLACE"
                ELSE "PERSON TO PLACE"
            END AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.bzk bzk ON mce1.QUESTIS_ID = CAST(CONV(bzk.BZKGPSNCDBKEY,16,10) AS BIGINT) AND mce1.SOURCE_TABLE = "EP1"
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
            ON mce2.QUESTIS_ID = CAST(CONV(bzk.BZKGPLNCDBKEY,16,10) AS BIGINT) AND mce2.SOURCE_TABLE = "EL1" AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        
        UNION
        
        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "BZK" AS SOURCE_TABLE,
            CASE
                WHEN CAST(bzk.REBMOTIF_002 AS INT) = 2 THEN "NATURAL PERSON HAS LEGAL ADDRESS AT PLACE"
                WHEN CAST(bzk.REBMOTIF_002 AS INT) IN (1, 3, 4) THEN "NATURAL PERSON IS LOCATED IN PLACE"
                ELSE "NATURAL PERSON TO PLACE"
            END AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.bzk bzk ON mce1.QUESTIS_ID = CAST(CONV(bzk.BZKGPSNCDBKEY,16,10) AS BIGINT) AND mce1.SOURCE_TABLE = "EP1"
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
            ON mce2.QUESTIS_ID = CAST(CONV(bzk.BZKGPLNCDBKEY,16,10) AS BIGINT) AND mce2.SOURCE_TABLE = "EL1" AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"

        """)
        bzk_tab = bzk_tab.dropDuplicates()
    else:
        bzk_tab = sparkSession.sql(f"""
        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "BZK" AS SOURCE_TABLE,
            CASE
                WHEN CAST(bzk_reb.REBMOTIF AS INT) = 2 THEN "NATURAL PERSON HAS LEGAL ADDRESS AT PLACE"
                WHEN CAST(bzk_reb.REBMOTIF AS INT) IN (1, 3, 4) THEN "NATURAL PERSON IS LOCATED IN PLACE"
                ELSE "NATURAL PERSON TO PLACE" 
            END AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.bzk bzk ON mce1.QUESTIS_ID = CAST(CONV(bzk.BZKGPSNCDBKEY,16,10) AS BIGINT) AND mce1.SOURCE_TABLE = "EP1"
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
            ON mce2.QUESTIS_ID = CAST(CONV(bzk.BZKGPLNCDBKEY,16,10) AS BIGINT) AND mce2.SOURCE_TABLE = "EL1" AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        JOIN {raw_questis}.bzk_reb bzk_reb ON bzk.BZKGPSNCDBKEY = bzk_reb.BZKGPSNCDBKEY
        """)

    query = f"""
        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "GL2" AS SOURCE_TABLE,
            "OFFENCE TO OFFENCE" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.gl2 gl2    
          ON mce1.QUESTIS_ID = CAST(CONV(gl2.GL2FEINCDBKEY,16,10) AS BIGINT) AND mce1.SOURCE_TABLE = "EF1"
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
          ON mce2.QUESTIS_ID = CAST(CONV(gl2.GL2FEINCDBKEYLINK,16,10) AS BIGINT) AND mce2.SOURCE_TABLE = "EF1" AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc 
            ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND" 
        
        UNION  

        SELECT
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1, -- Person
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2, -- Offence
            "PL2" AS SOURCE_TABLE,
            CASE 
                WHEN CAST(pl2.PL2RECBASIS AS INT) in (1,2,3,4,8,9) then "SUSPECT NATURAL PERSON IN OFFENCE"
                ELSE "NATURAL PERSON TO OFFENCE"
            END AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.pl2 pl2  
            ON mce1.QUESTIS_ID = CAST(CONV(pl2.PL2FEINCDBKEY,16,10) AS BIGINT) 
            AND mce1.SOURCE_TABLE = "EF1"
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
            ON mce2.QUESTIS_ID = CAST(CONV(pl2.PL2GPSNCDBKEY,16,10) AS BIGINT) 
            AND mce2.SOURCE_TABLE = "EP1" 
            AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc 
            ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID 
            AND mc.SOURCE_TABLE = "OND"
        WHERE CAST(pl2.PL2KONTEKST AS INT) IN (0, 1)

        UNION

        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "FO1" AS SOURCE_TABLE,
            "GROUPING/MORAL PERSON TO OFFENCE" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.fo1 fo1  
            ON mce1.QUESTIS_ID = CAST(CONV(fo1.FO1FEINCDBKEY,16,10) AS BIGINT) AND mce1.SOURCE_TABLE = "EF1"
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
            ON mce2.QUESTIS_ID = CAST(CONV(fo1.FO1ORGNCDBKEY,16,10) AS BIGINT) AND mce2.SOURCE_TABLE = "EO1" AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        WHERE CAST(fo1.FO1KONTEKST AS INT) IN (0, 1)  
        
        UNION
        
        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "mapping_case_entities" AS SOURCE_TABLE,
            "VEHICLE IS ASSOCIATED WITH LICENSE PLATE" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
            ON mce1.SOURCE_TABLE = "EM1" 
            AND mce1.QUESTIS_ID = mce2.QUESTIS_ID 
            AND mce1.SOURCE_TABLE = mce2.SOURCE_TABLE 
            AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc 
            ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID 
            AND mc.SOURCE_TABLE = "OND"
        
        UNION
        
        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "VB4" AS SOURCE_TABLE,
            CASE
                WHEN CAST(vb4.VB4BETROKKENHEID AS INT) IN (2, 3, 4, 5)
                    THEN "VEHICLE IS OBJECT OF OFFENCE"
                WHEN CAST(vb4.VB4BETROKKENHEID AS INT) IN (1, 12, 13, 14, 15)
                    THEN "VEHICLE IS USED DURING OFFENCE"
                ELSE "VEHICLE TO OFFENCE"
            END AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.vb4 vb4
            ON mce1.QUESTIS_ID = CAST(CONV(vb4.VB4FEINCDBKEY,16,10) AS BIGINT)
            AND mce1.SOURCE_TABLE = "EF1"
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2
            ON mce2.QUESTIS_ID = CAST(CONV(vb4.VB4GVMNCDBKEY,16,10) AS BIGINT)
            AND mce2.SOURCE_TABLE = "EM1"
            AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc
            ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID
            AND mc.SOURCE_TABLE = "OND"

        UNION
        
        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "VB4" AS SOURCE_TABLE,
            CASE
                WHEN CAST(vb4.VB4BETROKKENHEID AS INT) IN (2, 3, 4, 5) THEN "LICENSE PLATE IS OBJECT OF OFFENCE"
                WHEN CAST(vb4.VB4BETROKKENHEID AS INT) IN (1, 12, 13, 14, 15) THEN "LICENSE PLATE IS USED DURING OFFENCE"
                ELSE "VEHICLE TO OFFENCE"
            END AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.vb4 vb4  
            ON mce1.QUESTIS_ID = CAST(CONV(vb4.VB4FEINCDBKEY,16,10) AS BIGINT) AND mce1.SOURCE_TABLE = "EF1"
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
        ON mce2.QUESTIS_ID = CAST(CONV(vb4.VB4GVMNCDBKEY,16,10) AS BIGINT) AND mce2.SOURCE_TABLE = "EM1" AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"

        UNION
        
        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "GB3" AS SOURCE_TABLE,
            CASE
                WHEN CAST(gb3.GB3ISBEZITVANGPS AS INT) = 1 THEN "NATURAL PERSON OWNS VEHICLE"
                WHEN CAST(gb3.GB3ISBEZITVANGPS AS INT) = 0 THEN "NATURAL PERSON USES VEHICLE"
            END AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.gb3 gb3 ON mce1.QUESTIS_ID = CAST(CONV(gb3.GB3GPSNCDBKEY,16,10) AS BIGINT) AND mce1.SOURCE_TABLE = "EP1"
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
            ON mce2.QUESTIS_ID = CAST(CONV(gb3.GB3GVMNCDBKEY,16,10) AS BIGINT) AND mce2.TARGET_TYPE = "VEHICLE" AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"

        UNION
        
        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "GB3" AS SOURCE_TABLE,
            CASE
                WHEN CAST(gb3.GB3ISBEZITVANGPS AS INT) = 1 THEN "NATURAL PERSON OWNS LICENSE PLATE"
                WHEN CAST(gb3.GB3ISBEZITVANGPS AS INT) = 0 THEN "NATURAL PERSON USES LICENSE PLATE"
            END AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.gb3 gb3 ON mce1.QUESTIS_ID = CAST(CONV(gb3.GB3GPSNCDBKEY,16,10) AS BIGINT) AND mce1.SOURCE_TABLE = "EP1"
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
            ON mce2.QUESTIS_ID = CAST(CONV(gb3.GB3GVMNCDBKEY,16,10) AS BIGINT) AND mce2.TARGET_TYPE = "LICENSE PLATE" AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"

        UNION

        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "VB6" AS SOURCE_TABLE,
            CASE
                WHEN CAST(vb6.VB6BETROKKENHEID AS INT) IN (2, 3, 4, 5, 19) THEN "FIREARM IS OBJECT OF OFFENCE"
                WHEN CAST(vb6.VB6BETROKKENHEID AS INT) IN (1, 5, 12, 13, 14, 15) THEN "FIREARM IS USED DURING OFFENCE"
                ELSE "FIREARM TO OFFENCE"
            END AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.vb6 vb6 ON mce1.QUESTIS_ID = CAST(CONV(vb6.VB6FEINCDBKEY,16,10) AS BIGINT) AND mce1.SOURCE_TABLE = "EF1"
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
            ON mce2.QUESTIS_ID = CAST(CONV(vb6.VB6GVWNCDBKEY,16,10) AS BIGINT) AND mce2.SOURCE_TABLE = "EW1" AND MCE1.QUESTIS_CASE_ID = MCE2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        JOIN {raw_questis}.gvw gvw ON mce2.QUESTIS_ID = CAST(CONV(gvw.GVWNCDBKEY,16,10) AS BIGINT)
        WHERE CAST(gvw.gvwcat AS INT) IN (80, 96)

        UNION 

        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "VB6" AS SOURCE_TABLE,
            CASE
                WHEN CAST(vb6.VB6BETROKKENHEID AS INT) IN (2, 3, 4, 5, 19) THEN "DRUG IS OBJECT OF OFFENCE"
                WHEN CAST(vb6.VB6BETROKKENHEID AS INT) IN (1, 5, 12, 13, 14, 15) THEN "DRUG IS USED DURING OFFENCE"
                ELSE "DRUG TO OFFENCE"
            END AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.vb6 vb6 ON mce1.QUESTIS_ID = CAST(CONV(vb6.VB6FEINCDBKEY,16,10) AS BIGINT) AND mce1.SOURCE_TABLE = "EF1"
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
            ON mce2.QUESTIS_ID = CAST(CONV(vb6.VB6GVWNCDBKEY,16,10) AS BIGINT) AND mce2.SOURCE_TABLE = "EW1" AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        JOIN {raw_questis}.gvw gvw ON MCE2.QUESTIS_ID = CAST(CONV(gvw.GVWNCDBKEY,16,10) AS BIGINT)
        WHERE CAST(gvw.gvwcat AS INT) = 18 
       
        UNION

        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "PW1" AS SOURCE_TABLE,
            CASE
                WHEN CAST(pw1.PW1REASON AS INT) IN (1, 4) THEN "NATURAL PERSON OWNS FIREARM"
                WHEN CAST(pw1.PW1REASON AS INT) IN (2, 3) THEN "NATURAL PERSON USES FIREARM"
                ELSE "NATURAL PERSON TO FIREARM"
            END AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.pw1 pw1 ON mce1.QUESTIS_ID = CAST(CONV(pw1.PW1GPSNCDBKEY,16,10) AS BIGINT) AND mce1.SOURCE_TABLE = "EP1"
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
            ON mce2.QUESTIS_ID = CAST(CONV(pw1.PW1GVWNCDBKEY,16,10) AS BIGINT) AND mce2.SOURCE_TABLE = "EW1" AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        JOIN {raw_questis}.gvw gvw ON mce2.QUESTIS_ID = CAST(CONV(gvw.GVWNCDBKEY,16,10) AS BIGINT)
        WHERE CAST(gvw.gvwcat AS INT) IN (80, 96)

        UNION
        
        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "PW1" AS SOURCE_TABLE,
            CASE
                WHEN CAST(pw1.PW1REASON AS INT) IN (1, 4) THEN "NATURAL PERSON OWNS DRUG"
                WHEN CAST(pw1.PW1REASON AS INT) IN (2, 3) THEN "NATURAL PERSON USES DRUG"
                ELSE "NATURAL PERSON TO DRUG"
            END AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.pw1 pw1 ON mce1.QUESTIS_ID = CAST(CONV(pw1.PW1GPSNCDBKEY,16,10) AS BIGINT) AND mce1.SOURCE_TABLE = "EP1"
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
            ON mce2.QUESTIS_ID = CAST(CONV(pw1.PW1GVWNCDBKEY,16,10) AS BIGINT) AND mce2.SOURCE_TABLE = "EW1" AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        JOIN {raw_questis}.gvw gvw ON mce2.QUESTIS_ID = CAST(CONV(gvw.GVWNCDBKEY,16,10) AS BIGINT)
        WHERE CAST(gvw.gvwcat AS INT) = 18 

        UNION

        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "FN1" AS SOURCE_TABLE,
            CASE
                WHEN CAST(fn1.FN1REASON AS INT) = 1 THEN "EMAIL ADDRESS IS USED DURING OFFENCE"
                ELSE "EMAIL ADDRESS TO OFFENCE"
            END AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.fn1 fn1 ON mce1.QUESTIS_ID = CAST(CONV(fn1.FN1FEINCDBKEY,16,10) AS BIGINT) AND mce1.SOURCE_TABLE = "EF1"
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
            ON mce2.QUESTIS_ID = CAST(CONV(fn1.FN1NUMNCDBKEY,16,10) AS BIGINT) AND mce2.SOURCE_TABLE = "EN1" AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        JOIN {raw_questis}.num num ON mce2.QUESTIS_ID = CAST(CONV(num.NUMNCDBKEY,16,10) AS BIGINT)
        WHERE CAST(num.NUMCLASSE AS INT) = 3

        UNION 

        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "FN1" AS SOURCE_TABLE,
            CASE
                WHEN CAST(fn1.FN1REASON AS INT) = 1 THEN "PHONE NUMBER IS USED DURING OFFENCE"
                ELSE "PHONE NUMBER TO OFFENCE"
            END AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.fn1 fn1 ON mce1.QUESTIS_ID = CAST(CONV(fn1.FN1FEINCDBKEY,16,10) AS BIGINT) AND mce1.SOURCE_TABLE = "EF1"
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
            ON mce2.QUESTIS_ID = CAST(CONV(fn1.FN1NUMNCDBKEY,16,10) AS BIGINT) AND mce2.SOURCE_TABLE = "EN1" AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        JOIN {raw_questis}.num num ON mce2.QUESTIS_ID = CAST(CONV(num.NUMNCDBKEY,16,10) AS BIGINT)
        WHERE CAST(num.NUMCLASSE AS INT) IN (1,2,17,18)

        UNION

        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "PN1" AS SOURCE_TABLE,
            CASE
                WHEN CAST(pn1.PN1REASON AS INT) = 1 THEN "NATURAL PERSON USES EMAIL ADDRESS"
                WHEN CAST(pn1.PN1REASON AS INT) = 2 THEN "NATURAL PERSON OWNS EMAIL ADDRESS"
                ELSE "NATURAL PERSON TO EMAIL ADDRESS"
            END AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.pn1 pn1 ON mce1.QUESTIS_ID = CAST(CONV(pn1.PN1GPSNCDBKEY,16,10) AS BIGINT) AND mce1.SOURCE_TABLE = "EP1"
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
            ON mce2.QUESTIS_ID = CAST(CONV(pn1.PN1NUMNCDBKEY,16,10) AS BIGINT) AND mce2.SOURCE_TABLE = "EN1" AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        JOIN {raw_questis}.num num ON mce2.QUESTIS_ID = CAST(CONV(num.NUMNCDBKEY,16,10) AS BIGINT)
        WHERE CAST(num.NUMCLASSE AS INT) = 3

        UNION

        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "PN1" AS SOURCE_TABLE,
            CASE
                WHEN CAST(pn1.PN1REASON AS INT) = 1 THEN "NATURAL PERSON USES PHONE NUMBER"
                WHEN CAST(pn1.PN1REASON AS INT) = 2 THEN "NATURAL PERSON OWNS PHONE NUMBER"
                ELSE "NATURAL PERSON TO PHONE NUMBER"
            END AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.pn1 pn1 ON mce1.QUESTIS_ID = CAST(CONV(pn1.PN1GPSNCDBKEY,16,10) AS BIGINT) AND mce1.SOURCE_TABLE = "EP1"
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
            ON mce2.QUESTIS_ID = CAST(CONV(pn1.PN1NUMNCDBKEY,16,10) AS BIGINT) AND mce2.SOURCE_TABLE = "EN1" AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"
        JOIN {raw_questis}.num num ON mce2.QUESTIS_ID = CAST(CONV(num.NUMNCDBKEY,16,10) AS BIGINT)
        WHERE CAST(num.NUMCLASSE AS INT) IN (1,2,17,18)

        UNION

        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "PL1" AS SOURCE_TABLE,
            "OFFENCE LOCATED IN PLACE" AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.pl1 pl1 ON mce1.QUESTIS_ID = CAST(CONV(pl1.PL1FEINCDBKEY,16,10) AS BIGINT) AND mce1.SOURCE_TABLE = "EF1"
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
            ON mce2.QUESTIS_ID = CAST(CONV(pl1.PL1GPLNCDBKEY,16,10) AS BIGINT) AND mce2.SOURCE_TABLE = "EL1" AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND" 
        
        UNION 
        
        SELECT
            mce1.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_1,
            mce2.CASE_ENTITY_STAGING_ID AS CASE_ENTITY_STAGING_ID_2,
            "MTP" AS SOURCE_TABLE,
            CASE
                WHEN CAST(mtp.MTPIMPL AS INT) IN (1, 2, 3, 5, 8, 9) THEN "NATURAL PERSON HAS LEGAL ADDRESS AT PLACE"
                WHEN CAST(mtp.MTPIMPL AS INT) = 4 THEN "NATURAL PERSON IS LOCATED IN PLACE"
                ELSE "NATURAL PERSON TO PLACE" 
            END AS TARGET_TYPE,
            mc.CASE_GENERATED_ID AS CASE_GENERATED_ID
        FROM {i3_db_staging}.MAPPING_CASE_ENTITIES mce1
        JOIN {raw_questis}.mtp mtp ON mce1.QUESTIS_ID = CAST(CONV(mtp.MTPGPSNCDBKEY,16,10) AS BIGINT) AND mce1.SOURCE_TABLE = "EP1"
        JOIN {i3_db_staging}.mapping_person_addresses mpa 
            ON mtp.MTPCOUNTRY = mpa.COUNTRY 
            AND mtp.MTPMUNICIPALITY = mpa.MUNICIPALITY
            AND mtp.MTPSTREET = mpa.STREET
            AND mtp.MTPSTREETASTEXT = mpa.STREET_AS_TEXT
            AND mtp.MTPHOUSENR = mpa.HOUSE_NR
            AND mtp.MTPBOXNR = mpa.BOX_NR
        JOIN {i3_db_staging}.MAPPING_CASE_ENTITIES mce2 
            ON mce2.QUESTIS_ID = mpa.AD1ADDNCDBKEY AND mce2.SOURCE_TABLE = "mapping_case_person_addresses" AND mce1.QUESTIS_CASE_ID = mce2.QUESTIS_CASE_ID
        JOIN {i3_db_staging}.MAPPING_CASES mc ON mce1.QUESTIS_CASE_ID = mc.QUESTIS_ID AND mc.SOURCE_TABLE = "OND"

    """

    mapping_deduced_relations = sparkSession.sql(query)
    
    # Add location relations
    mapping_deduced_relations = mapping_deduced_relations.union(bzk_tab)

    # Add unique generated ID
    mapping_deduced_relations = mapping_deduced_relations.withColumn("RELATION_STAGING_ID", monotonically_increasing_id())

    return mapping_deduced_relations