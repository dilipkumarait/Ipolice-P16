from pyspark.sql.functions import monotonically_increasing_id

def load_table(sparkSession, conf_variables):
    # TODO: Load json file here to replace hard coded source DB
    i3_db_staging = conf_variables['i3_db_staging']
    raw_questis = conf_variables['raw_questis']


    query = f"""
        SELECT
            mre.REAL_ENTITY_STAGING_ID AS CASE_ITEM_STAGING_ID,
            "mapping_real_entities" AS SOURCE_TABLE,
            mre.TARGET_TYPE AS TARGET_TYPE,
            mre.CASE_GENERATED_ID as CASE_GENERATED_ID
        FROM {i3_db_staging}.mapping_real_entities mre
        
        UNION
        
        SELECT
            mce.CASE_ENTITY_STAGING_ID AS CASE_ITEM_STAGING_ID,
            "mapping_case_entities" AS SOURCE_TABLE,
            mce.TARGET_TYPE AS TARGET_TYPE,
            mce.CASE_GENERATED_ID as CASE_GENERATED_ID
        FROM {i3_db_staging}.mapping_case_entities mce        
        
        UNION
        
        SELECT
            mir.RELATION_STAGING_ID AS CASE_ITEM_STAGING_ID,
            "mapping_identification_relations" AS SOURCE_TABLE,
            mir.TARGET_TYPE AS TARGET_TYPE,
            mir.CASE_GENERATED_ID as CASE_GENERATED_ID
        FROM {i3_db_staging}.mapping_identification_relations mir
        
        UNION
        
        SELECT
            mdr.RELATION_STAGING_ID AS CASE_ITEM_STAGING_ID,
            "mapping_deduced_relations" AS SOURCE_TABLE,
            mdr.TARGET_TYPE AS TARGET_TYPE,
            mdr.CASE_GENERATED_ID as CASE_GENERATED_ID
        FROM {i3_db_staging}.mapping_deduced_relations mdr
          
        UNION
        
        SELECT 
            mdc.DATA_CONTAINER_STAGING_ID AS CASE_ITEM_STAGING_ID,
            "mapping_data_containers" AS SOURCE_TABLE,
            mdc.TARGET_TYPE AS TARGET_TYPE,
            mdc.CASE_GENERATED_ID as CASE_GENERATED_ID
        FROM {i3_db_staging}.mapping_data_containers mdc

        UNION

        SELECT
            ma.ATTRIBUTE_STAGING_ID AS CASE_ITEM_STAGING_ID,
            "mapping_attributes" AS SOURCE_TABLE,
            ma.TARGET_TYPE AS TARGET_TYPE,
            ma.CASE_GENERATED_ID as CASE_GENERATED_ID
        FROM {i3_db_staging}.mapping_attributes ma
        
    """

    mapping_case_items = sparkSession.sql(query)
    mapping_case_items = mapping_case_items.withColumn("CASE_ITEM_GENERATED_ID", monotonically_increasing_id())

    return mapping_case_items