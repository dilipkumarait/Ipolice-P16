import sys
from TableManager import TableManager

# Get config file path
conf_filename = sys.argv[1] if sys.argv[1] != None else None
if conf_filename is None:
    raise Exception("ERROR: config file is missing")

# Charger les tables
tm = TableManager(conf_filename)
tm.load_tables("staging", write_format="parquet", write_mode="overwrite", debug=False)
tm.load_tables("gold", write_format="parquet", write_mode="overwrite", debug=False)
tm.load_tables("view", write_format="parquet", write_mode="overwrite", debug=False)

print('-- All tables loaded --')
