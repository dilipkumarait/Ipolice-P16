import re
import os
import json
from itertools import chain
from pyspark.conf import SparkConf
from pyspark.sql import SparkSession
from importlib.machinery import SourceFileLoader

class TableManager:
    def __init__(self, conf_filepath):
        # Load json config file
        self.config_file = self.load_conf(conf_filepath)
    
        # Get Spark session
        self.spark_session = self.create_spark_session()

        
    def create_databases(self):
        databases_matrix = [list(self.config_file["variables"][x] for x in self.config_file[x].keys()) 
                                for x in self.config_file.keys() if x != "variables"]
        databases = list(chain.from_iterable(databases_matrix))

        for x in databases:
            self.spark_session.sql(f"CREATE DATABASE IF NOT EXISTS {x}")

    def create_spark_session(self):
        hive_metastore_uri = self.config_file["variables"]["hive_metastore_uri"]
        spark = (
            SparkSession
            .builder
            .appName('questis_table_manager')
            .config("hive.metastore.uris", hive_metastore_uri, conf=SparkConf())
            .enableHiveSupport()
            .getOrCreate()
        )
        spark.sparkContext.setLogLevel('WARN')
        return spark

    def load_conf(self, conf_filename):
        """ Load configuration from i3_config.json file
        """
        with open(conf_filename, 'r') as configuration_filename:
            configuration_content = configuration_filename.read()
            configuration_content = re.sub('///.*', '', configuration_content)
            conf = json.loads(configuration_content)
            self.conf_default_values(conf) # apply default values on missing fields
        return conf


    def conf_default_values(self, conf):
        """ Set default values for the fields not manually filled in by the user
        """
        DEFAULT_CONF = {
            "active:": False,
            "path":"",
            "order":1000000 # if this parameter is not specified, the table is created after all the other
        }
        for zone in conf:
            if zone != "variables":
                for db in conf[zone]:
                    for table in conf[zone][db]:
                        print("table:", table)
                        if "active" not in conf[zone][db][table]:
                            conf[zone][db][table]["active"] = DEFAULT_CONF["active"]
                        if "path" not in conf[zone][db][table]:
                            conf[zone][db][table]["active"] = False
                            conf[zone][db][table]["path"] = DEFAULT_CONF["path"]
                        if "order" not in conf[zone][db][table]:
                            conf[zone][db][table]["order"] = DEFAULT_CONF["order"]
            

    def drop_tables(self, step):
        """ Load the tables in the database specified in the Json, for a specific step
        :step str: either "staging" or "gold"
        """
        conf = self.config_file
        hive_warehouse = conf["variables"]['hive_warehouse']
        # Drop tables from Hive database
        for db in conf[step]:
            for table in conf[step][db]:
                if "drop" not in conf[step][db][table]:
                    conf[step][db][table]["drop"] = True
                if conf[step][db][table]['active'] and conf[step][db][table]['drop'] is True:
                    if conf[step][db][table]['path'].endswith(".py"):
                        table = table if "table_name" not in conf[step][db][table] else conf[step][db][table]["table_name"]
                    try:
                        
                        if db not in conf['variables']:
                            raise Exception(f"ERROR: the database {db} is missing from 'variables' section")
                        db_name = conf['variables'][db]

                        self.spark_session.sql(f"DROP TABLE IF EXISTS {db_name}.{table}")
                        table_path = os.path.join(hive_warehouse, db_name+".db", table)
                        print("Deleting file:", table_path)
                        self.hdfs_delete_path(table_path)
                    except Exception as e:
                        raise Exception('ERROR while dropping table', table, ":\n", e)


    def load_tables(self, step, write_format="parquet", write_mode="overwrite", debug=False):
        """ Load the tables in the database specified in the Json, for a specific step
        :step str: either "staging" or "gold"
        """
        conf = self.config_file
        # Create Databases (if not exists)
        self.create_databases()

        for db in conf[step]:
            for table, tab_attributes in sorted(conf[step][db].items(), key=lambda item:item[1]['order']):
                if tab_attributes['active']:
                        print(f'Loading table: {table}')
                        if tab_attributes['path'].endswith(".sql"):
                            with open(tab_attributes['path'], 'r') as sqlf:
                                sql_content = sqlf.read()
                                for var_value in conf["variables"]:
                                    sql_content = sql_content.replace('${'+str(var_value)+'}', str(conf["variables"][var_value]))
                                queries_list=sql_content.split(';')
                                for query in queries_list:
                                    if query.replace(' ', '').lstrip().rstrip() != "":
                                        try:
                                            self.spark_session.sql(query)
                                        except Exception as e:
                                            raise Exception('ERROR while creating table - '+str(table), "\nQuery:\n", query, "\nError:", e)
                        elif tab_attributes['path'].endswith(".py"):
                            pymodule = SourceFileLoader("modname", tab_attributes['path']).load_module()
                            df = pymodule.load_table(self.spark_session, conf['variables'])
                            # Write table
                            table_name = tab_attributes['table_name'] if 'table_name' in tab_attributes else table
                            write_mode = tab_attributes['mode'] if 'mode' in tab_attributes else write_mode
                            if debug:
                                print('DEBUG#1 - nb_lines_in_table:', df.count())

                            if db not in conf['variables']:
                                raise Exception(f"ERROR: the database {db} is missing from 'variables' section")
                            db_name = conf['variables'][db]

                            df.write.format(write_format).mode(write_mode).saveAsTable(db_name+'.'+table_name)


    def hdfs_delete_path(self, path):
        sc = self.spark_session.sparkContext
        fs = sc._jvm.org.apache.hadoop.fs.FileSystem.get(sc._jsc.hadoopConfiguration())
        try: 
            fs.delete(sc._jvm.org.apache.hadoop.fs.Path(path), True)
        except Exception as e:
            print('Cannot remove file:', path, "\n", e)
            pass
