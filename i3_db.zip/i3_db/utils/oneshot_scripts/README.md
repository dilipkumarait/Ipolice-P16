
This file describe how to used the different scripts in this repository.

1) Extractors
The script files starting with "extract_" are simple python scripts to execute localy after modifying the paths to the data source and the output folder.

Data source = a repository containing one of the datasets downloaded from the "DataExtraction" sharepoint 

command to execute: python3 extract_pamela.py


2) Loaders

The script files starting with "load_raw_" are pyspark scripts that should be executed from a node of the cloudera cluster because they require access to HiveDB to read or create databases or tables.

The first step is to create a distributed folder on HDFS containing Pamela or Questis csv files obtained from the "Extractor" scripts and modify the path to this folder in the loader script.
Then you can modify the target DB by editing the code and execute the script to load the data.

commands to execute : 

 - Generate the list of files use to create the tables: 
 cd ~
 hdfs dfs -ls /Equipes/P16/raw_pamela_2023_06 | grep .csv> available_files.txt

- remove the data from any previous existing db
hdfs dfs -rm -R /warehouse/tablespace/external/hive/raw_pamela_latest.db

- Execute the script to reload the data into the db:
 spark-submit --conf spark.hadoop.dfs.replication=3 --conf "spark.pyspark.python=/usr/bin/python3" load_raw_questis.py