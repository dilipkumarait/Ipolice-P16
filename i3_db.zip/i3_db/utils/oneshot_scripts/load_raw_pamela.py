import re, os
import pandas as pd
from pyspark import SparkConf
from pyspark.conf import SparkConf
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number
from pyspark.sql.functions import concat_ws, collect_list, size, split

spark = (SparkSession
	.builder
	.appName('pamela_load_one_shot')
	.config("hive.metastore.uris", "thrift://ipl1mgt00cldp03.ipolicedev.int:9083", conf=SparkConf())
	.enableHiveSupport()
	.getOrCreate()
)

# Table target
target_db = "raw_pamela_latest"
extension = ".csv"
separator = "\x1f"
source_folder = r"/Equipes/P16/raw_pamela_2023_06"

stat_folder = r"/Equipes/P16/log"
stat_df = pd.DataFrame()

with open('available_files.txt', 'r') as ficin:
    lines = ficin.readlines()

try:
    spark.sql("DROP DATABASE IF EXISTS " + target_db + " CASCADE")
    spark.sql("CREATE DATABASE IF NOT EXISTS " + target_db)

    for line in lines:
        filepath = line.split()[-1]
        filename = filepath.split('/')[-1].replace(extension, '')
        # All the names of the tables start by 3 while in Questis there is no such thing
        tablename = filename.lower()[1::]
        
        print("-- File: %s --"%(filename))
        df = spark.read.option("quote", "\"").option("escape", "\"").csv(filepath, header=True, sep=separator)
        
        col_names = df.columns
        techfield = [x for x in col_names if x.lower().endswith("techts")]
        
        if len(techfield) == 1:
            techfield = techfield[0]
            subset_colnames = [x for x in col_names if x != techfield]
            
            # get table PK
            tab_pk = [x for x in col_names if re.match(f'{tablename}.*ncdbkey', x.lower()) is not None]
            
            stat_tab = df[[tab_pk + [techfield]]].groupBy(tab_pk).agg(concat_ws(";", collect_list(df[techfield].astype(str))).alias("values_techts"))
            stat_tab = stat_tab.withColumn("count",size(split(col("values_techts"),";")))
            stat_tab = stat_tab.filter("count > 1")
            
            count_dupli = stat_tab.count()
            if count_dupli > 0:
                stat_df.loc[tablename, "nb_dupli"] = count_dupli
                stat_tab.coalesce(1).write.csv(os.path.join(stat_folder, f'stats_{tablename}.csv'), sep=";")

            # tab_window = Window.partitionBy(tab_pk + [techfield]).orderBy(col(techfield).desc())
            tab_window = Window.partitionBy(subset_colnames).orderBy(col(techfield).desc())
            df = df.withColumn("technical_rownumber", row_number().over(tab_window)) \
                    .filter(col("technical_rownumber") == 1) \
                    .drop("technical_rownumber")

        elif len(techfield) > 1:
            raise Exception(f'Table {tablename} has more than 1 techfield: {techfield}')

        df.write.format('parquet') \
            .mode("overwrite") \
            .saveAsTable(target_db+'.'+tablename)
    
except Exception as e:
    print('ERROR while loading tables :', e)

stat_df.to_csv("stat_log.csv", sep=";")
print('DONE ! ')