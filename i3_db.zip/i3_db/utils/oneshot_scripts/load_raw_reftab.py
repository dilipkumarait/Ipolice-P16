from pyspark import SparkConf
from pyspark.conf import SparkConf
from pyspark.sql import SparkSession
import os

spark = (SparkSession
	.builder
	.appName('reftab_load_one_shot')
	.config("hive.metastore.uris", "thrift://ipl1mgt00cldp03.ipolicedev.int:9083", conf=SparkConf())
	.enableHiveSupport()
	.getOrCreate()
)

# Table target
target_db = "raw_references_latest"
extension = ".csv"
separator = "\x1f"
source_folder = r"/Equipes/P16/raw_references_2023_05"


sc = spark.sparkContext
hadoop = sc._jvm.org.apache.hadoop

fs = hadoop.fs.FileSystem
conf = hadoop.conf.Configuration() 
path = hadoop.fs.Path(source_folder)

res=[]
for f in fs.get(conf).listStatus(path):
    if f.getPath().getName().endswith('.csv'): 
        res.append(f.getPath().toString())
# list to store files
#res = []
# Iterate directory
#for file in os.listdir(source_folder):
#    # check only text files
#    if file.endswith('.csv'):
#        res.append(file)
#print(res)


try:
    spark.sql("DROP DATABASE IF EXISTS " + target_db + " CASCADE")
    spark.sql("CREATE DATABASE IF NOT EXISTS " + target_db)
    

    for file in res:
        filepath = file.split()[-1]
        filename = filepath.lower().split('/')[-1].replace(extension, '')
        print("-- File: %s --"%(filename))
        
        # Read/Write table
        sdf = spark.read.csv(filepath, header=True, sep=separator)
        

        sdf.write.format('parquet') \
            .mode("overwrite") \
            .saveAsTable(target_db+'.'+filename)
    
except Exception as e:
    print('ERROR while loading tables :', e)

print('DONE ! ')