from pyspark import SparkConf
from pyspark.conf import SparkConf
from pyspark.sql import SparkSession

spark = (SparkSession
	.builder
	.appName('questis_load_one_shot')
	.config("hive.metastore.uris", "thrift://ipl1mgt00cldp03.ipolicedev.int:9083", conf=SparkConf())
	.enableHiveSupport()
	.getOrCreate()
)

# Table target
target_db = "raw_questis_latest"
extension = ".csv"
separator = ";"
source_folder = r"/Equipes/P16/raw_questis_2023_01"

with open('available_files.txt', 'r') as ficin:
    lines = ficin.readlines()

try:
    spark.sql("DROP DATABASE IF EXISTS " + target_db + " CASCADE")
    spark.sql("CREATE DATABASE IF NOT EXISTS " + target_db)
    renaming_counter = 0

    for line in lines:
        filepath = line.split()[-1]
        filename = filepath.lower().split('/')[-1].replace(extension, '')
        tablename = filename.replace("_hashed", "")
        print("-- File: %s --"%(filename))
        
        # Read/Write table
        sdf = spark.read.csv(filepath, header=True, sep=separator)
        new_colnames = {}

        for x in sdf.columns:
            if "hash_" in x.lower():
                new_name = x.lower().replace("hashed_", "").replace("hash_", "")
                print("renaming "+x+ " as "+ new_name+"\n")
                sdf = sdf.withColumnRenamed(x, new_name)
                renaming_counter += 1

        sdf.write.format('parquet') \
            .mode("overwrite") \
            .saveAsTable(target_db+'.'+tablename)
    
except Exception as e:
    print('ERROR while loading tables :', e)

print(str(renaming_counter) + " fields renamed !")
print('DONE ! ')