import pyodbc
import pandas
import os

# Dossier de sortie
output_folder = r"/data/output"

# Connexion à la database access
access_db_path=r"DBQ=/data/raw/20230502_RefTab.accdb;"
driver = "Driver={Microsoft Access Driver (*.mdb, *.accdb)};"
conn = pyodbc.connect(driver+access_db_path)
cursor = conn.cursor()

all_tables = [x[2] for x in cursor.tables()]
with open(os.path.join(output_folder,'log.txt'), 'w') as ficout:
    for tab_name in all_tables:
        try:
            tab = pandas.read_sql(f"SELECT * FROM {tab_name}", conn)
            tab.to_csv(os.path.join(output_folder, 'reftab', f'{tab_name}.csv'), sep="\x1f", index=False, header=True)
        except Exception as e:
            ficout.write(f'Cannot read {tab_name}, manual action required !\n')