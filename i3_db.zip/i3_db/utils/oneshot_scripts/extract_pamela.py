import pandas as pd
import os

def get_new_colnames(mapping):

    # Count occurence of each colname
    cn_occurence = {}
    for cn in mapping["Caché Column"]:
        if cn not in cn_occurence:
            cn_occurence[cn] = 0
        cn_occurence[cn] += 1

    # Create new colnames
    new_col_names = []
    countdown_per_col_names = cn_occurence.copy()
    for cn in mapping["Caché Column"]:
        if cn_occurence[cn]>1:
            new_col_names.append(f"{cn}_{str(1 + cn_occurence[cn] - countdown_per_col_names[cn]).zfill(3)}")
            countdown_per_col_names[cn] -= 1
        else:
            new_col_names.append(cn)

    return new_col_names

def load_mapping(pamela_mapping, mapping_header_idx, sheetname, seq_col, size_col, name_col):
    # Load mapping file
    mapping = pd.read_excel(pamela_mapping, header=mapping_header_idx, sheet_name=sheetname)[[seq_col, size_col, name_col]]
    mapping.dropna(how="all", inplace=True)
    
    mapping[seq_col] = mapping[seq_col].astype(int)
    mapping[size_col] = mapping[size_col].astype(int)
    
    prev_seq = None
    prev_index = None
    for i in range(mapping.shape[0]):
        current_seq = mapping.loc[i, seq_col]
        if current_seq != prev_seq:
            prev_index = 0
        mapping.loc[i, "start_idx"] = 0 if prev_index is None else prev_index
        mapping.loc[i, "end_idx"] = mapping.loc[i, "start_idx"] + mapping.loc[i, size_col]
        
        prev_index = mapping.loc[i, "end_idx"]
        prev_seq = mapping.loc[i, seq_col]


    mapping["start_idx"] = mapping["start_idx"].astype(int)
    mapping["end_idx"] = mapping["end_idx"].astype(int)

    return mapping

def generate_pamela_csv(
    pamela_folder,
    mapping_file,
    mapping_header_idx = 0,
    seq_col = "Seq.",
    size_col = "Size",
    name_col = "Caché Column",
    separator = "\x1f",
    overwrite = False,
    output_folder="."
):
    """Function that extract data from raw Pamela files using the mapping file ncdbtoquestis
      and generates one CSV files for each table using the same separator as in raw files.
    """

    # Load Pamela data as a dictionnary
    all_pamela_files = os.listdir(pamela_folder)
    files_dict = {}
    for pamela_file in all_pamela_files:
        with open(os.path.join(pamela_folder, pamela_file), 'r') as fic:
            content = fic.read()
        lines = content.split('\n')
    
        for _ in range(len(lines)):
            item = lines.pop()
            if len(item.rstrip().lstrip()) > 0:
                tag = item[0:4]
                if tag not in files_dict:
                    files_dict[tag] = []
                files_dict[tag].append(item.split(separator))

    # create all tables from files_dict dictionary
    for tablename in files_dict:
        if f'{tablename}.csv' not in os.listdir(output_folder) or overwrite:
            print(f'Generating {tablename}...')
            df = pd.DataFrame(files_dict[tablename])
            df_columns = df.columns
            mapping = load_mapping(mapping_file, mapping_header_idx, tablename, seq_col, size_col, name_col)
            
            # deal with duplicated column names
            mapping[name_col] = get_new_colnames(mapping)

            for idx in mapping.index:
                start_index = mapping.loc[idx, "start_idx"]
                end_index = mapping.loc[idx, "end_idx"]
                seq_index = mapping.loc[idx, seq_col] - 1
                col_name = mapping.loc[idx, name_col]

                # Separate data in columns in target table
                df[col_name] = df[seq_index].apply(lambda x: x[start_index:end_index])
            df.drop(df_columns, axis=1, inplace=True)
            
            # write df in file with defined separator
            df.to_csv(os.path.join(output_folder, f'{tablename}.csv'), sep=separator, index=False, header=True)
        else:
            print(f'{tablename} already in output_folder.')


# Variables
root_folder = "/data"
pamela_raw_folder = os.path.join(root_folder, "raw", "export_pamela")
pamela_mapping_file = os.path.join(root_folder, "raw", "ncdb2questis_v.3.6_pamela_v2.xlsx")
output_folder = os.path.join(root_folder, "output", "pamela")

# Execute the whole script
generate_pamela_csv(pamela_raw_folder, pamela_mapping_file, overwrite=False, output_folder=output_folder)



