import sys
from TableManager import TableManager

# Get config file path
conf_filename = sys.argv[1] if sys.argv[1] != None else None
if conf_filename is None:
    raise Exception("ERROR: config file is missing")

# Drop activated tables
tm = TableManager(conf_filename)
tm.drop_tables("staging")
tm.drop_tables("gold")
tm.drop_tables("view")

print('-- All tables dropped --')
