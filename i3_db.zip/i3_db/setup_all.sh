# Load all activated tables 

sudo su hdfs -c """spark-submit \
--conf "spark.pyspark.python=/usr/bin/python3" \
--driver-memory=16g \
--executor-memory=16g \
--conf "spark.hadoop.hive.exec.dynamic.partition=true" \
--conf "spark.hadoop.hive.exec.dynamic.partition.mode=nonstrict" \
--conf "spark.sql.autoBroadcastJoinThreshold=-1" \
--conf "spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation=true" \
utils/load_tables.py i3_config.json
"""