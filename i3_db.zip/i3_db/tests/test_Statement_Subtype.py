from TestConfigurationLoader import TestConfigurationLoader
from PrimaryKeyChecker import PrimaryKeyChecker

# Variables
configurationLoader = TestConfigurationLoader("Testing Statement Subtype Table in I3")
configuration = configurationLoader.get_configuration()
spark_session = configurationLoader.get_spark_session()
primaryKeyChecker = PrimaryKeyChecker(spark_session, configuration['variables']['i3_db'], '`STATEMENT_SUBTYPE`')

# Execute tests
if not primaryKeyChecker.assert_no_null_primary_key():
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in STATEMENT_SUBTYPE has no primary key !\n")

if not primaryKeyChecker.assert_all_primary_keys_are_unique():
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least two rows in STATEMENT_SUBTYPE have the same primary key !\n")
