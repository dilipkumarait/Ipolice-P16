from TestConfigurationLoader import TestConfigurationLoader
from PrimaryKeyChecker import PrimaryKeyChecker


def all_offences_should_have_a_case_type(spark_session, db_name_db, db_name_view, table_name):
    number_of_offences = spark_session.sql(f"SELECT COUNT(*) AS RESULT FROM {db_name_view}.{table_name}")
    number_of_offences_with_case_type = spark_session.sql(f"SELECT COUNT(*) AS RESULT FROM {db_name_view}.{table_name} AS np INNER JOIN {db_name_db}.CASE_TYPE AS ct ON np.case_type_id = ct.id")

    return number_of_offences.first()['RESULT'] == number_of_offences_with_case_type.first()['RESULT']


def all_case_offences_should_be_loaded_in_view(spark_session, db_name_db, db_name_view, table_name):
    number_of_case_offences_in_view = spark_session.sql(f"SELECT COUNT(*) AS RESULT FROM {db_name_view}.{table_name}")
    number_of_case_offences_in_master_db = spark_session.sql(f"""
        SELECT COUNT(*) AS RESULT 
        FROM {db_name_db}.FACT AS f 
        WHERE f.is_case_entity
    """)

    return number_of_case_offences_in_view.first()['RESULT'] == number_of_case_offences_in_master_db.first()['RESULT']


# Variables
configurationLoader = TestConfigurationLoader("Testing Case Offence Table in I3")
configuration = configurationLoader.get_configuration()
spark_session = configurationLoader.get_spark_session()
db_name_db = configuration['variables']['i3_db']
db_name_view = configuration['variables']['i3_view']
table_name = 'CASE_OFFENCE'
primaryKeyChecker = PrimaryKeyChecker(spark_session, db_name_view, table_name, 'CASE_OFFENCE_ID')

# Execute tests
if not primaryKeyChecker.assert_no_null_primary_key():
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in CASE_OFFENCE has no CASE_OFFENCE_ID value !\n")

if not primaryKeyChecker.assert_all_primary_keys_are_unique():
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least two rows in CASE_OFFENCE have the same value for CASE_OFFENCE_ID while it is expected to unique !\n")

if not all_offences_should_have_a_case_type(spark_session, db_name_db, db_name_view, table_name):
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in CASE_OFFENCE has no Foreign Key to CASE_TYPE !\n")

if not all_case_offences_should_be_loaded_in_view(spark_session, db_name_db, db_name_view, table_name):
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one case offence is not loaded in CASE_OFFENCE !\n")