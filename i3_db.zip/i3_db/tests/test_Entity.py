from TestConfigurationLoader import TestConfigurationLoader
from PrimaryKeyChecker import PrimaryKeyChecker

def all_case_entities_should_have_an_information_catgory(spark_session, db_name, table_name):
    number_of_case_entities = spark_session.sql(f"""
        SELECT COUNT(*) AS RESULT 
        FROM {db_name}.{table_name} AS e 
        WHERE e.is_case_entity
    """)

    number_of_case_entities_with_information_category = spark_session.sql(f"""
        SELECT COUNT(*) AS RESULT 
        FROM {db_name}.{table_name} AS e 
        INNER JOIN {db_name}.INFORMATION_CATEGORY AS ic 
            ON ic.id = e.information_category_id 
        WHERE e.is_case_entity
    """)

    return number_of_case_entities.first()['RESULT'] == number_of_case_entities_with_information_category.first()['RESULT']

def no_real_entity_should_have_an_information_catgory(spark_session, db_name, table_name):
    number_of_real_entities_with_information_category = spark_session.sql(f"""
        SELECT COUNT(*) AS RESULT 
        FROM {db_name}.{table_name} AS e 
        INNER JOIN {db_name}.INFORMATION_CATEGORY AS ic 
            ON ic.id = e.information_category_id 
        WHERE NOT e.is_case_entity
    """)

    return number_of_real_entities_with_information_category.first()['RESULT'] == 0

# Variables
configurationLoader = TestConfigurationLoader("Testing Entity Table in I3")
configuration = configurationLoader.get_configuration()
spark_session = configurationLoader.get_spark_session()
db_name = configuration['variables']['i3_db']
table_name = '`ENTITY`'
primaryKeyChecker = PrimaryKeyChecker(spark_session, configuration['variables']['i3_db'], '`ENTITY`')

# Execute tests

if not primaryKeyChecker.assert_no_null_primary_key():
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in ENTITY has no primary key !\n")

if not primaryKeyChecker.assert_all_primary_keys_are_unique():
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least two rows in ENTITY have the same primary key !\n")

if not no_real_entity_should_have_an_information_catgory(spark_session, db_name, table_name):
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in ENTITY is a real entity and has a Foreign Key to INFORMATION_CATEGORY !\n")

if not all_case_entities_should_have_an_information_catgory(spark_session, db_name, table_name):
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in ENTITY is a case entity and has no Foreign Key to INFORMATION_CATEGORY !\n")
