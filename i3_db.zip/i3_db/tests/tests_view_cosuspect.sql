-- Nb lines in view: 905 lines
select count(*)
from i3_v1_view.co_suspect;

-- composite PK must be unique
-- Expected result: 0 lines
select SOURCE_ENTITY_ID, TARGET_ENTITY_ID, REAL_OFFENCE_ID, count(*)
from i3_v1_view.co_suspect
group by SOURCE_ENTITY_ID, TARGET_ENTITY_ID, REAL_OFFENCE_ID
having count(*) > 1;

-- Check if all source_entity_id are in natural_person table
-- Expected : 0
-- Result : 1417
select count(*)
from i3_v1_view.co_suspect cs
inner join i3_v1_dev.statement stm
    ON stm.target_entity_id = cs.source_entity_id
    AND stm.statement_type_id = 2
    and stm.statement_subtype_id = 7
    AND stm.source_entity_type_id = 1
    AND stm.source_entity_sub_type_id = 3
    AND stm.target_entity_type_id = 1
    AND stm.target_entity_sub_type_id = 3
where stm.source_entity_id not in (
    select case_person_id
    from i3_v1_view.case_natural_person
)

-- Check if all target_entity_id are in natural_person table
-- Expected : 0
-- Result : 1283
select count(*)
from i3_v1_view.co_suspect cs
inner join i3_v1_dev.statement stm
    ON stm.target_entity_id = cs.target_entity_id
    AND stm.statement_type_id = 2
    and stm.statement_subtype_id = 7
    AND stm.source_entity_type_id = 1
    AND stm.source_entity_sub_type_id = 3
    AND stm.target_entity_type_id = 1
    AND stm.target_entity_sub_type_id = 3
where stm.source_entity_id not in (
    select case_person_id
    from i3_v1_view.case_natural_person
)


