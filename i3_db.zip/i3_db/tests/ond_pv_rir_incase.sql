--nombre de case dans i3_db.case
select count(*) from i3_v1_dev.`case`; --7373380

--nombre de case attendu
select sum(test.a)
from ((select count(distinct(ondncdbkey)) as a from raw_questis_latest.ond )
union all
(select count(distinct(pvtechkey)) as a from raw_questis_latest.pf1 pf1 
                      JOIN raw_questis_latest.fei fei
                            ON pf1.pf1feincdbkey = fei.feincdbkey
                      JOIN raw_questis_latest.pvf pvf
                             ON pvf.pvtechkey = pf1.pf1pvtechkey)
union all 
(select count(distinct(rirtechkey))  as a from raw_questis_latest.rf1 rf1
                        JOIN raw_questis_latest.fei fei
                             ON rf1.rf1feincdbkey  = fei.feincdbkey 
                        JOIN raw_questis_latest.rir rir
                             on rir.rirtechkey =rf1.RF1RIRTECHKEY )
) as test;