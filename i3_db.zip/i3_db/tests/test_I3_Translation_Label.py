from TestConfigurationLoader import TestConfigurationLoader
from PrimaryKeyChecker import PrimaryKeyChecker

def all_entries_should_have_an_I3_table(spark_session, db_name, table_name):
    number_of_entries_with_no_I3_table = spark_session.sql(f"""
        SELECT COUNT(*) AS RESULT 
        FROM {db_name}.{table_name} AS c
        WHERE c.i3_table IS NULL
    """)

    return number_of_entries_with_no_I3_table.first()['RESULT'] == 0

def all_entries_should_have_an_I3_id(spark_session, db_name, table_name):
    number_of_entries_with_no_I3_id = spark_session.sql(f"""
        SELECT COUNT(*) AS RESULT 
        FROM {db_name}.{table_name} AS c
        WHERE c.i3_id IS NULL
    """)

    return number_of_entries_with_no_I3_id.first()['RESULT'] == 0

def all_entries_should_have_a_label(spark_session, db_name, table_name):
    number_of_entries_with_no_label = spark_session.sql(f"""
        SELECT COUNT(*) AS RESULT 
        FROM {db_name}.{table_name} AS c
        WHERE c.label IS NULL
    """)

    return number_of_entries_with_no_label.first()['RESULT'] == 0

def all_entries_should_have_a_french_label(spark_session, db_name, table_name):
    number_of_entries_with_no_french_label = spark_session.sql(f"""
        SELECT COUNT(*) AS RESULT 
        FROM {db_name}.{table_name} AS c
        WHERE c.label_fr IS NULL
    """)

    return number_of_entries_with_no_french_label.first()['RESULT'] == 0

# Variables
configurationLoader = TestConfigurationLoader("Testing I3 Translation Label Table in REFERENTIAL DATA View")
configuration = configurationLoader.get_configuration()
spark_session = configurationLoader.get_spark_session()
db_name = configuration['variables']['referential_data_view']
table_name = '`I3_TRANSLATION_LABEL`'
primaryKeyChecker = PrimaryKeyChecker(spark_session, db_name, table_name)

# Execute tests
if not primaryKeyChecker.assert_no_null_primary_key():
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in I3_TRANSLATION_LABEL has no primary key !\n")

if not primaryKeyChecker.assert_all_primary_keys_are_unique():
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least two rows in I3_TRANSLATION_LABEL have the same primary key !\n")

if not all_entries_should_have_an_I3_table(spark_session, db_name, table_name):
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in I3_TRANSLATION_LABEL has no I3 table value !\n")

if not all_entries_should_have_an_I3_id(spark_session, db_name, table_name):
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in I3_TRANSLATION_LABEL has no I3 ID value !\n")

if not all_entries_should_have_a_label(spark_session, db_name, table_name):
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in I3_TRANSLATION_LABEL has no label value !\n")

if not all_entries_should_have_a_french_label(spark_session, db_name, table_name):
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in I3_TRANSLATION_LABEL has no french label value !\n")