
class PrimaryKeyChecker:

    def __init__(self, spark_session, database_name, table_name, primary_key_name='ID'):
        self.database_name = database_name
        self.table_name = table_name
        self.primary_key_name = primary_key_name
        self.spark_session = spark_session

    def assert_all_primary_keys_are_unique(self):
        number_of_distinct_ids = self.spark_session.sql(f"""
            SELECT COUNT(DISTINCT(c.{self.primary_key_name})) AS RESULT 
            FROM {self.database_name}.{self.table_name} AS c
        """)
        number_of_rows = self.spark_session.sql(f"""
            SELECT COUNT(*) AS RESULT 
            FROM {self.database_name}.{self.table_name} AS c
        """)

        return number_of_distinct_ids.first()['RESULT'] == number_of_rows.first()['RESULT']

    def assert_no_null_primary_key(self):
        number_of_rows = self.spark_session.sql(f"""
            SELECT COUNT(*) AS RESULT 
            FROM {self.database_name}.{self.table_name} AS c 
            WHERE c.{self.primary_key_name} IS NULL
        """)

        return number_of_rows.first()['RESULT'] == 0
