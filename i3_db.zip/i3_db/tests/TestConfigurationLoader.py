import re
import json
from pyspark.conf import SparkConf
from pyspark.sql import SparkSession

class TestConfigurationLoader:

    def __init__(self, application_name="Default application name", configuration_filepath="../i3_config.json"):
        # Load json config file
        self.configuration_file = self.load_configuration(configuration_filepath)

        # Get Spark session
        self.spark_session = self.create_spark_session(application_name)
    

    def create_spark_session(self, application_name="Default application name"):
        hive_metastore_uri = self.configuration_file["variables"]["hive_metastore_uri"]
        spark_session = (
            SparkSession
            .builder
            .appName(application_name)
            .config("hive.metastore.uris", hive_metastore_uri, conf=SparkConf())
            .enableHiveSupport()
            .getOrCreate()
        )
        spark_session.sparkContext.setLogLevel('WARN')
        return spark_session

    def load_configuration(self, configuration_filepath):
        """ Load configuration from configuration_filepath
        """
        with open(configuration_filepath, 'r') as configuration_filename:
            configuration_content = configuration_filename.read()
            configuration_content = re.sub('///.*', '', configuration_content)
            conf = json.loads(configuration_content)
            self.conf_default_values(conf) # apply default values on missing fields
        return conf


    def conf_default_values(self, conf):
        """ Set default values for the fields not manually filled in by the user
        """
        DEFAULT_CONF = {
            "active:": False,
            "path":"",
            "order":1000000 # if this parameter is not specified, the table is created after all the other
        }
        for zone in conf:
            if zone != "variables":
                for db in conf[zone]:
                    for table in conf[zone][db]:
                        print("table:", table)
                        if "active" not in conf[zone][db][table]:
                            conf[zone][db][table]["active"] = DEFAULT_CONF["active"]
                        if "path" not in conf[zone][db][table]:
                            conf[zone][db][table]["active"] = False
                            conf[zone][db][table]["path"] = DEFAULT_CONF["path"]
                        if "order" not in conf[zone][db][table]:
                            conf[zone][db][table]["order"] = DEFAULT_CONF["order"]
            
    def get_configuration(self):
        return self.configuration_file

    def get_spark_session(self):
        return self.spark_session