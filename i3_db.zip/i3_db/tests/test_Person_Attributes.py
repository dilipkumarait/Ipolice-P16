from TestConfigurationLoader import TestConfigurationLoader
from PrimaryKeyChecker import PrimaryKeyChecker

# Variables
configurationLoader = TestConfigurationLoader("Testing Person Attributes Table in I3")
configuration = configurationLoader.get_configuration()
spark_session = configurationLoader.get_spark_session()
primaryKeyChecker = PrimaryKeyChecker(spark_session, configuration['variables']['i3_db'], '`PERSON_ATTRIBUTES`')

# Execute tests
if not primaryKeyChecker.assert_no_null_primary_key():
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in PERSON_ATTRIBUTES has no primary key !\n")

if not primaryKeyChecker.assert_all_primary_keys_are_unique():
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least two rows in PERSON_ATTRIBUTES have the same primary key !\n")
