-- le nombre de lignes dans la table enfant correspond au nombre de lignes dans la table entity pour un type/subtype donné
select
    e.entity_type_id as type,
    e.entity_sub_type_id as subtype,
    count(e.entity_id) as count_entity,
    case 
        when e.entity_type_id = 1 then count(p.person_id)
        when e.entity_type_id = 3 then count(ev.event_id)
        when e.entity_type_id = 4 then count(o.object_id) 
        else Null
        end
    as count_child
    
from i3_v1_dev.entity e
left join i3_v1_dev.person p
    on e.entity_id = p.person_id
    and e.is_case_entity = p.is_case_entity
    
left join i3_v1_dev.object o
    on e.entity_id = o.object_id
    and e.is_case_entity = o.is_case_entity
left join i3_v1_dev.event ev
    on e.entity_id = ev.event_id
    and e.is_case_entity = ev.is_case_entity

WHERE e.is_case_entity = True
group by
    e.entity_type_id,
    e.entity_sub_type_id
order by type
;

--L'ensemble des clé primaires dans la table enfant est inclu dans l'ensemble des clés primaires dans la table parente
select count(*) from i3_v1_dev.natural_person  where id not in (select id from i3_v1_dev.person);
select count(*) from i3_v1_dev.moral_person where id not in (select id from i3_v1_dev.person) ;
select count(*) from i3_v1_dev.`grouping`  where id not in (select id from i3_v1_dev.person) ;
select count(*) from i3_v1_dev.fact  where id not in (select id from i3_v1_dev.event) ;
select count(*) from i3_v1_dev.drug  where id not in (select id from i3_v1_dev.object);
select count(*) from i3_v1_dev.firearm  where id not in (select id from i3_v1_dev.object);
select count(*) from i3_v1_dev.weapon  where id not in (select id from i3_v1_dev.object) ;
select count(*) from i3_v1_dev.vehicle  where id not in (select id from i3_v1_dev.object) ;

