
-- Check case status:
-- Expected: 4 different IDs and 4 labels
select id, count(distinct(labels)) as nb_labels, count(*) as nb_lines
from i3_v1_dev.CASE_STATUS
where ID is not NULL
group by id

-- Check case type:
-- Expected: 24 different IDs and 24 different labels
-- This bloc should return 24 lines
select id, labels, count(*) as cnt
from i3_v1_dev.CASE_TYPE
where ID is not NULL
and LABEL is not NULL
group by id, labels

-- Check case confidentiality
-- Expected: 4 distinct levels of confidentiality with different IDs and labels
select id, labels, count(*) as cnt
from i3_v1_dev.CASE_CONFIDENTIALITY
where ID is not NULL
and LABEL is not NULL
group by id, labels