from TestConfigurationLoader import TestConfigurationLoader


def real_offence_display_title(spark_session, db_name_view, table_name):
    concatinated_column = spark_session.sql(f"SELECT REAL_OFFENCE_DISPLAY_TITLE AS RESULT FROM {db_name_view}.{table_name} LIMIT 1")
    concatinated_id_class = spark_session.sql(f"SELECT CONCAT_WS(' ', REAL_OFFENCE_ID, REAL_OFFENCE_CLASS) AS RESULT FROM {db_name_view}.{table_name} LIMIT 1")

    return concatinated_column.first()['RESULT'] == concatinated_id_class.first()['RESULT']


def all_shared_real_offence_should_have_a_display_title(spark_session, db_name_view, table_name):
    number_of_missing_real_offence_display_title = spark_session.sql(f"""
        SELECT COUNT(*) AS RESULT 
        FROM {db_name_view}.{table_name} AS co_suspect
        WHERE co_suspect.real_offence_display_title IS NULL
    """)

    return number_of_missing_real_offence_display_title.first()['RESULT'] == 0


def all_source_real_entity_should_have_a_display_title(spark_session, db_name_view, table_name):
    number_of_missing_source_real_entity_display_title = spark_session.sql(f"""
        SELECT COUNT(*) AS RESULT 
        FROM {db_name_view}.{table_name} AS co_suspect
        WHERE co_suspect.source_entity_display_title IS NULL
    """)

    return number_of_missing_source_real_entity_display_title.first()['RESULT'] == 0


def all_target_real_entity_should_have_a_display_title(spark_session, db_name_view, table_name):
    number_of_missing_target_real_entity_display_title = spark_session.sql(f"""
        SELECT COUNT(*) AS RESULT 
        FROM {db_name_view}.{table_name} AS co_suspect
        WHERE co_suspect.target_entity_display_title IS NULL
    """)

    return number_of_missing_target_real_entity_display_title.first()['RESULT'] == 0


def all_shared_real_offence_should_have_case_types(spark_session, db_name_view, table_name):
    number_of_missing_shared_real_offence_case_type = spark_session.sql(f"""
        SELECT COUNT(*) AS RESULT 
        FROM {db_name_view}.{table_name} AS co_suspect
        WHERE co_suspect.case_type IS NULL OR co_suspect.case_type = ''
    """)

    return number_of_missing_shared_real_offence_case_type.first()['RESULT'] == 0


def all_shared_real_offence_should_have_cases(spark_session, db_name_view, table_name):
    number_of_missing_shared_real_offence_case_type = spark_session.sql(f"""
        SELECT COUNT(*) AS RESULT 
        FROM {db_name_view}.{table_name} AS co_suspect
        WHERE co_suspect.case_id IS NULL OR co_suspect.case_id = ''
    """)

    return number_of_missing_shared_real_offence_case_type.first()['RESULT'] == 0

# Variables
configurationLoader = TestConfigurationLoader("Testing Co_suspect Table in I3")
configuration = configurationLoader.get_configuration()
spark_session = configurationLoader.get_spark_session()
db_name_view = configuration['variables']['i3_view']
table_name = 'CO_SUSPECT'

# Execute tests
if not real_offence_display_title(spark_session, db_name_view, table_name):
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in Co_suspect has no correct value in REAL_OFFENCE_DISPLAY_TITLE !\n")

if not all_shared_real_offence_should_have_a_display_title(spark_session, db_name_view, table_name):
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in Co_suspect has no value in REAL_OFFENCE_DISPLAY_TITLE !\n")

if not all_source_real_entity_should_have_a_display_title(spark_session, db_name_view, table_name):
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in Co_suspect has no value in SOURCE_ENTITY_DISPLAY_TITLE !\n")

if not all_target_real_entity_should_have_a_display_title(spark_session, db_name_view, table_name):
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in Co_suspect has no value in TARGET_ENTITY_DISPLAY_TITLE !\n")

if not all_shared_real_offence_should_have_case_types(spark_session, db_name_view, table_name):
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in Co_suspect has no value or a blank value in CASE_TYPE !\n")

if not all_shared_real_offence_should_have_cases(spark_session, db_name_view, table_name):
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in Co_suspect has no value or a blank value in CASE_ID !\n")
