
-- -- -- Row number check
-- Source: ENTITY
SELECT
is_case_entity,
count(*) as Nb
FROM ${i3_db}.entity 
where is_case_entity IS FALSE
GROUP BY is_case_entity; -- 683 140

-- View: REAL_ENTITY
SELECT
count(*)
FROM ${i3_view}.real_entity; -- 683 140

-- -- -- Schema requirement check
DESCRIBE ${i3_view}.real_entity;
-- Spec Requirements: Three column BIGINT

-- -- -- Multivalue check
SELECT
*
FROM ${i3_view}.real_entity
GROUP BY real_entity_id, real_entity_type_id, real_entity_sub_type_id
HAVING count(*) > 1: -- 0 multiple row

-- -- -- Nullable check
SELECT
*
FROM ${i3_view}.real_entity
WHERE real_entity_id is null or real_entity_type_id is null
or real_entity_sub_type_id is null -- 0

-- -- -- PK unicity check
SELECT
real_entity_id
FROM ${i3_view}.real_entity
GROUP BY real_entity_id
HAVING count(*) > 1; -- 0