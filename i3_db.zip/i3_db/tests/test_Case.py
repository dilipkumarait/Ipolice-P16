from TestConfigurationLoader import TestConfigurationLoader
from PrimaryKeyChecker import PrimaryKeyChecker


def all_cases_should_have_a_type(spark_session, db_name, table_name):
    number_of_cases = spark_session.sql(f"SELECT COUNT(*) AS RESULT FROM {db_name}.{table_name}")
    number_of_cases_with_type = spark_session.sql(f"SELECT COUNT(*) AS RESULT FROM {db_name}.{table_name} AS c INNER JOIN {db_name}.CASE_TYPE AS ct ON c.case_type_id = ct.id")

    return number_of_cases.first()['RESULT'] == number_of_cases_with_type.first()['RESULT']

def all_cases_should_have_a_confidentiality_level(spark_session, db_name, table_name):
    number_of_cases = spark_session.sql(f"SELECT COUNT(*) AS RESULT FROM {db_name}.{table_name}")
    number_of_cases_with_confidentiality_level = spark_session.sql(f"SELECT COUNT(*) AS RESULT FROM {db_name}.{table_name} AS c INNER JOIN {db_name}.CASE_CONFIDENTIALITY AS cc ON c.case_confidentiality_id = cc.id")

    return number_of_cases.first()['RESULT'] == number_of_cases_with_confidentiality_level.first()['RESULT']

# Variables
configurationLoader = TestConfigurationLoader("Testing Case Table in I3")
configuration = configurationLoader.get_configuration()
spark_session = configurationLoader.get_spark_session()
db_name = configuration['variables']['i3_db']
table_name = '`CASE`'
primaryKeyChecker = PrimaryKeyChecker(spark_session, db_name, table_name)

# Execute tests
if not primaryKeyChecker.assert_no_null_primary_key():
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in CASE has no primary key !\n")

if not primaryKeyChecker.assert_all_primary_keys_are_unique():
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least two rows in CASE have the same primary key !\n")

if not all_cases_should_have_a_type(spark_session, db_name, table_name):
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in CASE has no Foreign Key to CASE_TYPE !\n")

if not all_cases_should_have_a_confidentiality_level(spark_session, db_name, table_name):
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in CASE has no Foreign Key to CASE_CONFIDENTIALITY !\n")
