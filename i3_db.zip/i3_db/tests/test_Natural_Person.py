from TestConfigurationLoader import TestConfigurationLoader
from PrimaryKeyChecker import PrimaryKeyChecker

# Variables
configurationLoader = TestConfigurationLoader("Testing Natural Person Table in I3")
configuration = configurationLoader.get_configuration()
spark_session = configurationLoader.get_spark_session()
primaryKeyChecker = PrimaryKeyChecker(spark_session, configuration['variables']['i3_db'], '`NATURAL_PERSON`')

# Execute tests
if not primaryKeyChecker.assert_no_null_primary_key():
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least one row in NATURAL_PERSON has no primary key !\n")

if not primaryKeyChecker.assert_all_primary_keys_are_unique():
    # TODO: Replace this line with an assertion
    print(f"TEST FAILED: At least two rows in NATURAL_PERSON have the same primary key !\n")
