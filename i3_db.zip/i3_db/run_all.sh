bash clean_all.sh
bash setup_all.sh
bash postprocess_all.sh