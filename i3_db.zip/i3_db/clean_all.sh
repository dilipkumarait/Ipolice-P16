# Drop activated tables
sudo su hdfs -c """spark-submit \
--conf spark.pyspark.python=/usr/bin/python3 \
utils/drop_tables.py i3_config.json
"""
